export interface GitLabErrorOptions {
  message: string;
  statusCode?: number;
  responseBody?: string;
  cause?: unknown;
}

export class GitLabError extends Error {
  readonly statusCode?: number;
  readonly responseBody?: string;
  declare readonly cause?: unknown;

  constructor(options: GitLabErrorOptions) {
    super(options.message, { cause: options.cause });
    this.name = 'GitLabError';
    this.statusCode = options.statusCode;
    this.responseBody = options.responseBody;

    // Maintain proper stack trace for where error was thrown (only available on V8)
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, GitLabError);
    }
  }

  static fromResponse(response: Response, body: string): GitLabError {
    return new GitLabError({
      message: `GitLab API error: ${response.status} ${response.statusText}`,
      statusCode: response.status,
      responseBody: body,
    });
  }

  isAuthError(): boolean {
    return this.statusCode === 401;
  }

  isRateLimitError(): boolean {
    return this.statusCode === 429;
  }

  isForbiddenError(): boolean {
    return this.statusCode === 403;
  }

  isServerError(): boolean {
    return this.statusCode !== undefined && this.statusCode >= 500;
  }

  /**
   * Check if this error is a context overflow error (prompt too long).
   * These errors occur when the conversation exceeds the model's token limit.
   */
  isContextOverflowError(): boolean {
    if (this.statusCode !== 400) {
      return false;
    }
    const message = this.message?.toLowerCase() || '';
    return (
      message.includes('context overflow') ||
      message.includes('prompt is too long') ||
      message.includes('prompt too long') ||
      (message.includes('tokens') && message.includes('maximum'))
    );
  }
}
