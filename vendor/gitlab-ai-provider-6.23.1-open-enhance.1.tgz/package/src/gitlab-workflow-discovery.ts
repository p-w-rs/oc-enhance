/**
 * High-level workflow model discovery.
 *
 * Combines project detection, GraphQL model discovery, model config lookup,
 * and MODEL_MAPPINGS to produce a list of available workflow models with
 * their token limits. Consumers map these into their own internal model
 * representations.
 */

import { GitLabModelDiscovery } from './gitlab-model-discovery';
import type { DiscoveredModels, DiscoveryScope } from './gitlab-model-discovery';
import { GitLabModelConfigRegistry } from './gitlab-model-config';
import { GitLabProjectDetector } from './gitlab-project-detector';
import { MODEL_MAPPINGS } from './model-mappings';
import type { GitLabProject } from './gitlab-project-cache';
import { GitLabModelCache } from './gitlab-model-cache';

export interface DiscoveredWorkflowModel {
  /** Model ID suitable for use with `sdk.workflowChat()` (e.g. "duo-workflow-sonnet-4-6") */
  id: string;
  /** Upstream model ref (e.g. "claude_sonnet_4_6") */
  ref: string;
  /** Human-readable name (e.g. "Claude Sonnet 4.6") */
  name: string;
  /** Max input context tokens */
  context: number;
  /** Max output tokens */
  output: number;
  /** Whether this model was admin-pinned */
  pinned: boolean;
}

export interface WorkflowDiscoveryConfig {
  instanceUrl: string;
  getHeaders: () => Record<string, string>;
  fetch?: typeof fetch;
}

export interface WorkflowDiscoveryOptions {
  workingDirectory: string;
  /**
   * Optional opaque identifier of the account the discovery runs for. When set, cached
   * results are scoped to it so switching accounts on the same workspace and instance
   * never returns another account's models. The value is hashed before being stored.
   */
  cacheKey?: string;
}

export interface WorkflowDiscoveryResult {
  models: DiscoveredWorkflowModel[];
  project: GitLabProject | null;
}

const configRegistry = new GitLabModelConfigRegistry();

async function buildModels(
  discovered: DiscoveredModels,
  project: GitLabProject | null
): Promise<WorkflowDiscoveryResult> {
  const configs = await configRegistry.getConfigs();

  const refToID = new Map<string, string>();
  for (const [id, mapping] of Object.entries(MODEL_MAPPINGS)) {
    if (mapping.provider === 'workflow' && id !== 'duo-workflow' && id !== 'duo-workflow-default') {
      refToID.set(mapping.model, id);
    }
  }

  const all = discovered.pinnedModel
    ? [discovered.pinnedModel]
    : [
        ...(discovered.selectableModels ?? []),
        ...(discovered.defaultModel ? [discovered.defaultModel] : []),
      ];

  const seen = new Set<string>();
  const models: DiscoveredWorkflowModel[] = [];

  for (const model of all) {
    if (!model.ref || seen.has(model.ref)) continue;
    seen.add(model.ref);

    const id =
      refToID.get(model.ref) ??
      (model.ref.startsWith('__default__')
        ? 'duo-workflow-default'
        : `duo-workflow-${model.ref.replace(/[/_]/g, '-')}`);
    const limits = configs.get(model.ref);

    models.push({
      id,
      ref: model.ref,
      name: model.name,
      context: limits?.context ?? 200_000,
      output: limits?.output ?? 64_000,
      pinned: !!discovered.pinnedModel && discovered.pinnedModel.ref === model.ref,
    });
  }

  return { models, project };
}

export async function discoverWorkflowModels(
  config: WorkflowDiscoveryConfig,
  options: WorkflowDiscoveryOptions
): Promise<WorkflowDiscoveryResult> {
  const cache = new GitLabModelCache(
    options.workingDirectory,
    config.instanceUrl,
    options.cacheKey
  );

  if (!cache.isDiscoveryExpired()) {
    const entry = cache.load();
    if (entry?.discovery) {
      return buildModels(entry.discovery, entry.project);
    }
  }

  const detector = new GitLabProjectDetector({
    instanceUrl: config.instanceUrl,
    getHeaders: config.getHeaders,
    fetch: config.fetch,
  });

  let project: GitLabProject | null = null;
  try {
    project = await detector.detectProject(options.workingDirectory);
  } catch {
    return { models: [], project: null };
  }

  if (!project?.id) return { models: [], project };

  const scope: DiscoveryScope = {
    projectId: `gid://gitlab/Project/${project.id}`,
    ...(project.namespaceId
      ? { rootNamespaceId: `gid://gitlab/Group/${project.namespaceId}` }
      : {}),
  };

  const discovery = new GitLabModelDiscovery({
    instanceUrl: config.instanceUrl,
    getHeaders: config.getHeaders,
    fetch: config.fetch,
  });

  let discovered: DiscoveredModels;
  try {
    discovered = await discovery.discover(scope);
  } catch {
    // Discovery can legitimately fail (e.g. Duo Agent Platform not
    // available for this namespace, or an unsupported GitLab version).
    // Degrade to no workflow models rather than surfacing the error.
    return { models: [], project };
  }

  cache.saveDiscovery(discovered, project);

  if (!cache.getSelectedModelRef()) {
    const pick = discovered.pinnedModel ?? discovered.defaultModel;
    if (pick) cache.saveSelection(pick.ref, pick.name);
  }

  return buildModels(discovered, project);
}
