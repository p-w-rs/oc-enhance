import { z } from 'zod';
import { GitLabError } from './gitlab-error';
import { sanitizeErrorText } from './gitlab-workflow-token-client';

/**
 * Response from /api/v4/ai/third_party_agents/direct_access
 */
export const directAccessTokenSchema = z.object({
  headers: z.record(z.string(), z.string()),
  token: z.string(),
});

export type DirectAccessToken = z.infer<typeof directAccessTokenSchema>;

export const DEFAULT_AI_GATEWAY_URL = 'https://cloud.gitlab.com';

export interface GitLabDirectAccessConfig {
  instanceUrl: string;
  getHeaders: () => Record<string, string>;
  /**
   * Optional async hook that resolves once credentials are loaded.
   * `getHeaders` is synchronous, but the API key is loaded asynchronously; the
   * client awaits this before building request headers so the first request on
   * a cold provider doesn't race the lazy key load (which would otherwise throw
   * "API key is missing" or send an empty Authorization header).
   */
  ensureApiKey?: () => Promise<void>;
  fetch?: typeof fetch;
  /**
   * Optional callback to refresh the API key when a 401 error occurs.
   * Should clear cached credentials and re-fetch from auth provider.
   */
  refreshApiKey?: () => Promise<void>;
  /**
   * Feature flags to pass to the GitLab API
   */
  featureFlags?: Record<string, boolean>;
  /**
   * AI Gateway URL for the Anthropic proxy.
   * Can also be set via GITLAB_AI_GATEWAY_URL environment variable.
   * @default 'https://cloud.gitlab.com'
   */
  aiGatewayUrl?: string;
  /**
   * Private POSIX directory for cross-process token caching; empty string disables it.
   * Falls back to GITLAB_DIRECT_ACCESS_CACHE_DIR when omitted.
   * @default undefined
   */
  directAccessCacheDir?: string;
}

/**
 * Client for GitLab's third-party agents direct access API.
 * This allows routing requests through GitLab's proxy to Anthropic.
 */
export class GitLabDirectAccessClient {
  private readonly config: GitLabDirectAccessConfig;
  private readonly fetchFn: typeof fetch;
  private readonly aiGatewayUrl: string;
  private cachedToken: DirectAccessToken | null = null;
  private tokenExpiresAt: number = 0;
  private invalidationVersion = 0;
  private refreshedVersion = 0;
  private cachedScope: string | null = null;

  constructor(config: GitLabDirectAccessConfig) {
    this.config = config;
    this.fetchFn = config.fetch ?? fetch;
    this.aiGatewayUrl =
      config.aiGatewayUrl || process.env['GITLAB_AI_GATEWAY_URL'] || DEFAULT_AI_GATEWAY_URL;
  }

  /**
   * Get a direct access token for the Anthropic proxy.
   * Tokens are cached for 25 minutes (they expire after 30 minutes).
   * @param forceRefresh - If true, ignores the cache and fetches a new token
   */
  async getDirectAccessToken(forceRefresh: boolean = false): Promise<DirectAccessToken> {
    // Check if we have a valid cached token (unless force refresh is requested)
    const now = Date.now();
    const directory =
      this.config.directAccessCacheDir ?? process.env['GITLAB_DIRECT_ACCESS_CACHE_DIR'];
    if (!directory && !forceRefresh && this.cachedToken && this.tokenExpiresAt > now) {
      return this.cachedToken;
    }

    // Clear cache if forcing refresh
    if (forceRefresh) {
      this.invalidateToken();
    }

    const url = `${this.config.instanceUrl}/api/v4/ai/third_party_agents/direct_access`;

    // Prepare request body with feature flags if provided
    const requestBody: Record<string, unknown> = {};
    if (this.config.featureFlags && Object.keys(this.config.featureFlags).length > 0) {
      requestBody.feature_flags = this.config.featureFlags;
    }

    // Ensure the (asynchronously loaded) API key is ready before building the
    // synchronous headers, so a cold first request doesn't race the lazy load.
    if (this.config.ensureApiKey) {
      await this.config.ensureApiKey();
    }

    try {
      const headers = this.config.getHeaders();
      const scope = JSON.stringify([
        url,
        this.aiGatewayUrl,
        Object.entries(headers).sort(([a], [b]) => a.localeCompare(b)),
        Object.entries(this.config.featureFlags ?? {}).sort(([a], [b]) => a.localeCompare(b)),
      ]);
      const version = this.invalidationVersion;
      const bypass = version !== this.refreshedVersion;
      if (
        directory &&
        !bypass &&
        this.cachedScope === scope &&
        this.cachedToken &&
        this.tokenExpiresAt > Date.now()
      ) {
        return this.cachedToken;
      }
      const request = (signal?: AbortSignal) =>
        this.fetchFn(url, {
          method: 'POST',
          signal,
          headers: {
            ...headers,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        });
      const shared = directory
        ? await (
            await import('./gitlab-direct-access-cache')
          ).cachedDirectAccess(directory, scope, bypass, request)
        : undefined;
      const response = shared?.response ?? (await request());

      if (!response.ok) {
        const errorText = await response.text();
        const safeError = sanitizeErrorText(errorText);

        // If we get a 401 and have a refresh callback, try refreshing the API key once
        if (response.status === 401 && this.config.refreshApiKey && !forceRefresh) {
          try {
            // Refresh the API key (this should clear cached credentials and re-fetch from auth)
            await this.config.refreshApiKey();

            // Retry the request with the refreshed credentials
            return await this.getDirectAccessToken(true);
          } catch (retryError) {
            if (retryError instanceof GitLabError) {
              throw retryError;
            }
            throw new GitLabError({
              message: `Failed to get direct access token: ${response.status} ${response.statusText} - ${safeError}`,
              statusCode: response.status,
              responseBody: safeError,
              cause: retryError,
            });
          }
        }

        // Provide helpful error message for 403 errors (common with self-hosted instances)
        if (response.status === 403) {
          throw new GitLabError({
            message:
              `Access denied to GitLab AI features (${this.config.instanceUrl}). ` +
              `This may indicate that: (1) GitLab Duo is not enabled on this instance, ` +
              `(2) Your account does not have access to AI features, or ` +
              `(3) The third-party agents feature is not available. ` +
              `Original error: ${response.status} ${response.statusText} - ${safeError}`,
            statusCode: response.status,
            responseBody: safeError,
          });
        }

        throw new GitLabError({
          message: `Failed to get direct access token: ${response.status} ${response.statusText} - ${safeError}`,
          statusCode: response.status,
          responseBody: safeError,
        });
      }

      const data = await response.json();
      const token = directAccessTokenSchema.parse(data);
      this.refreshedVersion = version;

      // Cache the token for 25 minutes (tokens expire after 30 minutes)
      this.cachedToken = token;
      this.tokenExpiresAt = shared?.expiresAt ?? now + 25 * 60 * 1000;
      this.cachedScope = scope;

      return token;
    } catch (error) {
      if (error instanceof GitLabError) {
        throw error;
      }
      throw new GitLabError({
        message: `Failed to get direct access token: ${error}`,
        cause: error,
      });
    }
  }

  /**
   * Get the Anthropic proxy base URL
   */
  getAnthropicProxyUrl(): string {
    const baseUrl = this.aiGatewayUrl.replace(/\/$/, '');
    return `${baseUrl}/ai/v1/proxy/anthropic/`;
  }

  /**
   * Get the OpenAI proxy base URL
   * Note: The OpenAI SDK expects a base URL like https://api.openai.com/v1
   * and appends paths like /chat/completions. So we need /v1 at the end.
   */
  getOpenAIProxyUrl(): string {
    const baseUrl = this.aiGatewayUrl.replace(/\/$/, '');
    return `${baseUrl}/ai/v1/proxy/openai/v1`;
  }

  /**
   * Invalidate the cached token
   */
  invalidateToken(): void {
    this.cachedToken = null;
    this.tokenExpiresAt = 0;
    this.invalidationVersion++;
  }
}
