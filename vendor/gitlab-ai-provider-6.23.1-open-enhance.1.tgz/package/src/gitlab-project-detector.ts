import { spawn } from 'child_process';
import * as path from 'path';
import { GitLabProjectCache, type GitLabProject } from './gitlab-project-cache';
import { GitLabError } from './gitlab-error';

export interface GitLabProjectDetectorConfig {
  instanceUrl: string;
  getHeaders: () => Record<string, string>;
  fetch?: typeof fetch;
  cache?: GitLabProjectCache;
  gitTimeout?: number;
}

/**
 * Detects GitLab project information from git remote URLs
 *
 * This class provides functionality to:
 * - Parse git remote URLs (SSH, HTTPS, custom domains)
 * - Execute git commands to get remote URLs
 * - Fetch project details from GitLab API
 * - Cache project information to avoid repeated API calls
 */
export class GitLabProjectDetector {
  private readonly config: GitLabProjectDetectorConfig;
  private readonly fetchFn: typeof fetch;
  private readonly cache: GitLabProjectCache;

  constructor(config: GitLabProjectDetectorConfig) {
    this.config = {
      gitTimeout: 5000, // 5 seconds default
      ...config,
    };
    this.fetchFn = config.fetch ?? fetch;
    this.cache = config.cache ?? new GitLabProjectCache();
  }

  /**
   * Auto-detect GitLab project from git remote in the working directory
   *
   * @param workingDirectory - The directory to check for git remote
   * @param remoteName - The git remote name to use (default: 'origin')
   * @returns The detected project or null if not a git repo / no matching remote
   * @throws GitLabError if the API call or an unexpected error occurs
   */
  async detectProject(
    workingDirectory: string,
    remoteName: string = 'origin'
  ): Promise<GitLabProject | null> {
    // 1. Check cache first
    const cacheKey = `${path.resolve(workingDirectory)}\0${remoteName}`;
    const cached = this.cache.get(cacheKey);
    if (cached) {
      return cached;
    }

    try {
      // 2. Get git remote URL
      const remoteUrl = await this.getGitRemoteUrl(workingDirectory, remoteName);
      if (!remoteUrl) {
        return null; // Not a git repo or no remote
      }

      // 3. Parse project path from URL
      const projectPath = this.parseGitRemoteUrl(remoteUrl, this.config.instanceUrl);
      if (!projectPath) {
        return null; // Remote doesn't match instance
      }

      // 4. Fetch project from GitLab API
      const project = await this.getProjectByPath(projectPath);

      // 5. Cache the result
      this.cache.set(cacheKey, project);

      return project;
    } catch (error) {
      throw error instanceof GitLabError
        ? error
        : new GitLabError({
            message: `Project detection failed: ${error}`,
            cause: error,
          });
    }
  }

  /**
   * Parse a git remote URL to extract the project path
   *
   * Supports:
   * - SSH: git@gitlab.com:namespace/project.git
   * - HTTPS: https://gitlab.com/namespace/project.git
   * - HTTP: http://gitlab.local/namespace/project.git
   * - Custom domains and ports
   *
   * @param remoteUrl - The git remote URL
   * @param instanceUrl - The GitLab instance URL to match against
   * @returns The project path (e.g., "namespace/project") or null if parsing fails
   */
  parseGitRemoteUrl(remoteUrl: string, instanceUrl: string): string | null {
    try {
      // Extract hostname from instanceUrl
      const instanceHost = new URL(instanceUrl).hostname;

      // ssh:// format: ssh://git@host[:port]/path.git
      if (remoteUrl.startsWith('ssh://')) {
        try {
          const sshUrl = new URL(remoteUrl);
          if (sshUrl.hostname === instanceHost) {
            const sshPath = sshUrl.pathname.replace(/^\//, '');
            return sshPath.endsWith('.git') ? sshPath.slice(0, -4) : sshPath;
          }
        } catch {
          // fall through to other formats
        }
        return null;
      }

      // scp-style SSH format: git@host:path.git (no port — paths start right
      // after the colon, so numeric top-level namespaces are preserved)
      const sshMatch = remoteUrl.match(/^git@([^:]+):(.+?)(?:\.git)?$/);
      if (sshMatch) {
        const [, host, pathPart] = sshMatch;
        if (host === instanceHost) {
          return pathPart.endsWith('.git') ? pathPart.slice(0, -4) : pathPart;
        }
      }

      // HTTPS/HTTP format: https://host/path.git or https://host:port/path.git
      const httpsMatch = remoteUrl.match(/^(https?):\/\/([^/]+)\/(.+?)(?:\.git)?$/);
      if (httpsMatch) {
        const [, , hostWithPort, pathPart] = httpsMatch;
        const host = hostWithPort.split(':')[0];
        if (host === instanceHost) {
          return pathPart.endsWith('.git') ? pathPart.slice(0, -4) : pathPart;
        }
      }

      return null;
    } catch {
      // URL parsing failed
      return null;
    }
  }

  /**
   * Get the git remote URL from a working directory
   *
   * @param workingDirectory - The directory to check
   * @param remoteName - The git remote name (default: 'origin')
   * @returns The remote URL or null if not found
   */
  async getGitRemoteUrl(
    workingDirectory: string,
    remoteName: string = 'origin'
  ): Promise<string | null> {
    return new Promise((resolve) => {
      const child = spawn('git', ['config', '--get', `remote.${remoteName}.url`], {
        cwd: workingDirectory,
        timeout: this.config.gitTimeout,
      });

      let stdout = '';

      child.stdout?.on('data', (data) => {
        stdout += data.toString();
      });

      child.stderr?.resume();

      child.on('close', (exitCode) => {
        if (exitCode === 0 && stdout.trim()) {
          resolve(stdout.trim());
        } else {
          resolve(null);
        }
      });

      child.on('error', () => {
        // Git not available or command failed
        resolve(null);
      });
    });
  }

  /**
   * Fetch project details from GitLab API by project path
   *
   * @param projectPath - The project path (e.g., "namespace/project")
   * @returns The project details
   * @throws GitLabError if the API call fails
   */
  async getProjectByPath(projectPath: string): Promise<GitLabProject> {
    // URL-encode the project path
    const encodedPath = encodeURIComponent(projectPath);
    const url = `${this.config.instanceUrl}/api/v4/projects/${encodedPath}`;

    try {
      const response = await this.fetchFn(url, {
        method: 'GET',
        headers: this.config.getHeaders(),
      });

      if (!response.ok) {
        throw new GitLabError({
          message: `Failed to fetch project '${projectPath}': ${response.status} ${response.statusText}`,
        });
      }

      const data = (await response.json()) as {
        id: number;
        path: string;
        path_with_namespace: string;
        name: string;
        namespace?: { id: number };
      };

      return {
        id: data.id,
        path: data.path,
        pathWithNamespace: data.path_with_namespace,
        name: data.name,
        namespaceId: data.namespace?.id,
      };
    } catch (error) {
      if (error instanceof GitLabError) {
        throw error;
      }
      throw new GitLabError({
        message: `Failed to fetch project '${projectPath}': ${error}`,
        cause: error,
      });
    }
  }

  /**
   * Clear the project cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Get the cache instance (useful for testing)
   */
  getCache(): GitLabProjectCache {
    return this.cache;
  }
}
