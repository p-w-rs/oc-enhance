/**
 * Dynamic model discovery via GitLab GraphQL API.
 *
 * Queries `aiChatAvailableModels` to discover which models are available
 * for a given GitLab project or namespace. Used to dynamically populate
 * `duo-workflow-*` model IDs at runtime.
 *
 * Requires GitLab 18.4+ (18.5+ for pinned model support). `projectId` scoping
 * requires a newer GitLab release than `rootNamespaceId` scoping; when a
 * `projectId` query fails and a `rootNamespaceId` is also known, discovery
 * falls back to the namespace-scoped query.
 */

import { GitLabError } from './gitlab-error';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AiModel {
  /** Display name (e.g., 'Claude Sonnet 4.6') */
  name: string;
  /** Model reference for API use (e.g., 'claude_sonnet_4_6') */
  ref: string;
}

export interface AiChatAvailableModels {
  defaultModel: AiModel | null;
  selectableModels: AiModel[];
  pinnedModel: AiModel | null;
}

export interface DiscoveredModels {
  /** The effective model (pinned > user-selected > default) */
  defaultModel: AiModel | null;
  /** All models the user can select from */
  selectableModels: AiModel[];
  /** Admin-pinned model (overrides everything) */
  pinnedModel: AiModel | null;
  /** Whether the ai_user_model_switching feature flag is enabled */
  modelSwitchingEnabled: boolean;
  /** GitLab instance version */
  instanceVersion: string | null;
}

export interface ModelDiscoveryConfig {
  /** GitLab instance URL */
  instanceUrl: string;
  /** Function returning auth headers */
  getHeaders: () => Record<string, string>;
  /** Custom fetch */
  fetch?: typeof fetch;
}

/**
 * Scope to discover models for. `projectId` is preferred (works for both
 * group- and user-namespace projects). An optional `rootNamespaceId` may be
 * supplied alongside it as a fallback for GitLab instances too old to
 * support `projectId`-scoped discovery.
 */
export type DiscoveryScope =
  | { projectId: string; rootNamespaceId?: string }
  | { rootNamespaceId: string };

function scopeCacheKey(scope: DiscoveryScope): string {
  return 'projectId' in scope ? `p:${scope.projectId}` : `n:${scope.rootNamespaceId}`;
}

function normalizeScope(scope: DiscoveryScope | string): DiscoveryScope {
  return typeof scope === 'string' ? { rootNamespaceId: scope } : scope;
}

// ---------------------------------------------------------------------------
// GraphQL query (inlined — no need for graphql-request gql tag)
// ---------------------------------------------------------------------------

const AI_CHAT_AVAILABLE_MODELS_QUERY = `
  query aiChatAvailableModels($projectId: ProjectID, $rootNamespaceId: GroupID) {
    metadata {
      featureFlags(names: ["ai_user_model_switching"]) {
        enabled
        name
      }
      version
    }

    aiChatAvailableModels(projectId: $projectId, rootNamespaceId: $rootNamespaceId) {
      defaultModel {
        name
        ref
      }
      selectableModels {
        name
        ref
      }
      pinnedModel {
        name
        ref
      }
    }
  }
`;

// ---------------------------------------------------------------------------
// Client
// ---------------------------------------------------------------------------

const DISCOVERY_CACHE_TTL_MS = 10 * 60 * 1000;

interface CachedDiscovery {
  data: DiscoveredModels;
  expiresAt: number;
}

export class GitLabModelDiscovery {
  private readonly config: ModelDiscoveryConfig;
  private readonly fetchFn: typeof fetch;
  private cache = new Map<string, CachedDiscovery>();

  constructor(config: ModelDiscoveryConfig) {
    this.config = config;
    this.fetchFn = config.fetch ?? fetch;
  }

  /**
   * Discover available models for a given project or root namespace.
   *
   * Results are cached per scope with a 10-minute TTL.
   * Use `invalidateCache()` to force an immediate refresh.
   *
   * @param scope - `{ projectId }` (preferred), `{ rootNamespaceId }`, or a
   *   bare string (treated as `rootNamespaceId` for backwards compatibility)
   */
  async discover(scope: DiscoveryScope | string): Promise<DiscoveredModels> {
    const normalized = normalizeScope(scope);
    const cacheKey = scopeCacheKey(normalized);
    const cached = this.cache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data;
    }

    try {
      const result = await this.query(normalized);
      this.cache.set(cacheKey, {
        data: result,
        expiresAt: Date.now() + DISCOVERY_CACHE_TTL_MS,
      });
      return result;
    } catch (error) {
      // Older GitLab instances don't support projectId-scoped discovery.
      // Fall back to rootNamespaceId when the caller also supplied one.
      if ('projectId' in normalized && normalized.rootNamespaceId) {
        const fallbackScope: DiscoveryScope = { rootNamespaceId: normalized.rootNamespaceId };
        const result = await this.query(fallbackScope);
        this.cache.set(scopeCacheKey(fallbackScope), {
          data: result,
          expiresAt: Date.now() + DISCOVERY_CACHE_TTL_MS,
        });
        return result;
      }
      throw error;
    }
  }

  private async query(scope: DiscoveryScope): Promise<DiscoveredModels> {
    const url = `${this.config.instanceUrl}/api/graphql`;

    try {
      const response = await this.fetchFn(url, {
        method: 'POST',
        headers: {
          ...this.config.getHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: AI_CHAT_AVAILABLE_MODELS_QUERY,
          variables:
            'projectId' in scope
              ? { projectId: scope.projectId, rootNamespaceId: undefined }
              : { projectId: undefined, rootNamespaceId: scope.rootNamespaceId },
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new GitLabError({
          message: `Model discovery GraphQL request failed: ${response.status} ${response.statusText} - ${errorText}`,
          statusCode: response.status,
          responseBody: errorText,
        });
      }

      const json = (await response.json()) as {
        data?: {
          aiChatAvailableModels?: AiChatAvailableModels | null;
          metadata?: {
            featureFlags?: Array<{ name: string; enabled: boolean }>;
            version?: string;
          } | null;
        };
        errors?: Array<{ message: string }>;
      };

      if (json.errors && json.errors.length > 0) {
        throw new GitLabError({
          message: `Model discovery GraphQL errors: ${json.errors.map((e) => e.message).join(', ')}`,
        });
      }

      const models = json.data?.aiChatAvailableModels;
      const metadata = json.data?.metadata;

      // The `ai_user_model_switching` flag has been removed on newer GitLab
      // instances (rolled out permanently). Only treat model switching as
      // disabled when the flag is present and explicitly reports `false`.
      const flag = metadata?.featureFlags?.find((f) => f.name === 'ai_user_model_switching');
      const modelSwitchingEnabled = flag ? flag.enabled : true;

      return {
        defaultModel: models?.defaultModel ?? null,
        selectableModels: models?.selectableModels ?? [],
        pinnedModel: models?.pinnedModel ?? null,
        modelSwitchingEnabled,
        instanceVersion: metadata?.version ?? null,
      };
    } catch (error) {
      if (error instanceof GitLabError) throw error;
      throw new GitLabError({
        message: `Model discovery failed: ${error}`,
        cause: error,
      });
    }
  }

  /**
   * Get the effective model ref to use for a workflow.
   *
   * Priority: pinned > user-selected > default.
   *
   * @param scope - Project or root namespace to discover models for
   * @param userSelectedRef - Optional user preference
   */
  async getEffectiveModelRef(
    scope: DiscoveryScope | string,
    userSelectedRef?: string
  ): Promise<string | null> {
    const discovered = await this.discover(scope);

    // Pinned model always wins
    if (discovered.pinnedModel) {
      return discovered.pinnedModel.ref;
    }

    // User selection (if model switching is enabled)
    if (userSelectedRef && discovered.modelSwitchingEnabled) {
      const isValid = discovered.selectableModels.some((m) => m.ref === userSelectedRef);
      if (isValid) {
        return userSelectedRef;
      }
    }

    // Default
    return discovered.defaultModel?.ref ?? null;
  }

  /**
   * Invalidate the cached discovery results.
   */
  invalidateCache(): void {
    this.cache.clear();
  }
}
