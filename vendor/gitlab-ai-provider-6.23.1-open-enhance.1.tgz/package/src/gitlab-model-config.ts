/**
 * Fetches and caches model configuration from the GitLab AI Gateway's
 * models.yml definition file. Provides per-model context window and
 * output token limits keyed by `gitlab_identifier`.
 *
 * Results are cached both in memory and on disk at
 * `~/.cache/opencode/gitlab-model-configs.json`
 * (or `$XDG_CACHE_HOME/opencode/...` when set).
 *
 * @see https://gitlab.com/gitlab-org/modelops/applied-ml/code-suggestions/ai-assist/-/blob/main/ai_gateway/model_selection/models.yml
 */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { GitLabError } from './gitlab-error';

export interface ModelConfig {
  /** Maximum input context tokens */
  context: number;
  /** Maximum output tokens (from params.max_tokens) */
  output: number;
}

export interface ModelConfigRegistryOptions {
  /** Override the URL to fetch models.yml from */
  url?: string;
  /** Cache TTL in milliseconds (default: 24 hours) */
  ttlMs?: number;
  /** Custom fetch implementation */
  fetch?: typeof fetch;
}

const DEFAULT_MODELS_YML_URL =
  'https://gitlab.com/gitlab-org/modelops/applied-ml/code-suggestions/ai-assist/-/raw/main/ai_gateway/model_selection/models.yml';
const DEFAULT_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

const DEFAULT_CONTEXT = 200_000;
const DEFAULT_OUTPUT = 64_000;

// ---------------------------------------------------------------------------
// File cache
// ---------------------------------------------------------------------------

interface CacheFile {
  configs: Record<string, ModelConfig>;
  updatedAt: string;
}

interface FileCacheResult {
  configs: Map<string, ModelConfig>;
  writtenAt: number;
}

function getCacheFilePath(): string {
  const cacheHome = process.env.XDG_CACHE_HOME || path.join(os.homedir(), '.cache');
  return path.join(cacheHome, 'opencode', 'gitlab-model-configs.json');
}

function readCacheFile(): CacheFile | null {
  try {
    const filePath = getCacheFilePath();
    if (!fs.existsSync(filePath)) return null;
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw) as CacheFile;
  } catch {
    return null;
  }
}

function writeCacheFile(configs: Map<string, ModelConfig>): void {
  try {
    const filePath = getCacheFilePath();
    const dir = path.dirname(filePath);
    fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const data: CacheFile = {
      configs: Object.fromEntries(configs),
      updatedAt: new Date().toISOString(),
    };
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), { mode: 0o600 });
  } catch {
    // Best-effort — cache write failures are non-fatal
  }
}

function loadCacheFile(ttlMs: number): FileCacheResult | null {
  const cached = readCacheFile();
  if (!cached) return null;
  const writtenAt = new Date(cached.updatedAt).getTime();
  const age = Date.now() - writtenAt;
  if (age > ttlMs) return null;
  return { configs: new Map(Object.entries(cached.configs)), writtenAt };
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------

export class GitLabModelConfigRegistry {
  private readonly url: string;
  private readonly ttlMs: number;
  private readonly fetchFn: typeof fetch;
  private memCache: Map<string, ModelConfig> | null = null;
  private memExpiresAt = 0;
  private pending: Promise<Map<string, ModelConfig>> | null = null;

  constructor(options?: ModelConfigRegistryOptions) {
    this.url = options?.url ?? DEFAULT_MODELS_YML_URL;
    this.ttlMs = options?.ttlMs ?? DEFAULT_TTL_MS;
    this.fetchFn = options?.fetch ?? fetch;
  }

  /**
   * Get model configs, fetching and caching as needed.
   * Returns a Map keyed by `gitlab_identifier` (the discovery `ref`).
   */
  async getConfigs(): Promise<Map<string, ModelConfig>> {
    // 1. In-memory cache
    if (this.memCache && Date.now() < this.memExpiresAt) {
      return this.memCache;
    }

    // 2. File cache
    const fileCached = loadCacheFile(this.ttlMs);
    if (fileCached) {
      this.memCache = fileCached.configs;
      this.memExpiresAt = fileCached.writtenAt + this.ttlMs;
      return fileCached.configs;
    }

    // 3. Fetch (deduplicate concurrent requests)
    if (this.pending) return this.pending;

    this.pending = this.fetchConfigs();
    try {
      return await this.pending;
    } finally {
      this.pending = null;
    }
  }

  /**
   * Look up config for a single model ref.
   * Returns defaults if the ref is not found or fetch fails.
   */
  async getConfig(ref: string): Promise<ModelConfig> {
    const configs = await this.getConfigs();
    return configs.get(ref) ?? { context: DEFAULT_CONTEXT, output: DEFAULT_OUTPUT };
  }

  /** Invalidate both in-memory and file caches. */
  invalidateCache(): void {
    this.memCache = null;
    this.memExpiresAt = 0;
    try {
      const filePath = getCacheFilePath();
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch {
      // Best-effort
    }
  }

  private async fetchConfigs(): Promise<Map<string, ModelConfig>> {
    try {
      const res = await this.fetchFn(this.url);
      if (!res.ok) {
        throw new GitLabError({
          message: `Failed to fetch model configs: HTTP ${res.status}`,
          statusCode: res.status,
        });
      }
      const text = await res.text();
      const configs = parseModelsYml(text);

      // Persist to memory + disk
      this.memCache = configs;
      this.memExpiresAt = Date.now() + this.ttlMs;
      writeCacheFile(configs);

      return configs;
    } catch (error) {
      console.warn(
        `gitlab-ai-provider: model config fetch failed (${
          error instanceof Error ? error.message : String(error)
        }); falling back to cached or default model limits`
      );
      // Return stale memory/file cache on failure, or empty map
      return this.memCache ?? loadCacheFile(Infinity)?.configs ?? new Map();
    }
  }
}

/**
 * Parse models.yml to extract gitlab_identifier → { context, output } mapping.
 * Uses simple line-by-line parsing to avoid a YAML dependency.
 */
export function parseModelsYml(text: string): Map<string, ModelConfig> {
  const configs = new Map<string, ModelConfig>();
  let currentIdentifier: string | null = null;
  let currentContext = 0;
  let currentOutput = 0;
  let inParams = false;
  let paramsIndent = -1;

  for (const line of text.split('\n')) {
    const idMatch = line.match(/^\s*gitlab_identifier:\s*"?([^"#\s]+)"?/);
    if (idMatch) {
      if (currentIdentifier) {
        configs.set(currentIdentifier, {
          context: currentContext || DEFAULT_CONTEXT,
          output: currentOutput || DEFAULT_OUTPUT,
        });
      }
      currentIdentifier = idMatch[1];
      currentContext = 0;
      currentOutput = 0;
      inParams = false;
      paramsIndent = -1;
    }

    const ctxMatch = line.match(/^\s*max_context_tokens:\s*([0-9_]+)/);
    if (ctxMatch && currentIdentifier) {
      currentContext = parseInt(ctxMatch[1].replace(/_/g, ''), 10);
    }

    if (/^\s*params:\s*$/.test(line)) {
      inParams = true;
      paramsIndent = line.match(/^(\s*)/)?.[1].length ?? 0;
    } else if (inParams && /^\s*\S+:/.test(line)) {
      const indent = line.match(/^(\s*)/)?.[1].length ?? 0;
      if (indent <= paramsIndent) {
        inParams = false;
        paramsIndent = -1;
      }
    }

    if (inParams) {
      const maxTokensMatch = line.match(/^\s*max_tokens:\s*([0-9_]+)/);
      if (maxTokensMatch && currentIdentifier) {
        currentOutput = parseInt(maxTokensMatch[1].replace(/_/g, ''), 10);
      }
    }
  }

  if (currentIdentifier) {
    configs.set(currentIdentifier, {
      context: currentContext || DEFAULT_CONTEXT,
      output: currentOutput || DEFAULT_OUTPUT,
    });
  }

  return configs;
}
