import OpenAI from 'openai';
import { GitLabDirectAccessClient } from './gitlab-direct-access';
import { GitLabError } from './gitlab-error';
import { isResponsesApiModel } from './model-mappings';

import type {
  LanguageModelV3,
  LanguageModelV3CallOptions,
  LanguageModelV3StreamPart,
  LanguageModelV3FinishReason,
  LanguageModelV3Content,
  LanguageModelV3Usage,
  LanguageModelV3FunctionTool,
  LanguageModelV3Message,
  LanguageModelV3ToolChoice,
} from '@ai-sdk/provider';

export interface GitLabOpenAIConfig {
  provider: string;
  instanceUrl: string;
  getHeaders: () => Record<string, string>;
  fetch?: typeof fetch;
  ensureApiKey?: () => Promise<void>;
  refreshApiKey?: () => Promise<void>;
  openaiModel?: string;
  maxTokens?: number;
  reasoningEffort?: 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max';
  featureFlags?: {
    DuoAgentPlatformNext: true;
  } & Record<string, boolean>;
  aiGatewayUrl?: string;
  directAccessCacheDir?: string;
  /** Whether to use the Responses API instead of Chat Completions API */
  useResponsesApi?: boolean;
  /**
   * Custom headers for AI Gateway OpenAI proxy requests.
   * Merged with headers from direct_access token response.
   */
  aiGatewayHeaders?: Record<string, string>;
}

export class GitLabOpenAILanguageModel implements LanguageModelV3 {
  readonly specificationVersion = 'v3' as const;
  readonly modelId: string;
  readonly supportedUrls: Record<string, RegExp[]> = {};

  private readonly config: GitLabOpenAIConfig;
  private readonly directAccessClient: GitLabDirectAccessClient;
  private readonly useResponsesApi: boolean;
  private openaiClient: OpenAI | null = null;

  constructor(modelId: string, config: GitLabOpenAIConfig) {
    this.modelId = modelId;
    this.config = config;
    this.useResponsesApi = config.useResponsesApi ?? isResponsesApiModel(modelId);

    this.directAccessClient = new GitLabDirectAccessClient({
      instanceUrl: config.instanceUrl,
      getHeaders: config.getHeaders,
      ensureApiKey: config.ensureApiKey,
      refreshApiKey: config.refreshApiKey,
      fetch: config.fetch,
      featureFlags: config.featureFlags,
      aiGatewayUrl: config.aiGatewayUrl,
      directAccessCacheDir: config.directAccessCacheDir,
    });
  }

  get provider(): string {
    return this.config.provider;
  }

  private async getOpenAIClient(forceRefresh: boolean = false): Promise<OpenAI> {
    const tokenData = await this.directAccessClient.getDirectAccessToken(forceRefresh);
    const { 'x-api-key': _removed, ...filteredHeaders } = tokenData.headers;

    // Merge: tokenData headers < custom aiGatewayHeaders
    const mergedHeaders = {
      ...filteredHeaders,
      ...this.config.aiGatewayHeaders,
    };

    this.openaiClient = new OpenAI({
      apiKey: tokenData.token,
      baseURL: this.directAccessClient.getOpenAIProxyUrl(),
      defaultHeaders: mergedHeaders,
    });

    return this.openaiClient;
  }

  private isTokenError(error: unknown): boolean {
    if (error instanceof OpenAI.APIError) {
      if (error.status === 401) {
        return true;
      }
      const message = error.message?.toLowerCase() || '';
      if (
        message.includes('token') &&
        (message.includes('expired') || message.includes('revoked') || message.includes('invalid'))
      ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check if an error is a context overflow error (prompt too long)
   * These should NOT trigger token refresh and should be reported to the user.
   */
  private isContextOverflowError(error: unknown): boolean {
    if (error instanceof OpenAI.APIError) {
      // 400 Bad Request with prompt too long message
      if (error.status === 400) {
        const message = error.message?.toLowerCase() || '';
        if (
          message.includes('prompt is too long') ||
          message.includes('prompt too long') ||
          (message.includes('tokens') && message.includes('maximum'))
        ) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Build a descriptive error message from an OpenAI APIError.
   *
   * The AI Gateway proxy often returns errors with empty bodies, which the
   * OpenAI SDK renders as "500 status code (no body)". This helper surfaces
   * everything that is actually available: the parsed error body, the
   * request ID for support, and — for 5xx responses with a large tool set —
   * a hint that the gateway may be rejecting the request due to tool count.
   */
  private formatOpenAIError(
    error: InstanceType<typeof OpenAI.APIError>,
    toolCount?: number
  ): string {
    const parts: string[] = [`OpenAI API error: ${error.message}`];

    const body = error.error as unknown;
    if (body) {
      const detail =
        typeof body === 'string'
          ? body
          : ((body as Record<string, unknown>).message ??
            (body as Record<string, unknown>).detail ??
            (body as Record<string, unknown>).error);
      if (detail && !error.message.includes(String(detail))) {
        parts.push(`detail: ${typeof detail === 'string' ? detail : JSON.stringify(detail)}`);
      }
    }

    const headers = error.headers as { get?: (name: string) => string | null } | undefined;
    const requestId =
      typeof headers?.get === 'function'
        ? (headers.get('x-request-id') ?? headers.get('x-amzn-requestid'))
        : undefined;
    if (requestId) {
      parts.push(`request-id: ${requestId}`);
    }

    const isOpaque = error.message?.includes('no body');
    if (
      error.status != null &&
      error.status >= 400 &&
      isOpaque &&
      toolCount != null &&
      toolCount > 20
    ) {
      parts.push(
        `Hint: the request included ${toolCount} tools; the GitLab AI Gateway may reject ` +
          'large tool sets — try reducing the number of enabled tools or MCP servers.'
      );
    }

    return parts.join(' | ');
  }

  /**
   * Per-call `providerOptions.gitlab.reasoningEffort` takes precedence over the
   * model-level default.
   */
  private resolveReasoningEffort(
    options: LanguageModelV3CallOptions
  ): GitLabOpenAIConfig['reasoningEffort'] {
    const gitlabOptions = (options.providerOptions as Record<string, unknown> | undefined)?.[
      'gitlab'
    ] as Record<string, unknown> | undefined;
    return (
      (gitlabOptions?.reasoningEffort as GitLabOpenAIConfig['reasoningEffort']) ??
      this.config.reasoningEffort
    );
  }

  private asOpenAIReasoningEffort(
    effort: NonNullable<GitLabOpenAIConfig['reasoningEffort']>
  ): OpenAI.ReasoningEffort {
    // The API supports `max`, but the pinned OpenAI SDK's ReasoningEffort type
    // predates it. Keep the compatibility cast isolated at serialization.
    return effort as OpenAI.ReasoningEffort;
  }

  private convertTools(
    tools?: LanguageModelV3CallOptions['tools']
  ): OpenAI.ChatCompletionTool[] | undefined {
    if (!tools || tools.length === 0) {
      return undefined;
    }

    return tools
      .filter((tool): tool is LanguageModelV3FunctionTool => tool.type === 'function')
      .map((tool) => {
        const schema = tool.inputSchema as Record<string, unknown>;
        return {
          type: 'function' as const,
          function: {
            name: tool.name,
            description: tool.description || '',
            // Ensure the schema has type: 'object' as OpenAI requires it
            parameters: {
              type: 'object',
              ...schema,
            },
          },
        };
      });
  }

  private convertToolChoice(
    toolChoice?: LanguageModelV3ToolChoice
  ): OpenAI.ChatCompletionToolChoiceOption | undefined {
    if (!toolChoice) {
      return undefined;
    }

    switch (toolChoice.type) {
      case 'auto':
        return 'auto';
      case 'none':
        return 'none';
      case 'required':
        return 'required';
      case 'tool':
        return { type: 'function', function: { name: toolChoice.toolName } };
      default:
        return undefined;
    }
  }

  private convertPrompt(prompt: LanguageModelV3Message[]): OpenAI.ChatCompletionMessageParam[] {
    const messages: OpenAI.ChatCompletionMessageParam[] = [];

    for (const message of prompt) {
      if (message.role === 'system') {
        messages.push({ role: 'system', content: message.content });
        continue;
      }

      if (message.role === 'user') {
        const textParts = message.content
          .filter((part) => part.type === 'text')
          .map((part) => part.text);
        if (textParts.length > 0) {
          messages.push({ role: 'user', content: textParts.join('\n') });
        }
      } else if (message.role === 'assistant') {
        const textParts: string[] = [];
        const toolCalls: OpenAI.ChatCompletionMessageToolCall[] = [];

        for (const part of message.content) {
          if (part.type === 'text') {
            textParts.push(part.text);
          } else if (part.type === 'tool-call') {
            toolCalls.push({
              id: part.toolCallId,
              type: 'function',
              function: {
                name: part.toolName,
                arguments: typeof part.input === 'string' ? part.input : JSON.stringify(part.input),
              },
            });
          }
        }

        const assistantMessage: OpenAI.ChatCompletionAssistantMessageParam = {
          role: 'assistant',
          content: textParts.length > 0 ? textParts.join('\n') : null,
        };
        if (toolCalls.length > 0) {
          assistantMessage.tool_calls = toolCalls;
        }
        messages.push(assistantMessage);
      } else if (message.role === 'tool') {
        for (const part of message.content) {
          if (part.type === 'tool-result') {
            let resultContent: string;
            if (part.output.type === 'text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'content') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'error-text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'error-json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'execution-denied') {
              resultContent = part.output.reason ?? 'Tool execution denied.';
            } else {
              resultContent = JSON.stringify(part.output);
            }
            messages.push({
              role: 'tool',
              tool_call_id: part.toolCallId,
              content: resultContent,
            });
          }
        }
      }
    }

    return messages;
  }

  private convertFinishReason(
    finishReason: string | null | undefined
  ): LanguageModelV3FinishReason {
    const unified: LanguageModelV3FinishReason['unified'] = (() => {
      switch (finishReason) {
        case 'stop':
          return 'stop';
        case 'length':
          return 'length';
        case 'tool_calls':
          return 'tool-calls';
        case 'content_filter':
          return 'content-filter';
        default:
          return 'other';
      }
    })();

    return { unified, raw: finishReason ?? undefined };
  }

  private createUsage(params?: {
    inputTotal?: number;
    outputTotal?: number;
    outputReasoning?: number;
    cacheRead?: number;
    raw?: LanguageModelV3Usage['raw'];
  }): LanguageModelV3Usage {
    const inputTotal = params?.inputTotal;
    const outputTotal = params?.outputTotal;
    const cacheRead = params?.cacheRead;

    return {
      inputTokens: {
        total: inputTotal,
        noCache: inputTotal == null ? undefined : Math.max(0, inputTotal - (cacheRead ?? 0)),
        cacheRead,
        cacheWrite: undefined,
      },
      outputTokens: {
        total: outputTotal,
        text: outputTotal != null ? outputTotal - (params?.outputReasoning ?? 0) : undefined,
        reasoning: params?.outputReasoning,
      },
      raw: params?.raw,
    };
  }

  /**
   * Convert tools to Responses API format
   */
  private convertToolsForResponses(
    tools?: LanguageModelV3CallOptions['tools']
  ): OpenAI.Responses.FunctionTool[] | undefined {
    if (!tools || tools.length === 0) {
      return undefined;
    }

    return tools
      .filter((tool): tool is LanguageModelV3FunctionTool => tool.type === 'function')
      .map((tool) => {
        // Clone schema and remove $schema field which can confuse the model
        // Zod 4's toJSONSchema() adds "$schema": "https://json-schema.org/draft/2020-12/schema"
        const schema = { ...(tool.inputSchema as Record<string, unknown>) };
        delete schema['$schema'];

        return {
          type: 'function' as const,
          name: tool.name,
          description: tool.description || '',
          parameters: schema,
          // Responses may normalize schemas into strict mode when this field is omitted.
          strict: tool.strict ?? false,
        };
      });
  }

  /**
   * Convert prompt to Responses API input format
   */
  private convertPromptForResponses(
    prompt: LanguageModelV3Message[]
  ): OpenAI.Responses.ResponseInput {
    const items: OpenAI.Responses.ResponseInputItem[] = [];

    for (const message of prompt) {
      if (message.role === 'system') {
        // System messages become instructions, handled separately
        continue;
      }

      if (message.role === 'user') {
        const textParts = message.content
          .filter((part) => part.type === 'text')
          .map((part) => part.text);
        if (textParts.length > 0) {
          items.push({
            type: 'message',
            role: 'user',
            content: textParts.map((text) => ({ type: 'input_text' as const, text })),
          } as OpenAI.Responses.ResponseInputItem);
        }
      } else if (message.role === 'assistant') {
        // Replay assistant history as an input message, not an output resource
        // (output resources require server-assigned id and status fields).
        const textParts: string[] = [];
        for (const part of message.content) {
          if (part.type === 'text') {
            textParts.push(part.text);
          } else if (part.type === 'tool-call') {
            // Tool calls are function_call items in Responses API
            items.push({
              type: 'function_call',
              call_id: part.toolCallId,
              name: part.toolName,
              arguments: typeof part.input === 'string' ? part.input : JSON.stringify(part.input),
            } as OpenAI.Responses.ResponseInputItem);
          }
        }

        if (textParts.length > 0) {
          items.push({
            type: 'message',
            role: 'assistant',
            content: textParts.join('\n'),
          });
        }
      } else if (message.role === 'tool') {
        for (const part of message.content) {
          if (part.type === 'tool-result') {
            let resultContent: string;
            if (part.output.type === 'text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'content') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'error-text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'error-json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'execution-denied') {
              resultContent = part.output.reason ?? 'Tool execution denied.';
            } else {
              resultContent = JSON.stringify(part.output);
            }
            items.push({
              type: 'function_call_output',
              call_id: part.toolCallId,
              output: resultContent,
            } as OpenAI.Responses.ResponseInputItem);
          }
        }
      }
    }

    return items;
  }

  /**
   * Extract system instructions from prompt
   */
  private extractSystemInstructions(prompt: LanguageModelV3Message[]): string | undefined {
    const systemMessages = prompt
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n');
    return systemMessages || undefined;
  }

  /**
   * Convert Responses API status to finish reason
   * Note: Responses API returns 'completed' even when making tool calls,
   * so we need to check the content for tool calls separately.
   */
  private convertResponsesStatus(
    status: string | undefined,
    hasToolCalls: boolean = false
  ): LanguageModelV3FinishReason {
    // If we have tool calls, return 'tool-calls' regardless of status
    if (hasToolCalls) {
      return { unified: 'tool-calls', raw: status };
    }

    const unified: LanguageModelV3FinishReason['unified'] = (() => {
      switch (status) {
        case 'completed':
          return 'stop';
        case 'incomplete':
          return 'length';
        case 'cancelled':
          return 'stop';
        case 'failed':
          return 'error';
        default:
          return 'other';
      }
    })();

    return { unified, raw: status };
  }

  async doGenerate(options: LanguageModelV3CallOptions): Promise<{
    content: LanguageModelV3Content[];
    finishReason: LanguageModelV3FinishReason;
    usage: LanguageModelV3Usage;
    warnings: [];
  }> {
    if (this.useResponsesApi) {
      return this.doGenerateWithResponsesApi(options, false);
    }
    return this.doGenerateWithChatApi(options, false);
  }

  private async doGenerateWithChatApi(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    content: LanguageModelV3Content[];
    finishReason: LanguageModelV3FinishReason;
    usage: LanguageModelV3Usage;
    warnings: [];
  }> {
    const client = await this.getOpenAIClient(isRetry);
    const messages = this.convertPrompt(options.prompt);
    const toolsDisabled = options.toolChoice?.type === 'none';
    const tools = toolsDisabled ? undefined : this.convertTools(options.tools);
    const toolChoice = toolsDisabled ? undefined : this.convertToolChoice(options.toolChoice);

    const openaiModel = this.config.openaiModel || 'gpt-4o';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const reasoningEffort = this.resolveReasoningEffort(options);

    const generateParams = {
      model: openaiModel,
      max_completion_tokens: maxTokens,
      messages: messages,
      tools: tools,
      tool_choice: tools ? toolChoice : undefined,
      temperature: options.temperature,
      top_p: options.topP,
      stop: options.stopSequences,
      ...(reasoningEffort && {
        reasoning_effort: this.asOpenAIReasoningEffort(reasoningEffort),
      }),
    };

    try {
      const response = options.abortSignal
        ? await client.chat.completions.create(generateParams, { signal: options.abortSignal })
        : await client.chat.completions.create(generateParams);

      const choice = response.choices[0];
      const content: LanguageModelV3Content[] = [];

      if (choice?.message.content) {
        content.push({ type: 'text', text: choice.message.content });
      }

      if (choice?.message.tool_calls) {
        for (const toolCall of choice.message.tool_calls) {
          if (toolCall.type === 'function') {
            content.push({
              type: 'tool-call',
              toolCallId: toolCall.id,
              toolName: toolCall.function.name,
              input: toolCall.function.arguments,
            });
          }
        }
      }

      const usage = this.createUsage({
        inputTotal: response.usage?.prompt_tokens,
        outputTotal: response.usage?.completion_tokens,
        cacheRead: response.usage?.prompt_tokens_details?.cached_tokens,
        raw: { total_tokens: response.usage?.total_tokens },
      });

      return {
        content,
        finishReason: this.convertFinishReason(choice?.finish_reason),
        usage,
        warnings: [],
      };
    } catch (error) {
      // Check for context overflow FIRST - these should NOT trigger token refresh
      if (this.isContextOverflowError(error)) {
        const apiError = error as InstanceType<typeof OpenAI.APIError>;
        throw new GitLabError({
          message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
          statusCode: 400,
          cause: error,
        });
      }

      if (!isRetry && this.isTokenError(error)) {
        this.directAccessClient.invalidateToken();
        return this.doGenerateWithChatApi(options, true);
      }

      if (error instanceof OpenAI.APIError) {
        throw new GitLabError({
          message: this.formatOpenAIError(error, tools?.length),
          statusCode: error.status,
          cause: error,
        });
      }
      throw error;
    }
  }

  private async doGenerateWithResponsesApi(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    content: LanguageModelV3Content[];
    finishReason: LanguageModelV3FinishReason;
    usage: LanguageModelV3Usage;
    warnings: [];
  }> {
    const client = await this.getOpenAIClient(isRetry);
    const input = this.convertPromptForResponses(options.prompt);
    const tools =
      options.toolChoice?.type === 'none'
        ? undefined
        : this.convertToolsForResponses(options.tools);
    const instructions = this.extractSystemInstructions(options.prompt);

    const openaiModel = this.config.openaiModel || 'gpt-5-codex';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const reasoningEffort = this.resolveReasoningEffort(options);

    const generateParams = {
      model: openaiModel,
      input,
      instructions,
      tools,
      max_output_tokens: maxTokens,
      temperature: options.temperature,
      top_p: options.topP,
      store: false,
      ...(reasoningEffort && {
        // `summary: 'auto'` opts into visible reasoning summary text.
        // Without it, the Responses API never returns summary content —
        // the model still reasons and effort still affects behavior, but
        // no chain-of-thought text comes back (mirrors the Anthropic
        // `thinking.display` gap fixed in buildThinkingParams).
        reasoning: {
          effort: this.asOpenAIReasoningEffort(reasoningEffort),
          summary: 'auto' as const,
        },
      }),
    };

    try {
      const response = options.abortSignal
        ? await client.responses.create(generateParams, { signal: options.abortSignal })
        : await client.responses.create(generateParams);

      const content: LanguageModelV3Content[] = [];
      let hasToolCalls = false;

      // Process output items
      for (const item of response.output || []) {
        if (item.type === 'message' && item.role === 'assistant') {
          for (const contentItem of item.content || []) {
            if (contentItem.type === 'output_text') {
              content.push({ type: 'text', text: contentItem.text });
            }
          }
        } else if (item.type === 'function_call') {
          hasToolCalls = true;
          content.push({
            type: 'tool-call',
            toolCallId: item.call_id,
            toolName: item.name,
            input: item.arguments,
          });
        } else if (item.type === 'reasoning') {
          for (const summary of item.summary || []) {
            if (summary.type === 'summary_text' && summary.text) {
              content.push({ type: 'reasoning', text: summary.text });
            }
          }
        }
      }

      const usage = this.createUsage({
        inputTotal: response.usage?.input_tokens,
        outputTotal: response.usage?.output_tokens,
        outputReasoning: response.usage?.output_tokens_details?.reasoning_tokens,
        cacheRead: response.usage?.input_tokens_details?.cached_tokens,
        raw: { total_tokens: response.usage?.total_tokens },
      });

      return {
        content,
        finishReason: this.convertResponsesStatus(response.status, hasToolCalls),
        usage,
        warnings: [],
      };
    } catch (error) {
      // Check for context overflow FIRST - these should NOT trigger token refresh
      if (this.isContextOverflowError(error)) {
        const apiError = error as InstanceType<typeof OpenAI.APIError>;
        throw new GitLabError({
          message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
          statusCode: 400,
          cause: error,
        });
      }

      if (!isRetry && this.isTokenError(error)) {
        this.directAccessClient.invalidateToken();
        return this.doGenerateWithResponsesApi(options, true);
      }

      if (error instanceof OpenAI.APIError) {
        throw new GitLabError({
          message: this.formatOpenAIError(error, tools?.length),
          statusCode: error.status,
          cause: error,
        });
      }
      throw error;
    }
  }

  async doStream(options: LanguageModelV3CallOptions): Promise<{
    stream: ReadableStream<LanguageModelV3StreamPart>;
    request?: { body?: unknown };
    response?: { headers?: Record<string, string> };
  }> {
    if (this.useResponsesApi) {
      return this.doStreamWithResponsesApi(options, false);
    }
    return this.doStreamWithChatApi(options, false);
  }

  private async doStreamWithChatApi(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    stream: ReadableStream<LanguageModelV3StreamPart>;
    request?: { body?: unknown };
    response?: { headers?: Record<string, string> };
  }> {
    const client = await this.getOpenAIClient(isRetry);
    const messages = this.convertPrompt(options.prompt);
    const toolsDisabled = options.toolChoice?.type === 'none';
    const tools = toolsDisabled ? undefined : this.convertTools(options.tools);
    const toolChoice = toolsDisabled ? undefined : this.convertToolChoice(options.toolChoice);

    const openaiModel = this.config.openaiModel || 'gpt-4o';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const reasoningEffort = this.resolveReasoningEffort(options);

    const requestBody = {
      model: openaiModel,
      max_completion_tokens: maxTokens,
      messages: messages,
      tools: tools,
      tool_choice: tools ? toolChoice : undefined,
      temperature: options.temperature,
      top_p: options.topP,
      stop: options.stopSequences,
      ...(reasoningEffort && {
        reasoning_effort: this.asOpenAIReasoningEffort(reasoningEffort),
      }),
      stream: true as const,
      stream_options: { include_usage: true },
    };

    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;

    const abortController = new AbortController();
    if (options.abortSignal) {
      if (options.abortSignal.aborted) {
        abortController.abort(options.abortSignal.reason);
      } else {
        options.abortSignal.addEventListener('abort', () =>
          abortController.abort(options.abortSignal?.reason)
        );
      }
    }
    let streamClosed = false;

    const stream = new ReadableStream<LanguageModelV3StreamPart>({
      cancel: () => {
        streamClosed = true;
        abortController.abort();
      },
      start: async (controller) => {
        const safeEnqueue = (part: LanguageModelV3StreamPart) => {
          if (streamClosed) return;
          try {
            controller.enqueue(part);
          } catch {
            streamClosed = true;
          }
        };
        const safeClose = () => {
          if (streamClosed) return;
          streamClosed = true;
          try {
            controller.close();
          } catch {
            // already closed
          }
        };

        const toolCalls: Record<number, { id: string; name: string; arguments: string }> = {};

        let usage = self.createUsage();
        let finishReason: LanguageModelV3FinishReason = { unified: 'other', raw: undefined };
        let textStarted = false;
        let metadataEmitted = false;
        let contentEmitted = false;
        const textId = 'text-0';

        try {
          const openaiStream = await client.chat.completions.create(
            {
              ...requestBody,
              stream: true,
            },
            { signal: abortController.signal }
          );

          safeEnqueue({ type: 'stream-start', warnings: [] });

          for await (const chunk of openaiStream) {
            const choice = chunk.choices?.[0];

            if (chunk.id && !metadataEmitted) {
              metadataEmitted = true;
              safeEnqueue({
                type: 'response-metadata',
                id: chunk.id,
                modelId: chunk.model,
              });
            }

            if (choice?.delta?.content) {
              contentEmitted = true;
              if (!textStarted) {
                safeEnqueue({ type: 'text-start', id: textId });
                textStarted = true;
              }
              safeEnqueue({
                type: 'text-delta',
                id: textId,
                delta: choice.delta.content,
              });
            }

            if (choice?.delta?.tool_calls) {
              contentEmitted = true;
              for (const tc of choice.delta.tool_calls) {
                const idx = tc.index;
                if (!toolCalls[idx]) {
                  toolCalls[idx] = {
                    id: tc.id || '',
                    name: tc.function?.name || '',
                    arguments: '',
                  };
                  safeEnqueue({
                    type: 'tool-input-start',
                    id: toolCalls[idx].id,
                    toolName: toolCalls[idx].name,
                  });
                } else {
                  if (tc.id && !toolCalls[idx].id) {
                    toolCalls[idx].id = tc.id;
                  }
                  if (tc.function?.name && !toolCalls[idx].name) {
                    toolCalls[idx].name = tc.function.name;
                  }
                }
                if (tc.function?.arguments) {
                  toolCalls[idx].arguments += tc.function.arguments;
                  safeEnqueue({
                    type: 'tool-input-delta',
                    id: toolCalls[idx].id,
                    delta: tc.function.arguments,
                  });
                }
              }
            }

            if (choice?.finish_reason) {
              finishReason = self.convertFinishReason(choice.finish_reason);
            }

            if (chunk.usage) {
              usage = self.createUsage({
                inputTotal: chunk.usage.prompt_tokens,
                outputTotal: chunk.usage.completion_tokens,
                cacheRead: chunk.usage.prompt_tokens_details?.cached_tokens,
                raw: { total_tokens: chunk.usage.total_tokens },
              });
            }
          }

          if (textStarted) {
            safeEnqueue({ type: 'text-end', id: textId });
          }

          for (const [, tc] of Object.entries(toolCalls)) {
            safeEnqueue({ type: 'tool-input-end', id: tc.id });
            safeEnqueue({
              type: 'tool-call',
              toolCallId: tc.id,
              toolName: tc.name,
              input: tc.arguments || '{}',
            });
          }

          safeEnqueue({ type: 'finish', finishReason, usage });
          safeClose();
        } catch (error) {
          // Check for context overflow FIRST - these should NOT trigger token refresh
          if (self.isContextOverflowError(error)) {
            const apiError = error as InstanceType<typeof OpenAI.APIError>;
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
                statusCode: 400,
                cause: error,
              }),
            });
            safeClose();
            return;
          }

          if (!isRetry && self.isTokenError(error)) {
            self.directAccessClient.invalidateToken();
            if (!contentEmitted) {
              try {
                const retried = await self.doStreamWithChatApi(options, true);
                const reader = retried.stream.getReader();
                for (;;) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  if (value.type === 'stream-start') continue;
                  safeEnqueue(value);
                }
                safeClose();
                return;
              } catch (retryError) {
                safeEnqueue({
                  type: 'error',
                  error:
                    retryError instanceof GitLabError
                      ? retryError
                      : new GitLabError({
                          message: 'Token refresh retry failed',
                          cause: retryError,
                        }),
                });
                safeClose();
                return;
              }
            }
            safeEnqueue({
              type: 'error',
              error: new GitLabError({ message: 'TOKEN_REFRESH_NEEDED', cause: error }),
            });
            safeClose();
            return;
          }

          if (error instanceof OpenAI.APIError) {
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: self.formatOpenAIError(error, tools?.length),
                statusCode: error.status,
                cause: error,
              }),
            });
          } else {
            safeEnqueue({ type: 'error', error });
          }
          safeClose();
        }
      },
    });

    return { stream, request: { body: requestBody } };
  }

  private async doStreamWithResponsesApi(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    stream: ReadableStream<LanguageModelV3StreamPart>;
    request?: { body?: unknown };
    response?: { headers?: Record<string, string> };
  }> {
    const client = await this.getOpenAIClient(isRetry);
    const input = this.convertPromptForResponses(options.prompt);
    const tools =
      options.toolChoice?.type === 'none'
        ? undefined
        : this.convertToolsForResponses(options.tools);
    const instructions = this.extractSystemInstructions(options.prompt);

    const openaiModel = this.config.openaiModel || 'gpt-5-codex';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const reasoningEffort = this.resolveReasoningEffort(options);

    const requestBody = {
      model: openaiModel,
      input,
      instructions,
      tools,
      max_output_tokens: maxTokens,
      temperature: options.temperature,
      top_p: options.topP,
      store: false,
      ...(reasoningEffort && {
        // `summary: 'auto'` opts into visible reasoning summary text.
        // Without it, the Responses API never returns summary content —
        // the model still reasons and effort still affects behavior, but
        // no chain-of-thought text comes back (mirrors the Anthropic
        // `thinking.display` gap fixed in buildThinkingParams).
        reasoning: {
          effort: this.asOpenAIReasoningEffort(reasoningEffort),
          summary: 'auto' as const,
        },
      }),
      stream: true as const,
    };

    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;

    const abortController = new AbortController();
    if (options.abortSignal) {
      if (options.abortSignal.aborted) {
        abortController.abort(options.abortSignal.reason);
      } else {
        options.abortSignal.addEventListener('abort', () =>
          abortController.abort(options.abortSignal?.reason)
        );
      }
    }
    let streamClosed = false;

    const stream = new ReadableStream<LanguageModelV3StreamPart>({
      cancel: () => {
        streamClosed = true;
        abortController.abort();
      },
      start: async (controller) => {
        const safeEnqueue = (part: LanguageModelV3StreamPart) => {
          if (streamClosed) return;
          try {
            controller.enqueue(part);
          } catch {
            streamClosed = true;
          }
        };
        const safeClose = () => {
          if (streamClosed) return;
          streamClosed = true;
          try {
            controller.close();
          } catch {
            // already closed
          }
        };

        // Use output_index as key (like OpenCode does) to track tool calls across events
        const toolCalls: Record<number, { callId: string; name: string; arguments: string }> = {};
        const activeReasoning = new Set<string>();
        const knownReasoning = new Set<string>();
        const reasoningWithText = new Set<string>();
        let usage = self.createUsage();
        let finishReason: LanguageModelV3FinishReason = { unified: 'other', raw: undefined };
        let textStarted = false;
        let contentEmitted = false;
        const textId = 'text-0';

        const reasoningId = (outputIndex: number, summaryIndex: number) =>
          `reasoning-${outputIndex}-${summaryIndex}`;
        const startReasoning = (outputIndex: number, summaryIndex: number) => {
          const id = reasoningId(outputIndex, summaryIndex);
          if (!knownReasoning.has(id)) {
            knownReasoning.add(id);
            activeReasoning.add(id);
            contentEmitted = true;
            safeEnqueue({ type: 'reasoning-start', id });
          }
          return id;
        };
        const emitReasoningDelta = (outputIndex: number, summaryIndex: number, delta: string) => {
          const id = startReasoning(outputIndex, summaryIndex);
          if (activeReasoning.has(id) && delta) {
            reasoningWithText.add(id);
            safeEnqueue({ type: 'reasoning-delta', id, delta });
          }
        };
        const endReasoning = (outputIndex: number, summaryIndex: number) => {
          const id = reasoningId(outputIndex, summaryIndex);
          if (activeReasoning.delete(id)) {
            safeEnqueue({ type: 'reasoning-end', id });
          }
        };

        try {
          const openaiStream = await client.responses.create(
            {
              ...requestBody,
              stream: true,
            },
            { signal: abortController.signal }
          );

          safeEnqueue({ type: 'stream-start', warnings: [] });

          for await (const event of openaiStream) {
            // Handle different event types from Responses API streaming
            if (event.type === 'response.created') {
              safeEnqueue({
                type: 'response-metadata',
                id: event.response.id,
                modelId: event.response.model,
              });
            } else if (event.type === 'response.output_item.added') {
              // Track function calls when they start, keyed by output_index
              if (event.item.type === 'function_call') {
                contentEmitted = true;
                const outputIndex = event.output_index;
                const callId = event.item.call_id;
                toolCalls[outputIndex] = {
                  callId,
                  name: event.item.name,
                  arguments: '',
                };
                safeEnqueue({
                  type: 'tool-input-start',
                  id: callId,
                  toolName: event.item.name,
                });
              }
            } else if (event.type === 'response.reasoning_summary_part.added') {
              startReasoning(event.output_index, event.summary_index);
            } else if (event.type === 'response.reasoning_summary_text.delta') {
              emitReasoningDelta(event.output_index, event.summary_index, event.delta);
            } else if (event.type === 'response.reasoning_summary_text.done') {
              const id = startReasoning(event.output_index, event.summary_index);
              if (!reasoningWithText.has(id)) {
                emitReasoningDelta(event.output_index, event.summary_index, event.text);
              }
              endReasoning(event.output_index, event.summary_index);
            } else if (event.type === 'response.reasoning_summary_part.done') {
              const id = startReasoning(event.output_index, event.summary_index);
              if (!reasoningWithText.has(id)) {
                emitReasoningDelta(event.output_index, event.summary_index, event.part.text);
              }
              endReasoning(event.output_index, event.summary_index);
            } else if (
              event.type === 'response.output_item.done' &&
              event.item.type === 'reasoning'
            ) {
              const prefix = `reasoning-${event.output_index}-`;
              for (const id of [...activeReasoning]) {
                if (id.startsWith(prefix)) {
                  activeReasoning.delete(id);
                  safeEnqueue({ type: 'reasoning-end', id });
                }
              }
            } else if (event.type === 'response.output_text.delta') {
              contentEmitted = true;
              if (!textStarted) {
                safeEnqueue({ type: 'text-start', id: textId });
                textStarted = true;
              }
              safeEnqueue({
                type: 'text-delta',
                id: textId,
                delta: event.delta,
              });
            } else if (event.type === 'response.function_call_arguments.delta') {
              // Use output_index to find the tool call (like OpenCode)
              const outputIndex = event.output_index;
              const tc = toolCalls[outputIndex];
              if (tc) {
                tc.arguments += event.delta;
                safeEnqueue({
                  type: 'tool-input-delta',
                  id: tc.callId,
                  delta: event.delta,
                });
              }
            } else if (event.type === 'response.function_call_arguments.done') {
              const outputIndex = event.output_index;
              const tc = toolCalls[outputIndex];
              if (tc) {
                tc.arguments = event.arguments;
              }
            } else if (event.type === 'response.completed') {
              // Check if there are tool calls to determine finish reason
              const hasToolCalls = Object.keys(toolCalls).length > 0;
              finishReason = self.convertResponsesStatus(event.response.status, hasToolCalls);
              if (event.response.usage) {
                usage = self.createUsage({
                  inputTotal: event.response.usage.input_tokens,
                  outputTotal: event.response.usage.output_tokens,
                  outputReasoning: event.response.usage.output_tokens_details?.reasoning_tokens,
                  cacheRead: event.response.usage.input_tokens_details?.cached_tokens,
                  raw: { total_tokens: event.response.usage.total_tokens },
                });
              }
            }
          }

          for (const id of activeReasoning) {
            safeEnqueue({ type: 'reasoning-end', id });
          }
          activeReasoning.clear();

          if (textStarted) {
            safeEnqueue({ type: 'text-end', id: textId });
          }

          // Check if we have tool calls to set the correct finish reason
          const hasToolCalls = Object.keys(toolCalls).length > 0;
          if (hasToolCalls && finishReason.unified === 'stop') {
            finishReason = { unified: 'tool-calls', raw: finishReason.raw };
          }

          for (const tc of Object.values(toolCalls)) {
            safeEnqueue({ type: 'tool-input-end', id: tc.callId });
            safeEnqueue({
              type: 'tool-call',
              toolCallId: tc.callId,
              toolName: tc.name,
              input: tc.arguments || '{}',
            });
          }

          safeEnqueue({ type: 'finish', finishReason, usage });
          safeClose();
        } catch (error) {
          // Check for context overflow FIRST - these should NOT trigger token refresh
          if (self.isContextOverflowError(error)) {
            const apiError = error as InstanceType<typeof OpenAI.APIError>;
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
                statusCode: 400,
                cause: error,
              }),
            });
            safeClose();
            return;
          }

          if (!isRetry && self.isTokenError(error)) {
            self.directAccessClient.invalidateToken();
            if (!contentEmitted) {
              try {
                const retried = await self.doStreamWithResponsesApi(options, true);
                const reader = retried.stream.getReader();
                for (;;) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  if (value.type === 'stream-start') continue;
                  safeEnqueue(value);
                }
                safeClose();
                return;
              } catch (retryError) {
                safeEnqueue({
                  type: 'error',
                  error:
                    retryError instanceof GitLabError
                      ? retryError
                      : new GitLabError({
                          message: 'Token refresh retry failed',
                          cause: retryError,
                        }),
                });
                safeClose();
                return;
              }
            }
            safeEnqueue({
              type: 'error',
              error: new GitLabError({ message: 'TOKEN_REFRESH_NEEDED', cause: error }),
            });
            safeClose();
            return;
          }

          if (error instanceof OpenAI.APIError) {
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: self.formatOpenAIError(error, tools?.length),
                statusCode: error.status,
                cause: error,
              }),
            });
          } else {
            safeEnqueue({ type: 'error', error });
          }
          safeClose();
        }
      },
    });

    return { stream, request: { body: requestBody } };
  }
}
