import { constants } from 'node:fs';
import { lstat, open, opendir, unlink } from 'node:fs/promises';
import { join } from 'node:path';
import { lock } from 'proper-lockfile';
import type { LockOptions } from 'proper-lockfile';

const lifetime = 25 * 60 * 1000;
const candidateName = /^([a-f0-9]{64})(?:\.json|\.[a-f0-9-]{36}\.tmp)$/;
// Bound process-local cursor state; directory order may change between sweeps.
const cursors = new Map<string, number>();

/** Best-effort bounded cleanup; another scope's writer must never be disturbed. */
export async function pruneDirectAccessCache(
  directory: string,
  currentKey: string,
  sameDirectory: () => boolean,
  filesystem: LockOptions['fs'],
  currentLeaseOwned: () => boolean = () => true
): Promise<void> {
  let scanned = 0;
  let candidates = 0;
  const offset = cursors.get(directory) ?? 0;
  let position = 0;
  let exhausted = true;
  try {
    const entries = await opendir(directory);
    for await (const entry of entries) {
      if (position++ < offset) continue;
      if (++scanned > 128 || candidates >= 32 || !sameDirectory() || !currentLeaseOwned()) {
        position--;
        exhausted = false;
        break;
      }
      const match = candidateName.exec(entry.name);
      if (!match || !entry.isFile()) continue;
      candidates++;
      const key = match[1];
      let release: (() => Promise<void>) | undefined;
      let compromised = false;
      let acquiredAt = performance.now();
      const owned = () =>
        currentLeaseOwned() && !compromised && performance.now() - acquiredAt < 30_000;
      try {
        if (key !== currentKey) {
          release = await lock(join(directory, `${key}.json`), {
            fs: filesystem,
            realpath: false,
            lockfilePath: join(directory, `${key}.refresh-v1.lock`),
            stale: 45_000,
            update: 5_000,
            retries: 0,
            onCompromised: () => {
              compromised = true;
            },
          });
          acquiredAt = performance.now();
        }
        if (!sameDirectory()) continue;
        const path = join(directory, entry.name);
        const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
        try {
          const info = await file.stat();
          if (!info.isFile() || info.uid !== process.getuid?.() || (info.mode & 0o077) !== 0)
            continue;
          let expired: boolean;
          if (entry.name.endsWith('.tmp')) {
            expired = info.mtimeMs < Date.now() - lifetime;
          } else {
            const value: unknown = JSON.parse(await file.readFile('utf8'));
            const expiresAt = (value as { expiresAt?: unknown } | null)?.expiresAt;
            expired =
              typeof expiresAt === 'number' &&
              Number.isFinite(expiresAt) &&
              expiresAt <= Date.now();
          }
          const current = await lstat(path);
          if (
            expired &&
            owned() &&
            sameDirectory() &&
            current.dev === info.dev &&
            current.ino === info.ino
          ) {
            await unlink(path);
          }
        } finally {
          await file.close();
        }
      } catch {
        // Busy scopes, malformed entries and filesystem failures are not token failures.
      } finally {
        if (!compromised) await release?.().catch(() => {});
      }
    }
  } catch {
    // Pruning is opportunistic and must not turn a successful refresh into a failure.
  } finally {
    cursors.delete(directory);
    cursors.set(directory, exhausted ? 0 : position);
    if (cursors.size > 16) cursors.delete(cursors.keys().next().value!);
  }
}
