import { z } from 'zod';

// OAuth token response schema
export const gitlabOAuthTokenResponseSchema = z.object({
  access_token: z.string(),
  refresh_token: z.string().optional(),
  expires_in: z.number(),
  created_at: z.number(),
});

export type GitLabOAuthTokenResponse = z.infer<typeof gitlabOAuthTokenResponseSchema>;
