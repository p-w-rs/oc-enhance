import Anthropic from '@anthropic-ai/sdk';
import type { Tool } from '@anthropic-ai/sdk/resources/messages';
import { GitLabDirectAccessClient } from './gitlab-direct-access';
import { GitLabError } from './gitlab-error';

import type {
  LanguageModelV3,
  LanguageModelV3CallOptions,
  LanguageModelV3StreamPart,
  LanguageModelV3FinishReason,
  LanguageModelV3Content,
  LanguageModelV3Usage,
  LanguageModelV3FunctionTool,
  LanguageModelV3Message,
  LanguageModelV3ToolChoice,
  LanguageModelV3GenerateResult,
  LanguageModelV3StreamResult,
} from '@ai-sdk/provider';

/**
 * Extended thinking configuration for Anthropic Messages API models.
 *
 * - `enabled`/`disabled` map to the Anthropic `thinking` field directly. `enabled`
 *   requires a `budgetTokens` value that is less than the request's max tokens.
 * - `adaptive` is required by effort-based models (e.g. Claude Opus 4.8), which
 *   reject `thinking.type.enabled`. It is serialized as `thinking: { type: 'adaptive' }`
 *   plus a sibling `output_config: { effort }`.
 */
export type GitLabThinkingConfig =
  | { type: 'disabled' }
  | { type: 'enabled'; budgetTokens: number }
  | { type: 'adaptive'; effort: 'low' | 'medium' | 'high' | 'xhigh' | 'max' };

/**
 * Per-request options for Anthropic models, read from `providerOptions.gitlab`
 * or from the provider's configured name (e.g. `providerOptions['gitlab.agentic']`).
 */
export interface GitLabAnthropicProviderOptions {
  /**
   * Extended thinking configuration for this request. Takes precedence over the
   * model-level `thinking` default.
   */
  thinking?: GitLabThinkingConfig;

  /**
   * Omit the message-level prompt-cache breakpoints for this request, so a
   * one-shot or background call whose context is never reused does not pay the
   * cache-write premium. The system prompt stays cached either way, since it is
   * static and cheap to keep cached.
   * @default false
   */
  skipCache?: boolean;
}

export interface GitLabAnthropicConfig {
  provider: string;
  instanceUrl: string;
  getHeaders: () => Record<string, string>;
  fetch?: typeof fetch;

  /**
   * Optional async hook that resolves once credentials are loaded, awaited
   * before the synchronous getHeaders() is used for the direct-access request.
   */
  ensureApiKey?: () => Promise<void>;

  /**
   * Optional callback to refresh the API key when a 401 error occurs.
   * Should clear cached credentials and re-fetch from auth provider.
   */
  refreshApiKey?: () => Promise<void>;

  /**
   * The Anthropic model to use (e.g., 'claude-sonnet-4-5-20250929')
   * @default 'claude-sonnet-4-5-20250929'
   */
  anthropicModel?: string;

  /**
   * Maximum tokens to generate
   * @default 8192
   */
  maxTokens?: number;
  thinking?: GitLabThinkingConfig;

  /**
   * Feature flags to pass to the GitLab API
   * @default { DuoAgentPlatformNext: true }
   */
  featureFlags?: {
    DuoAgentPlatformNext: true;
  } & Record<string, boolean>;

  /**
   * AI Gateway URL for the Anthropic proxy.
   * Can also be set via GITLAB_AI_GATEWAY_URL environment variable.
   * @default 'https://cloud.gitlab.com'
   */
  aiGatewayUrl?: string;
  directAccessCacheDir?: string;

  /**
   * Custom headers for AI Gateway Anthropic proxy requests.
   * Merged with headers from direct_access token response.
   */
  aiGatewayHeaders?: Record<string, string>;
}

/**
 * GitLab Anthropic Language Model
 *
 * This model uses GitLab's Anthropic proxy to provide native tool calling support
 * for the duo-chat model. It connects to Claude through GitLab's cloud proxy
 * at https://cloud.gitlab.com/ai/v1/proxy/anthropic/
 */
export class GitLabAnthropicLanguageModel implements LanguageModelV3 {
  readonly specificationVersion = 'v3' as const;
  readonly modelId: string;
  readonly supportedUrls: Record<string, RegExp[]> = {};

  private readonly config: GitLabAnthropicConfig;
  private readonly directAccessClient: GitLabDirectAccessClient;
  private anthropicClient: Anthropic | null = null;

  constructor(modelId: string, config: GitLabAnthropicConfig) {
    this.modelId = modelId;
    this.config = config;

    this.directAccessClient = new GitLabDirectAccessClient({
      instanceUrl: config.instanceUrl,
      getHeaders: config.getHeaders,
      ensureApiKey: config.ensureApiKey,
      refreshApiKey: config.refreshApiKey,
      fetch: config.fetch,
      featureFlags: config.featureFlags,
      aiGatewayUrl: config.aiGatewayUrl,
      directAccessCacheDir: config.directAccessCacheDir,
    });
  }

  get provider(): string {
    return this.config.provider;
  }

  /**
   * Get or create an Anthropic client with valid credentials
   * @param forceRefresh - If true, forces a token refresh before creating the client
   */
  private async getAnthropicClient(forceRefresh: boolean = false): Promise<Anthropic> {
    // Get token from GitLab (will use cache unless forceRefresh is true)
    const tokenData = await this.directAccessClient.getDirectAccessToken(forceRefresh);

    // Create new client with the token
    // GitLab's proxy expects:
    // - authToken: sets Authorization: Bearer header (NOT apiKey which sets x-api-key)
    // - defaultHeaders: additional headers from the direct access response
    // Filter out x-api-key from headers if present - we use authToken for Bearer auth
    const { 'x-api-key': _removed, ...filteredHeaders } = tokenData.headers;

    // Merge: tokenData headers < custom aiGatewayHeaders
    const mergedHeaders = {
      ...filteredHeaders,
      ...this.config.aiGatewayHeaders,
    };

    this.anthropicClient = new Anthropic({
      apiKey: null,
      authToken: tokenData.token,
      baseURL: this.directAccessClient.getAnthropicProxyUrl(),
      defaultHeaders: mergedHeaders,
    });

    return this.anthropicClient;
  }

  /**
   * Check if an error is a token-related authentication error that can be retried
   */
  private isTokenError(error: unknown): boolean {
    if (error instanceof Anthropic.APIError) {
      // 401 Unauthorized - token expired or revoked
      if (error.status === 401) {
        return true;
      }
      // Check for token-related error messages
      const message = error.message?.toLowerCase() || '';
      if (
        message.includes('token') &&
        (message.includes('expired') || message.includes('revoked') || message.includes('invalid'))
      ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check if an error is a context overflow error (prompt too long)
   * These should NOT trigger token refresh and should be reported to the user.
   */
  private isContextOverflowError(error: unknown): boolean {
    if (error instanceof Anthropic.APIError) {
      // 400 Bad Request with prompt too long message
      if (error.status === 400) {
        const message = error.message?.toLowerCase() || '';
        if (
          message.includes('prompt is too long') ||
          message.includes('prompt too long') ||
          (message.includes('tokens') && message.includes('maximum'))
        ) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Convert AI SDK tools to Anthropic tool format
   */
  private convertTools(tools?: LanguageModelV3CallOptions['tools']): Tool[] | undefined {
    if (!tools || tools.length === 0) {
      return undefined;
    }

    return tools
      .filter((tool): tool is LanguageModelV3FunctionTool => tool.type === 'function')
      .map((tool) => {
        const schema = tool.inputSchema as { properties?: object; required?: string[] } | undefined;
        return {
          name: tool.name,
          description: tool.description || '',
          input_schema: {
            type: 'object' as const,
            properties: schema?.properties || {},
            required: schema?.required || [],
          },
        };
      });
  }

  /**
   * Convert AI SDK tool choice to Anthropic format
   */
  private convertToolChoice(
    toolChoice?: LanguageModelV3ToolChoice
  ): Anthropic.MessageCreateParams['tool_choice'] {
    if (!toolChoice) {
      return undefined;
    }

    switch (toolChoice.type) {
      case 'auto':
        return { type: 'auto' };
      case 'none':
        // Anthropic doesn't have a direct 'none' - we handle this by not sending tools
        return undefined;
      case 'required':
        return { type: 'any' };
      case 'tool':
        return { type: 'tool', name: toolChoice.toolName };
      default:
        return undefined;
    }
  }

  /**
   * Convert AI SDK prompt to Anthropic messages format.
   *
   * Cache breakpoints (`cache_control: { type: "ephemeral" }`) are placed on:
   * 1. The system prompt content block — static across all turns.
   * 2. The last content block of each of the final two messages.
   *
   * Two trailing breakpoints (rather than a single one on the penultimate
   * message) keep a cache write within Anthropic's 20-block lookback window
   * as an agentic conversation grows several messages per turn (assistant
   * tool-call → tool-result → …). With a single breakpoint the most recent
   * write can drift more than 20 blocks behind the current position, so the
   * next request fails to prefix-match and pays for a fresh cache write
   * instead of a cheap read. The extra breakpoint costs nothing (breakpoints
   * themselves are free; you only pay for tokens actually written/read) and
   * materially raises the cache hit rate in multi-turn tool-using sessions.
   *
   * When `skipCache` is true (for example one-shot or background runs whose
   * context is never reused) the message-level breakpoints are omitted, so no
   * cache-write premium is paid for a cache that will never be read. The
   * system-prompt breakpoint is left in place because the system prompt is
   * static and cheap to keep cached.
   *
   * @see https://docs.anthropic.com/en/docs/build-with-claude/prompt-caching
   */
  private convertPrompt(
    prompt: LanguageModelV3Message[],
    options: { skipCache?: boolean } = {}
  ): {
    system?: Anthropic.MessageCreateParams['system'];
    messages: Anthropic.MessageParam[];
  } {
    const { skipCache = false } = options;
    let systemMessage: string | undefined;
    const messages: Anthropic.MessageParam[] = [];

    for (const message of prompt) {
      if (message.role === 'system') {
        systemMessage = systemMessage ? `${systemMessage}\n${message.content}` : message.content;
        continue;
      }

      if (message.role === 'user') {
        const content: Anthropic.ContentBlockParam[] = [];

        for (const part of message.content) {
          if (part.type === 'text') {
            content.push({ type: 'text', text: part.text });
          } else if (part.type === 'file') {
            // Handle file/image content if needed
            // For now, skip non-text content
          }
        }

        if (content.length > 0) {
          messages.push({ role: 'user', content });
        }
      } else if (message.role === 'assistant') {
        const content: Anthropic.ContentBlockParam[] = [];

        for (const part of message.content) {
          if (part.type === 'reasoning') {
            const thinkingBlock = this.convertReasoningPart(part);
            if (thinkingBlock) {
              content.push(thinkingBlock);
            }
          } else if (part.type === 'text') {
            content.push({ type: 'text', text: part.text });
          } else if (part.type === 'tool-call') {
            let toolInput: unknown = part.input;
            if (typeof part.input === 'string') {
              try {
                toolInput = JSON.parse(part.input);
              } catch {
                toolInput = {};
              }
            }
            content.push({
              type: 'tool_use',
              id: part.toolCallId,
              name: part.toolName,
              input: toolInput,
            });
          }
        }

        if (content.length > 0) {
          messages.push({ role: 'assistant', content });
        }
      } else if (message.role === 'tool') {
        // Tool results need to be sent as user messages with tool_result content
        const content: Anthropic.ToolResultBlockParam[] = [];

        for (const part of message.content) {
          if (part.type === 'tool-result') {
            let resultContent: string;

            // Convert tool result output to string
            if (part.output.type === 'text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'content') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'error-text') {
              resultContent = part.output.value;
            } else if (part.output.type === 'error-json') {
              resultContent = JSON.stringify(part.output.value);
            } else if (part.output.type === 'execution-denied') {
              resultContent = part.output.reason ?? 'Tool execution denied.';
            } else {
              resultContent = JSON.stringify(part.output);
            }

            content.push({
              type: 'tool_result',
              tool_use_id: part.toolCallId,
              content: resultContent,
              is_error: part.output.type.startsWith('error'),
            });
          }
        }

        if (content.length > 0) {
          messages.push({ role: 'user', content });
        }
      }
    }

    const system: Anthropic.MessageCreateParams['system'] = systemMessage
      ? [
          {
            type: 'text' as const,
            text: systemMessage,
            cache_control: { type: 'ephemeral' as const },
          },
        ]
      : undefined;

    if (!skipCache) {
      // Mark the last content block of each of the final two messages. Two
      // trailing breakpoints keep a prior cache write inside Anthropic's
      // 20-block lookback window as the conversation grows several blocks per
      // turn, so the next request prefix-matches and reads instead of rewriting.
      const breakpointCount = Math.min(2, messages.length);
      for (let i = messages.length - breakpointCount; i < messages.length; i++) {
        const message = messages[i];
        if (Array.isArray(message.content) && message.content.length > 0) {
          const lastBlock = message.content[message.content.length - 1];
          (lastBlock as unknown as Record<string, unknown>).cache_control = {
            type: 'ephemeral' as const,
          };
        }
      }
    }

    return { system, messages };
  }

  /**
   * Convert Anthropic finish reason to AI SDK format
   */
  private convertFinishReason(stopReason: string | null): LanguageModelV3FinishReason {
    const unified: LanguageModelV3FinishReason['unified'] = (() => {
      switch (stopReason) {
        case 'end_turn':
          return 'stop';
        case 'stop_sequence':
          return 'stop';
        case 'pause_turn':
          return 'stop';
        case 'max_tokens':
          return 'length';
        case 'model_context_window_exceeded':
          return 'length';
        case 'tool_use':
          return 'tool-calls';
        case 'refusal':
          return 'content-filter';
        default:
          return 'other';
      }
    })();

    return { unified, raw: stopReason ?? undefined };
  }

  private createUsage(params?: {
    inputTotal?: number;
    outputTotal?: number;
    outputReasoning?: number;
    cacheRead?: number;
    cacheWrite?: number;
    raw?: LanguageModelV3Usage['raw'];
  }): LanguageModelV3Usage {
    const inputNoCache = params?.inputTotal;
    const outputTotal = params?.outputTotal;
    const cacheRead = params?.cacheRead;
    const cacheWrite = params?.cacheWrite;
    const inputTotal =
      inputNoCache != null ? inputNoCache + (cacheRead ?? 0) + (cacheWrite ?? 0) : undefined;

    return {
      inputTokens: {
        total: inputTotal,
        noCache: inputNoCache,
        cacheRead,
        cacheWrite,
      },
      outputTokens: {
        total: outputTotal,
        text: outputTotal != null ? outputTotal - (params?.outputReasoning ?? 0) : undefined,
        reasoning: params?.outputReasoning,
      },
      raw: params?.raw,
    };
  }

  /**
   * Translates the camelCase GitLab thinking config into the Anthropic Messages
   * request fields. `adaptive` is required by effort-based models such as Claude
   * Opus 4.8 and pairs `thinking: { type: 'adaptive' }` with a sibling
   * `output_config: { effort }`; `enabled`/`disabled` map through directly.
   */
  private buildThinkingParams(config: GitLabThinkingConfig | undefined): Record<string, unknown> {
    if (!config) return {};
    if (config.type === 'adaptive') {
      return {
        // Newer adaptive-only models (Claude Sonnet 5+, Opus 4.7+) default
        // `thinking.display` to `'omitted'`, which returns *empty* thinking
        // blocks — the model still reasons and effort still affects
        // behavior/token usage, but no visible chain-of-thought text comes
        // back. Older models already default to `'summarized'`, so it's
        // safe to always request it explicitly rather than gating on model
        // version.
        thinking: { type: 'adaptive', display: 'summarized' },
        output_config: { effort: config.effort },
      };
    }
    if (config.type === 'enabled') {
      return { thinking: { type: 'enabled', budget_tokens: config.budgetTokens } };
    }
    return { thinking: { type: 'disabled' } };
  }

  /** Per-call thinking configuration takes precedence over the model-level default. */
  private resolveThinkingConfig(
    options: LanguageModelV3CallOptions
  ): GitLabThinkingConfig | undefined {
    return this.getProviderOption(options, 'thinking') ?? this.config.thinking;
  }

  /**
   * Look up a per-request option under `providerOptions.gitlab` first, then under
   * the provider's configured name (e.g. `gitlab.agentic`). The Set dedupes the
   * case where the configured name is itself `gitlab`.
   */
  private getProviderOption<K extends keyof GitLabAnthropicProviderOptions>(
    options: LanguageModelV3CallOptions,
    name: K
  ): GitLabAnthropicProviderOptions[K] | undefined {
    const providerOptions = options.providerOptions;
    if (!providerOptions) return undefined;
    for (const key of new Set(['gitlab', this.config.provider])) {
      const scoped: unknown = providerOptions[key];
      if (typeof scoped !== 'object' || scoped === null) continue;
      const value = (scoped as Record<string, unknown>)[name];
      if (value !== undefined) return value as GitLabAnthropicProviderOptions[K];
    }
    return undefined;
  }

  private validateThinkingConfig(
    config: GitLabThinkingConfig | undefined,
    maxTokens: number
  ): void {
    if (config?.type === 'enabled' && config.budgetTokens >= maxTokens) {
      throw new GitLabError({
        message:
          `Anthropic thinking budgetTokens (${config.budgetTokens}) must be less than ` +
          `maxTokens (${maxTokens}).`,
        statusCode: 400,
      });
    }
  }

  /**
   * Rebuild an Anthropic thinking block from a prior-turn reasoning part.
   * Anthropic requires thinking blocks to be replayed unmodified (with their
   * signature) during tool-use loops; the signature / redacted payload are
   * carried in the reasoning part's provider metadata under `gitlab`.
   */
  private convertReasoningPart(part: {
    text: string;
    providerOptions?: Record<string, Record<string, unknown>>;
  }): Anthropic.ContentBlockParam | undefined {
    const meta = part.providerOptions?.['gitlab'];
    const redactedData = meta?.['redactedData'];
    if (typeof redactedData === 'string') {
      return { type: 'redacted_thinking', data: redactedData };
    }

    const signature = meta?.['signature'];
    // A thinking block without its signature cannot be replayed — Anthropic
    // rejects unsigned thinking blocks — so drop it rather than send a 400.
    if (typeof signature !== 'string') {
      return undefined;
    }
    return { type: 'thinking', thinking: part.text, signature };
  }

  private isThinkingActive(config: GitLabThinkingConfig | undefined): boolean {
    return config?.type === 'enabled' || config?.type === 'adaptive';
  }

  /**
   * Anthropic rejects `temperature` changes while thinking is active and requires
   * `top_p` within [0.95, 1]; drop those params when thinking is engaged so the
   * gateway does not 400. Undefined values are omitted either way.
   */
  private buildSamplingParams(
    options: LanguageModelV3CallOptions,
    thinkingConfig: GitLabThinkingConfig | undefined
  ): { temperature?: number; top_p?: number } {
    const params: { temperature?: number; top_p?: number } = {};
    const thinkingActive = this.isThinkingActive(thinkingConfig);

    if (options.temperature != null && !thinkingActive) {
      params.temperature = options.temperature;
    }

    if (options.topP != null) {
      if (!thinkingActive || (options.topP >= 0.95 && options.topP <= 1)) {
        params.top_p = options.topP;
      }
    }

    return params;
  }

  /**
   * Read the `skipCache` flag from provider options. Callers pass it as
   * `providerOptions.gitlab.skipCache` (or under the provider's own name) to
   * omit the message-level prompt-cache breakpoints for one-shot / background
   * invocations whose context is never reused. The system-prompt breakpoint is
   * always kept. Defaults to false.
   */
  private shouldSkipCache(options: LanguageModelV3CallOptions): boolean {
    const skipCache = this.getProviderOption(options, 'skipCache');
    return typeof skipCache === 'boolean' ? skipCache : false;
  }

  async doGenerate(options: LanguageModelV3CallOptions): Promise<LanguageModelV3GenerateResult> {
    return this.doGenerateWithRetry(options, false);
  }

  private async doGenerateWithRetry(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    content: LanguageModelV3Content[];
    finishReason: LanguageModelV3FinishReason;
    usage: LanguageModelV3Usage;
    warnings: [];
  }> {
    const { system, messages } = this.convertPrompt(options.prompt, {
      skipCache: this.shouldSkipCache(options),
    });
    const toolsDisabled = options.toolChoice?.type === 'none';
    const tools = toolsDisabled ? undefined : this.convertTools(options.tools);
    const toolChoice = toolsDisabled ? undefined : this.convertToolChoice(options.toolChoice);

    const anthropicModel = this.config.anthropicModel || 'claude-sonnet-4-5-20250929';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const thinkingConfig = this.resolveThinkingConfig(options);
    this.validateThinkingConfig(thinkingConfig, maxTokens);
    const client = await this.getAnthropicClient(isRetry);

    const generateParams = {
      model: anthropicModel,
      max_tokens: maxTokens,
      system: system,
      messages: messages,
      tools: tools,
      tool_choice: tools ? toolChoice : undefined,
      ...this.buildSamplingParams(options, thinkingConfig),
      stop_sequences: options.stopSequences,
      ...this.buildThinkingParams(thinkingConfig),
    };

    try {
      const response = options.abortSignal
        ? await client.messages.create(generateParams, { signal: options.abortSignal })
        : await client.messages.create(generateParams);

      const content: LanguageModelV3Content[] = [];

      for (const block of response.content) {
        if (block.type === 'thinking') {
          content.push({
            type: 'reasoning',
            text: block.thinking,
            providerMetadata: { gitlab: { signature: block.signature } },
          });
        } else if (block.type === 'redacted_thinking') {
          content.push({
            type: 'reasoning',
            text: '',
            providerMetadata: { gitlab: { redactedData: block.data } },
          });
        } else if (block.type === 'text') {
          content.push({
            type: 'text',
            text: block.text,
          });
        } else if (block.type === 'tool_use') {
          content.push({
            type: 'tool-call',
            toolCallId: block.id,
            toolName: block.name,
            input: JSON.stringify(block.input),
          });
        }
      }

      const rawUsage = response.usage as unknown as Record<string, number>;
      const usage = this.createUsage({
        inputTotal: response.usage.input_tokens,
        outputTotal: response.usage.output_tokens,
        cacheRead: rawUsage.cache_read_input_tokens,
        cacheWrite: rawUsage.cache_creation_input_tokens,
      });

      return {
        content,
        finishReason: this.convertFinishReason(response.stop_reason),
        usage,
        warnings: [],
      };
    } catch (error) {
      // Check for context overflow FIRST - these should NOT trigger token refresh
      if (this.isContextOverflowError(error)) {
        const apiError = error as InstanceType<typeof Anthropic.APIError>;
        throw new GitLabError({
          message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
          statusCode: 400,
          cause: error,
        });
      }

      // If this is a token error and we haven't retried yet, refresh token and retry
      if (!isRetry && this.isTokenError(error)) {
        this.directAccessClient.invalidateToken();
        return this.doGenerateWithRetry(options, true);
      }

      if (error instanceof Anthropic.APIError) {
        throw new GitLabError({
          message: `Anthropic API error: ${error.message}`,
          statusCode: error.status,
          cause: error,
        });
      }
      throw error;
    }
  }

  async doStream(options: LanguageModelV3CallOptions): Promise<LanguageModelV3StreamResult> {
    return this.doStreamWithRetry(options, false);
  }

  private async doStreamWithRetry(
    options: LanguageModelV3CallOptions,
    isRetry: boolean
  ): Promise<{
    stream: ReadableStream<LanguageModelV3StreamPart>;
    request?: { body?: unknown };
    response?: { headers?: Record<string, string> };
  }> {
    const { system, messages } = this.convertPrompt(options.prompt, {
      skipCache: this.shouldSkipCache(options),
    });
    const toolsDisabled = options.toolChoice?.type === 'none';
    const tools = toolsDisabled ? undefined : this.convertTools(options.tools);
    const toolChoice = toolsDisabled ? undefined : this.convertToolChoice(options.toolChoice);

    const anthropicModel = this.config.anthropicModel || 'claude-sonnet-4-5-20250929';
    const maxTokens = options.maxOutputTokens || this.config.maxTokens || 8192;
    const thinkingConfig = this.resolveThinkingConfig(options);
    this.validateThinkingConfig(thinkingConfig, maxTokens);
    const client = await this.getAnthropicClient(isRetry);

    const requestBody = {
      model: anthropicModel,
      max_tokens: maxTokens,
      system: system,
      messages: messages,
      tools: tools,
      tool_choice: tools ? toolChoice : undefined,
      ...this.buildSamplingParams(options, thinkingConfig),
      stop_sequences: options.stopSequences,
      ...this.buildThinkingParams(thinkingConfig),
      stream: true as const,
    };

    // Reference to this for use in the stream callback
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const self = this;

    const abortController = new AbortController();
    if (options.abortSignal) {
      if (options.abortSignal.aborted) {
        abortController.abort(options.abortSignal.reason);
      } else {
        options.abortSignal.addEventListener('abort', () =>
          abortController.abort(options.abortSignal?.reason)
        );
      }
    }
    let streamClosed = false;

    const stream = new ReadableStream<LanguageModelV3StreamPart>({
      cancel: () => {
        streamClosed = true;
        abortController.abort();
      },
      start: async (controller) => {
        const safeEnqueue = (part: LanguageModelV3StreamPart) => {
          if (streamClosed) return;
          try {
            controller.enqueue(part);
          } catch {
            streamClosed = true;
          }
        };
        const safeClose = () => {
          if (streamClosed) return;
          streamClosed = true;
          try {
            controller.close();
          } catch {
            // already closed
          }
        };

        const contentBlocks: Record<
          number,
          | { type: 'text'; id: string }
          | { type: 'reasoning'; id: string; signature?: string; redactedData?: string }
          | { type: 'tool-call'; toolCallId: string; toolName: string; input: string }
        > = {};

        let usage = self.createUsage();
        let finishReason: LanguageModelV3FinishReason = { unified: 'other', raw: undefined };
        let finishEmitted = false;
        let contentEmitted = false;

        const flushPendingToolCalls = () => {
          for (const [index, block] of Object.entries(contentBlocks)) {
            if (block.type === 'tool-call') {
              safeEnqueue({
                type: 'tool-input-end',
                id: block.toolCallId,
              });
              safeEnqueue({
                type: 'tool-call',
                toolCallId: block.toolCallId,
                toolName: block.toolName,
                input: block.input === '' ? '{}' : block.input,
              });
            }
            delete contentBlocks[Number(index)];
          }
        };

        try {
          const anthropicStream = client.messages.stream(requestBody, {
            signal: abortController.signal,
          });

          // Stream start
          safeEnqueue({
            type: 'stream-start',
            warnings: [],
          });

          // Use event-based approach instead of for-await to ensure all events are received
          await new Promise<void>((resolve, reject) => {
            anthropicStream.on('streamEvent', (event) => {
              try {
                switch (event.type) {
                  case 'message_start':
                    if (event.message.usage) {
                      const msgUsage = event.message.usage as {
                        input_tokens?: number;
                        cache_read_input_tokens?: number;
                        cache_creation_input_tokens?: number;
                      };
                      usage = self.createUsage({
                        inputTotal: msgUsage.input_tokens,
                        outputTotal: usage.outputTokens.total,
                        outputReasoning: usage.outputTokens.reasoning,
                        cacheRead: msgUsage.cache_read_input_tokens,
                        cacheWrite: msgUsage.cache_creation_input_tokens,
                        raw: usage.raw,
                      });
                    }
                    safeEnqueue({
                      type: 'response-metadata',
                      id: event.message.id,
                      modelId: event.message.model,
                    });
                    break;

                  case 'content_block_start':
                    contentEmitted = true;
                    if (event.content_block.type === 'text') {
                      const textId = `text-${event.index}`;
                      contentBlocks[event.index] = { type: 'text', id: textId };
                      safeEnqueue({
                        type: 'text-start',
                        id: textId,
                      });
                    } else if (event.content_block.type === 'thinking') {
                      const reasoningId = `reasoning-${event.index}`;
                      contentBlocks[event.index] = { type: 'reasoning', id: reasoningId };
                      safeEnqueue({
                        type: 'reasoning-start',
                        id: reasoningId,
                      });
                    } else if (event.content_block.type === 'redacted_thinking') {
                      const reasoningId = `reasoning-${event.index}`;
                      contentBlocks[event.index] = {
                        type: 'reasoning',
                        id: reasoningId,
                        redactedData: event.content_block.data,
                      };
                      safeEnqueue({
                        type: 'reasoning-start',
                        id: reasoningId,
                      });
                    } else if (event.content_block.type === 'tool_use') {
                      contentBlocks[event.index] = {
                        type: 'tool-call',
                        toolCallId: event.content_block.id,
                        toolName: event.content_block.name,
                        input: '',
                      };
                      safeEnqueue({
                        type: 'tool-input-start',
                        id: event.content_block.id,
                        toolName: event.content_block.name,
                      });
                    }
                    break;

                  case 'content_block_delta': {
                    const block = contentBlocks[event.index];
                    if (event.delta.type === 'text_delta' && block?.type === 'text') {
                      safeEnqueue({
                        type: 'text-delta',
                        id: block.id,
                        delta: event.delta.text,
                      });
                    } else if (
                      event.delta.type === 'thinking_delta' &&
                      block?.type === 'reasoning'
                    ) {
                      safeEnqueue({
                        type: 'reasoning-delta',
                        id: block.id,
                        delta: event.delta.thinking,
                      });
                    } else if (
                      event.delta.type === 'signature_delta' &&
                      block?.type === 'reasoning'
                    ) {
                      block.signature = event.delta.signature;
                    } else if (
                      event.delta.type === 'input_json_delta' &&
                      block?.type === 'tool-call'
                    ) {
                      block.input += event.delta.partial_json;
                      safeEnqueue({
                        type: 'tool-input-delta',
                        id: block.toolCallId,
                        delta: event.delta.partial_json,
                      });
                    }
                    break;
                  }

                  case 'content_block_stop': {
                    const block = contentBlocks[event.index];
                    if (block?.type === 'text') {
                      safeEnqueue({
                        type: 'text-end',
                        id: block.id,
                      });
                    } else if (block?.type === 'reasoning') {
                      const gitlabMeta =
                        block.redactedData != null
                          ? { redactedData: block.redactedData }
                          : block.signature != null
                            ? { signature: block.signature }
                            : undefined;
                      safeEnqueue({
                        type: 'reasoning-end',
                        id: block.id,
                        ...(gitlabMeta && { providerMetadata: { gitlab: gitlabMeta } }),
                      });
                    } else if (block?.type === 'tool-call') {
                      safeEnqueue({
                        type: 'tool-input-end',
                        id: block.toolCallId,
                      });

                      safeEnqueue({
                        type: 'tool-call',
                        toolCallId: block.toolCallId,
                        toolName: block.toolName,
                        input: block.input === '' ? '{}' : block.input,
                      });
                    }
                    delete contentBlocks[event.index];
                    break;
                  }

                  case 'message_delta':
                    if (event.usage) {
                      const deltaUsage = event.usage as {
                        output_tokens?: number;
                        cache_read_input_tokens?: number;
                        cache_creation_input_tokens?: number;
                      };
                      usage = self.createUsage({
                        inputTotal: usage.inputTokens.noCache,
                        outputTotal: deltaUsage.output_tokens,
                        outputReasoning: usage.outputTokens.reasoning,
                        cacheRead:
                          deltaUsage.cache_read_input_tokens ?? usage.inputTokens.cacheRead,
                        cacheWrite:
                          deltaUsage.cache_creation_input_tokens ?? usage.inputTokens.cacheWrite,
                        raw: usage.raw,
                      });
                    }
                    if (event.delta.stop_reason) {
                      finishReason = self.convertFinishReason(event.delta.stop_reason);
                    }
                    break;

                  case 'message_stop': {
                    flushPendingToolCalls();
                    finishEmitted = true;
                    safeEnqueue({
                      type: 'finish',
                      finishReason,
                      usage,
                    });
                    break;
                  }
                }
              } catch (error) {
                safeEnqueue({
                  type: 'error',
                  error: error instanceof Error ? error : new Error(String(error)),
                });
              }
            });

            anthropicStream.on('end', () => {
              resolve();
            });

            anthropicStream.on('error', (error) => {
              reject(error);
            });
          });

          // Emit any pending tool calls if stream ended without content_block_stop,
          // and guarantee a finish part even when message_stop never arrived.
          flushPendingToolCalls();
          if (!finishEmitted) {
            finishEmitted = true;
            safeEnqueue({
              type: 'finish',
              finishReason,
              usage,
            });
          }

          safeClose();
        } catch (error) {
          // Emit any pending tool calls before handling the error
          flushPendingToolCalls();

          // Check for context overflow FIRST - these should NOT trigger token refresh
          if (self.isContextOverflowError(error)) {
            const apiError = error as InstanceType<typeof Anthropic.APIError>;
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: `Context overflow: ${apiError.message}. Please start a new session or use /compact to reduce context.`,
                statusCode: 400,
                cause: error,
              }),
            });
            safeClose();
            return;
          }

          // If this is a token error and we haven't retried yet, refresh the token
          // and retry the stream once — but only if no content was emitted yet.
          if (!isRetry && self.isTokenError(error)) {
            self.directAccessClient.invalidateToken();
            if (!contentEmitted) {
              try {
                const retried = await self.doStreamWithRetry(options, true);
                const reader = retried.stream.getReader();
                for (;;) {
                  const { done, value } = await reader.read();
                  if (done) break;
                  if (value.type === 'stream-start') continue;
                  safeEnqueue(value);
                }
                safeClose();
                return;
              } catch (retryError) {
                safeEnqueue({
                  type: 'error',
                  error:
                    retryError instanceof GitLabError
                      ? retryError
                      : new GitLabError({
                          message: 'Token refresh retry failed',
                          cause: retryError,
                        }),
                });
                safeClose();
                return;
              }
            }
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: 'TOKEN_REFRESH_NEEDED',
                cause: error,
              }),
            });
            safeClose();
            return;
          }

          if (error instanceof Anthropic.APIError) {
            safeEnqueue({
              type: 'error',
              error: new GitLabError({
                message: `Anthropic API error: ${error.message}`,
                statusCode: error.status,
                cause: error,
              }),
            });
          } else {
            safeEnqueue({
              type: 'error',
              error,
            });
          }
          safeClose();
        }
      },
    });

    return {
      stream,
      request: { body: requestBody },
    };
  }
}
