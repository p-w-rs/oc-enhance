/**
 * File-based cache for workflow model discovery results and user selection.
 *
 * A single cache file is stored at
 * `~/.cache/opencode/gitlab-workflow-model-cache.json`
 * (or `$XDG_CACHE_HOME/opencode/...` when set).
 *
 * The file contains a JSON object keyed by a truncated SHA-256 hash of the
 * workspace directory path combined with the GitLab instance URL. This ensures
 * that switching instances for the same workspace invalidates the cache.
 * Each value holds:
 *   - `discovery`: The full DiscoveredModels JSON from the last successful discovery
 *   - `project`: The GitLab project detected for this workspace
 *   - `selectedModelRef`: The model ref the user last selected
 *   - `selectedModelName`: Human-readable name of the selected model
 *   - `updatedAt`: ISO timestamp of the last write
 */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import * as crypto from 'crypto';
import type { DiscoveredModels } from './gitlab-model-discovery';
import type { GitLabProject } from './gitlab-project-cache';

export interface ModelCacheEntry {
  discovery: DiscoveredModels | null;
  project: GitLabProject | null;
  selectedModelRef: string | null;
  selectedModelName: string | null;
  updatedAt: string;
  /** Timestamp of the last successful discovery write — drives the discovery TTL. */
  discoveryUpdatedAt?: string;
}

type CacheFile = Record<string, ModelCacheEntry>;

const DISCOVERY_TTL_MS = 10 * 60 * 1000;

function getCacheFilePath(): string {
  const cacheHome = process.env.XDG_CACHE_HOME || path.join(os.homedir(), '.cache');
  return path.join(cacheHome, 'opencode', 'gitlab-workflow-model-cache.json');
}

function computeCacheKey(workDir: string, instanceUrl?: string, scope?: string): string {
  const normalizedUrl = (instanceUrl || 'https://gitlab.com').replace(/\/$/, '');
  const input = scope ? `${workDir}\0${normalizedUrl}\0${scope}` : `${workDir}\0${normalizedUrl}`;
  return crypto.createHash('sha256').update(input).digest('hex').slice(0, 12);
}

export class GitLabModelCache {
  private readonly filePath: string;
  private readonly key: string;

  /**
   * @param workDir - Workspace directory the cache entry belongs to
   * @param instanceUrl - GitLab instance URL
   * @param scope - Optional extra key component (e.g. an account identifier) that keeps
   *   entries for different accounts on the same workspace and instance apart
   */
  constructor(workDir: string, instanceUrl?: string, scope?: string) {
    this.filePath = getCacheFilePath();
    this.key = computeCacheKey(workDir, instanceUrl, scope);
  }

  private readAll(): CacheFile {
    try {
      if (!fs.existsSync(this.filePath)) {
        return {};
      }
      const raw = fs.readFileSync(this.filePath, 'utf-8');
      return JSON.parse(raw) as CacheFile;
    } catch {
      return {};
    }
  }

  private writeAll(data: CacheFile): void {
    try {
      const dir = path.dirname(this.filePath);
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
      const tmpPath = `${this.filePath}.${process.pid}.${Date.now()}.tmp`;
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), { mode: 0o600 });
      fs.renameSync(tmpPath, this.filePath);
    } catch {
      // Best-effort — cache write failures are non-fatal
    }
  }

  /**
   * Load the cached entry for this workspace.
   * Returns null if no cache exists or is unreadable.
   */
  load(): ModelCacheEntry | null {
    return this.readAll()[this.key] ?? null;
  }

  /**
   * Persist the full cache entry to disk.
   */
  save(entry: ModelCacheEntry): void {
    const data = this.readAll();
    data[this.key] = entry;
    this.writeAll(data);
  }

  /**
   * Returns true if the discovery data is missing or older than DISCOVERY_TTL_MS.
   * Invalid or missing timestamps are treated as expired (fail closed).
   */
  isDiscoveryExpired(): boolean {
    const entry = this.load();
    const timestamp = entry?.discoveryUpdatedAt;
    if (!entry?.discovery || !timestamp) return true;
    const updatedMs = new Date(timestamp).getTime();
    if (!Number.isFinite(updatedMs)) return true;
    return Date.now() - updatedMs > DISCOVERY_TTL_MS;
  }

  /**
   * Update only the discovery portion of the cache, preserving selection.
   * Optionally persists the associated GitLab project.
   */
  saveDiscovery(discovery: DiscoveredModels, project?: GitLabProject | null): void {
    const existing = this.load();
    const now = new Date().toISOString();
    this.save({
      discovery,
      project: project !== undefined ? project : (existing?.project ?? null),
      selectedModelRef: existing?.selectedModelRef ?? null,
      selectedModelName: existing?.selectedModelName ?? null,
      updatedAt: now,
      discoveryUpdatedAt: now,
    });
  }

  /**
   * Update only the selected model, preserving the discovery data.
   * If name is null but ref is provided, attempts to resolve the name
   * from the cached discovery data.
   */
  saveSelection(ref: string | null, name: string | null): void {
    const existing = this.load();
    let resolved = name;
    if (!resolved && ref && existing?.discovery) {
      const d = existing.discovery;
      const match =
        d.pinnedModel?.ref === ref
          ? d.pinnedModel
          : (d.selectableModels.find((m) => m.ref === ref) ??
            (d.defaultModel?.ref === ref ? d.defaultModel : null));
      resolved = match?.name ?? null;
    }
    this.save({
      discovery: existing?.discovery ?? null,
      project: existing?.project ?? null,
      selectedModelRef: ref,
      selectedModelName: resolved,
      updatedAt: new Date().toISOString(),
      discoveryUpdatedAt: existing?.discoveryUpdatedAt,
    });
  }

  /**
   * Remove the entry for this workspace from the cache file.
   */
  clear(): void {
    const data = this.readAll();
    delete data[this.key];
    if (Object.keys(data).length === 0) {
      try {
        if (fs.existsSync(this.filePath)) {
          fs.unlinkSync(this.filePath);
        }
      } catch {
        // Best-effort
      }
    } else {
      this.writeAll(data);
    }
  }

  /**
   * Convenience: get the cached selected model ref (or null).
   */
  getSelectedModelRef(): string | null {
    return this.load()?.selectedModelRef ?? null;
  }

  /**
   * Convenience: get the cached selected model name (or null).
   */
  getSelectedModelName(): string | null {
    return this.load()?.selectedModelName ?? null;
  }

  /**
   * Convenience: get the cached discovery result (or null).
   */
  getDiscovery(): DiscoveredModels | null {
    return this.load()?.discovery ?? null;
  }
}
