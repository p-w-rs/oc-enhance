/**
 * GitLab OAuth Manager
 * Handles OAuth token management, refresh, and exchange
 * Based on gitlab-vscode-extension TokenExchangeService and gitlab-lsp OAuthClientProvider
 */

import { GitLabError } from './gitlab-error';
import { gitlabOAuthTokenResponseSchema } from './gitlab-api-types';
import type { GitLabOAuthTokenResponse } from './gitlab-api-types';
import {
  type GitLabOAuthTokens,
  TOKEN_EXPIRY_SKEW_MS,
  OPENCODE_GITLAB_AUTH_CLIENT_ID,
  GITLAB_COM_URL,
} from './gitlab-oauth-types';

export interface TokenExchangeParams {
  instanceUrl: string;
  clientId?: string;
  redirectUri?: string;
}

export interface AuthorizationCodeParams extends TokenExchangeParams {
  code: string;
  codeVerifier: string;
}

export interface RefreshTokenParams extends TokenExchangeParams {
  refreshToken: string;
}

/**
 * Module-global in-flight refresh map.
 *
 * GitLab OAuth refresh tokens are single-use: a successful refresh rotates the
 * refresh token, so a second concurrent refresh that reuses the same (now
 * consumed) refresh token fails with 401. opencode creates a separate provider
 * (and therefore a separate GitLabOAuthManager) per model, and several agents
 * can request a token concurrently. Keying the dedup on a per-instance Map was
 * therefore ineffective across those concurrent callers. Sharing the map at
 * module scope ensures all concurrent refreshes for the same refresh token
 * collapse into a single network exchange and all receive the rotated token.
 */
const globalInFlightRefreshes = new Map<string, Promise<GitLabOAuthTokens>>();

export class GitLabOAuthManager {
  private fetch: typeof fetch;
  private inFlightRefreshes = globalInFlightRefreshes;

  constructor(fetchImpl: typeof fetch = fetch) {
    this.fetch = fetchImpl;
  }

  /**
   * Check if a token is expired.
   * Invalid expiry values (NaN) are treated as expired (fail closed).
   */
  isTokenExpired(expiresAt: number): boolean {
    if (!Number.isFinite(expiresAt)) {
      return true;
    }
    return Date.now() >= expiresAt;
  }

  /**
   * Check if a token needs refresh (within skew window).
   * Invalid expiry values (NaN) are treated as needing refresh (fail closed).
   */
  needsRefresh(expiresAt: number): boolean {
    if (!Number.isFinite(expiresAt)) {
      return true;
    }
    return Date.now() >= expiresAt - TOKEN_EXPIRY_SKEW_MS;
  }

  /**
   * Refresh tokens if needed
   * Returns the same tokens if refresh is not needed, or new tokens if refreshed
   */
  async refreshIfNeeded(tokens: GitLabOAuthTokens, clientId?: string): Promise<GitLabOAuthTokens> {
    if (!this.needsRefresh(tokens.expiresAt)) {
      return tokens;
    }

    if (!tokens.refreshToken) {
      throw new GitLabError({
        message: 'OAuth token has expired and no refresh token is available',
      });
    }

    return this.exchangeRefreshToken({
      instanceUrl: tokens.instanceUrl,
      refreshToken: tokens.refreshToken,
      clientId,
    });
  }

  /**
   * Exchange authorization code for tokens
   * Based on gitlab-vscode-extension createOAuthAccountFromCode
   */
  async exchangeAuthorizationCode(params: AuthorizationCodeParams): Promise<GitLabOAuthTokens> {
    const { instanceUrl, code, codeVerifier, clientId, redirectUri } = params;

    const tokenResponse = await this.exchangeToken({
      instanceUrl,
      grantType: 'authorization_code',
      code,
      codeVerifier,
      clientId: clientId || this.getClientId(instanceUrl),
      redirectUri,
    });

    return this.createTokensFromResponse(tokenResponse, instanceUrl);
  }

  /**
   * Exchange refresh token for new tokens
   * Based on gitlab-vscode-extension TokenExchangeService
   */
  async exchangeRefreshToken(params: RefreshTokenParams): Promise<GitLabOAuthTokens> {
    const { instanceUrl, refreshToken, clientId } = params;
    const inFlightKey = `${instanceUrl}:${refreshToken}`;

    const existing = this.inFlightRefreshes.get(inFlightKey);
    if (existing) {
      return existing;
    }

    const refreshPromise = (async () => {
      const tokenResponse = await this.exchangeToken({
        instanceUrl,
        grantType: 'refresh_token',
        refreshToken,
        clientId: clientId || this.getClientId(instanceUrl),
      });

      return this.createTokensFromResponse(tokenResponse, instanceUrl, refreshToken);
    })();

    this.inFlightRefreshes.set(inFlightKey, refreshPromise);

    try {
      return await refreshPromise;
    } finally {
      this.inFlightRefreshes.delete(inFlightKey);
    }
  }

  /**
   * Get the OAuth client ID for an instance.
   * Priority: env var > opencode-gitlab-auth default (for GitLab.com).
   * Note: callers (e.g. exchangeRefreshToken) may pass an explicit clientId
   * that bypasses this method entirely.
   */
  private getClientId(instanceUrl: string): string {
    // Priority 1: Environment variable (allows overriding at runtime)
    const envClientId = process.env['GITLAB_OAUTH_CLIENT_ID'];
    if (envClientId) {
      return envClientId;
    }

    // Priority 2: Use opencode-gitlab-auth's client ID for GitLab.com
    // This ensures refresh works with tokens created by the auth plugin
    if (instanceUrl === GITLAB_COM_URL) {
      return OPENCODE_GITLAB_AUTH_CLIENT_ID;
    }

    throw new GitLabError({
      message: `No OAuth client ID configured for instance ${instanceUrl}. Please provide a clientId parameter or set GITLAB_OAUTH_CLIENT_ID environment variable.`,
    });
  }

  /**
   * Exchange token with GitLab OAuth endpoint
   * Based on gitlab-vscode-extension GitLabService.exchangeToken
   */
  private async exchangeToken(params: {
    instanceUrl: string;
    grantType: 'authorization_code' | 'refresh_token';
    code?: string;
    codeVerifier?: string;
    refreshToken?: string;
    clientId: string;
    redirectUri?: string;
  }): Promise<GitLabOAuthTokenResponse> {
    const { instanceUrl, grantType, code, codeVerifier, refreshToken, clientId, redirectUri } =
      params;

    const body: Record<string, string> = {
      client_id: clientId,
      grant_type: grantType,
    };

    if (grantType === 'authorization_code') {
      if (!code || !codeVerifier || !redirectUri) {
        throw new GitLabError({
          message:
            'Authorization code, code verifier, and redirect URI are required for authorization_code grant',
        });
      }
      body.code = code;
      body.code_verifier = codeVerifier;
      body.redirect_uri = redirectUri;
    } else if (grantType === 'refresh_token') {
      if (!refreshToken) {
        throw new GitLabError({
          message: 'Refresh token is required for refresh_token grant',
        });
      }
      body.refresh_token = refreshToken;
    }

    const url = `${instanceUrl}/oauth/token`;

    try {
      const response = await this.fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams(body).toString(),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new GitLabError({
          message: `OAuth token exchange failed: ${response.status} ${response.statusText}`,
          cause: new Error(errorText),
        });
      }

      const data = await response.json();
      const parsed = gitlabOAuthTokenResponseSchema.safeParse(data);
      if (!parsed.success) {
        throw new GitLabError({
          message: `Invalid OAuth token response: ${parsed.error.message}`,
          cause: parsed.error,
        });
      }
      return parsed.data;
    } catch (error) {
      if (error instanceof GitLabError) {
        throw error;
      }
      throw new GitLabError({
        message: `Failed to exchange OAuth token: ${error instanceof Error ? error.message : String(error)}`,
        cause: error instanceof Error ? error : undefined,
      });
    }
  }

  /**
   * Create GitLabOAuthTokens from token response.
   * Falls back to the previous refresh token when the server omits one.
   */
  private createTokensFromResponse(
    response: GitLabOAuthTokenResponse,
    instanceUrl: string,
    previousRefreshToken?: string
  ): GitLabOAuthTokens {
    const expiresAt = this.createExpiresTimestamp(response);

    return {
      accessToken: response.access_token,
      refreshToken: response.refresh_token || previousRefreshToken || '',
      expiresAt,
      instanceUrl,
    };
  }

  /**
   * Create expiry timestamp from token response
   * Based on gitlab-vscode-extension createExpiresTimestamp
   */
  private createExpiresTimestamp(response: GitLabOAuthTokenResponse): number {
    // GitLab returns created_at (Unix timestamp in seconds) and expires_in (seconds)
    const createdAt = response.created_at * 1000; // Convert to milliseconds
    const expiresIn = response.expires_in * 1000; // Convert to milliseconds
    return createdAt + expiresIn;
  }
}
