import { createHash, randomUUID } from 'node:crypto';
import * as filesystem from 'node:fs';
import { constants } from 'node:fs';
import { lstat, mkdir, open, rename, unlink } from 'node:fs/promises';
import { isAbsolute, join } from 'node:path';
import { lock } from 'proper-lockfile';
import { z } from 'zod';
import { pruneDirectAccessCache } from './gitlab-direct-access-cache-prune';

const tokenSchema = z.object({ token: z.string().min(1), headers: z.record(z.string(), z.string()) });
const entrySchema = z.object({ expiresAt: z.number(), value: tokenSchema });
const lifetime = 25 * 60 * 1000;

/** Share only credentials with identical authorization, endpoint and feature settings. */
export async function cachedDirectAccess(
  directory: string,
  scope: string,
  bypass: boolean,
  fetchToken: (signal: AbortSignal) => Promise<Response>
): Promise<{ response: Response; expiresAt: number }> {
  if (typeof process.getuid !== 'function') {
    throw new Error('Shared direct-access caching requires POSIX ownership and permissions');
  }
  if (!isAbsolute(directory)) throw new Error('Direct-access cache directory must be absolute');
  await mkdir(directory, { recursive: true, mode: 0o700 });
  const stat = await lstat(directory);
  if (!stat.isDirectory() || stat.uid !== process.getuid?.() || (stat.mode & 0o077) !== 0) {
    throw new Error('Direct-access cache directory must be owner-only (0700), not a symlink');
  }
  const key = createHash('sha256').update(scope).digest('hex');
  const path = join(directory, `${key}.json`);
  // Version the suffix to leave room for future lock-format changes.
  const lockPath = join(directory, `${key}.refresh-v1.lock`);
  const read = async (): Promise<{ response: Response; expiresAt: number } | undefined> => {
    let file;
    try {
      file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
      const info = await file.stat();
      if (!info.isFile() || info.uid !== stat.uid || (info.mode & 0o077) !== 0) {
        throw new Error('Direct-access cache entry must be an owner-only regular file');
      }
      const entry = entrySchema.parse(JSON.parse(await file.readFile('utf8')));
      if (entry.expiresAt > Date.now() && entry.expiresAt <= Date.now() + lifetime) {
        return {
          response: new Response(JSON.stringify(entry.value), {
            headers: { 'Content-Type': 'application/json' },
          }),
          expiresAt: entry.expiresAt,
        };
      }
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    } finally {
      await file?.close();
    }
    return undefined;
  };
  // Atomic rename makes published entries safe to read without the refresh lock.
  // Still re-read after locking: another process may have populated a cold miss.
  if (!bypass) {
    const hit = await read();
    if (hit) return hit;
  }
  const controller = new AbortController();
  let compromised: Error | undefined;
  // The library retires its timer/bookkeeping before calling rmdir. Guard only
  // that pathname removal, not release itself, if the parent has been replaced.
  const sameDirectory = () => {
    try {
      const current = filesystem.lstatSync(directory);
      return current.isDirectory() && current.dev === stat.dev && current.ino === stat.ino;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
      return false;
    }
  };
  const lockFilesystem = {
    ...filesystem,
    rmdir: (target: string, callback: (error: NodeJS.ErrnoException | null) => void) => {
      try {
        if (sameDirectory()) filesystem.rmdir(target, callback);
        else callback(null);
      } catch (error) {
        callback(error as NodeJS.ErrnoException);
      }
    },
    rmdirSync: (target: string) => {
      if (sameDirectory()) filesystem.rmdirSync(target);
    },
  };
  const release = await lock(path, {
    fs: lockFilesystem,
    realpath: false,
    lockfilePath: lockPath,
    stale: 45_000,
    update: 5_000,
    retries: { retries: 120, factor: 1, minTimeout: 500, maxTimeout: 500, randomize: false },
    onCompromised: (error) => {
      compromised = error;
      controller.abort();
    },
  }).catch((error: NodeJS.ErrnoException) => {
    if (error.code === 'ELOCKED') {
      throw new Error(
        'Direct-access cache refresh remained locked after approximately 60 seconds. ' +
          'Check the private directory configured by directAccessCacheDir or ' +
          'GITLAB_DIRECT_ACCESS_CACHE_DIR; do not remove an active lock.'
      );
    }
    throw error;
  });
  const acquiredAt = performance.now();
  const assertOwned = () => {
    if (compromised) throw compromised;
    // A suspended process must not publish after another process could reclaim
    // its lease. The monotonic deadline is shorter than the stale threshold.
    if (performance.now() - acquiredAt >= 30_000) {
      throw new Error('Direct-access refresh timed out after 30 seconds');
    }
  };
  try {
    if (!bypass) {
      const hit = await read();
      if (hit) {
        return hit;
      }
    } else {
      await unlink(path).catch((error: NodeJS.ErrnoException) => {
        if (error.code !== 'ENOENT') throw error;
      });
    }
    const started = Date.now();
    let timer: ReturnType<typeof setTimeout> | undefined;
    // Only fetch/body consumption races the deadline. Publication stays outside
    // the losing task, so even a custom fetch ignoring abort cannot write late.
    const consume = async () => {
      const response = await fetchToken(controller.signal);
      const body = await response.text();
      return { response, body };
    };
    let result: Awaited<ReturnType<typeof consume>>;
    try {
      result = await Promise.race([
        consume(),
        new Promise<never>((_resolve, reject) => {
          timer = setTimeout(() => {
            reject(new Error('Direct-access refresh timed out after 30 seconds'));
            controller.abort();
          }, 30_000);
        }),
      ]);
    } finally {
      clearTimeout(timer);
    }
    const current = await lstat(directory);
    if (!current.isDirectory() || current.dev !== stat.dev || current.ino !== stat.ino) {
      throw new Error('Direct-access cache directory changed during refresh');
    }
    assertOwned();
    const { response, body } = result;
    const restored = new Response(body, {
      status: response.status,
      statusText: response.statusText,
    });
    if (!response.ok) return { response: restored, expiresAt: 0 };
    const value = tokenSchema.parse(JSON.parse(body));
    const temporary = join(directory, `${key}.${randomUUID()}.tmp`);
    try {
      const file = await open(temporary, 'wx', 0o600);
      try {
        await file.writeFile(JSON.stringify({ expiresAt: started + lifetime, value }));
      } finally {
        await file.close();
      }
      assertOwned();
      await rename(temporary, path);
    } finally {
      await unlink(temporary).catch((error: NodeJS.ErrnoException) => {
        if (error.code !== 'ENOENT') throw error;
      });
    }
    await pruneDirectAccessCache(directory, key, sameDirectory, lockFilesystem, () => {
      try {
        assertOwned();
        return true;
      } catch {
        return false;
      }
    });
    return { response: restored, expiresAt: started + lifetime };
  } finally {
    if (!compromised) await release();
  }
}
