// Main exports
export { createGitLab, gitlab } from './gitlab-provider';
export { VERSION } from './version';
export type {
  GitLabProvider,
  GitLabProviderSettings,
  GitLabAgenticOptions,
} from './gitlab-provider';

// Model exports
export { GitLabAnthropicLanguageModel } from './gitlab-anthropic-language-model';
export type {
  GitLabAnthropicConfig,
  GitLabAnthropicProviderOptions,
  GitLabThinkingConfig,
} from './gitlab-anthropic-language-model';
export { GitLabOpenAILanguageModel } from './gitlab-openai-language-model';
export type { GitLabOpenAIConfig } from './gitlab-openai-language-model';

// Model mappings exports
export {
  MODEL_MAPPINGS,
  MODEL_ID_TO_ANTHROPIC_MODEL,
  getModelMapping,
  getProviderForModelId,
  getValidModelsForProvider,
  getAnthropicModelForModelId,
  getOpenAIModelForModelId,
  getOpenAIApiType,
  isResponsesApiModel,
} from './model-mappings';
export type { ModelProvider, ModelMapping, OpenAIApiType } from './model-mappings';

// Error exports
export { GitLabError } from './gitlab-error';
export type { GitLabErrorOptions } from './gitlab-error';

// API types exports
export { gitlabOAuthTokenResponseSchema } from './gitlab-api-types';
export type { GitLabOAuthTokenResponse } from './gitlab-api-types';

// OAuth exports
export { GitLabOAuthManager } from './gitlab-oauth-manager';
export type {
  GitLabOAuthTokens,
  OpenCodeAuth,
  OpenCodeAuthOAuth,
  OpenCodeAuthApi,
} from './gitlab-oauth-types';
export {
  BUNDLED_CLIENT_ID,
  OPENCODE_GITLAB_AUTH_CLIENT_ID,
  GITLAB_COM_URL,
  TOKEN_EXPIRY_SKEW_MS,
  OAUTH_SCOPES,
} from './gitlab-oauth-types';

// Project detection exports
export { GitLabProjectDetector } from './gitlab-project-detector';
export type { GitLabProjectDetectorConfig } from './gitlab-project-detector';
export { GitLabProjectCache } from './gitlab-project-cache';
export type { GitLabProject } from './gitlab-project-cache';

// Direct access exports
export { GitLabDirectAccessClient, DEFAULT_AI_GATEWAY_URL } from './gitlab-direct-access';
export type { GitLabDirectAccessConfig, DirectAccessToken } from './gitlab-direct-access';

// Workflow (DWS) exports
export { GitLabWorkflowLanguageModel } from './gitlab-workflow-language-model';
export type {
  GitLabWorkflowLanguageModelConfig,
  WorkflowToolExecutor,
} from './gitlab-workflow-language-model';
export { GitLabWorkflowClient } from './gitlab-workflow-client';
export type { WorkflowWebSocketOptions } from './gitlab-workflow-client';
export { GitLabWorkflowTokenClient } from './gitlab-workflow-token-client';
export type {
  GitLabWorkflowOptions,
  GitLabWorkflowClientConfig,
  McpToolDefinition,
  AdditionalContext,
  GenerateTokenResponse,
  WorkflowAction,
  WorkflowClientEvent,
  WorkflowStatus,
  NewCheckpoint,
  RunMcpTool,
  ClientEvent,
  StartRequest,
  ActionResponsePayload,
  ApprovalDecision,
} from './gitlab-workflow-types';
export {
  WorkflowType,
  DEFAULT_WORKFLOW_DEFINITION,
  DEFAULT_CLIENT_CAPABILITIES,
  CLIENT_VERSION,
  WS_KEEPALIVE_PING_INTERVAL_MS,
  WS_HEARTBEAT_INTERVAL_MS,
  AGENT_PRIVILEGES,
  DEFAULT_AGENT_PRIVILEGES,
  WORKFLOW_ENVIRONMENT,
} from './gitlab-workflow-types';
export { isWorkflowModel, getWorkflowModelRef } from './model-mappings';

// Model discovery exports
export { GitLabModelDiscovery } from './gitlab-model-discovery';
export type {
  AiModel,
  AiChatAvailableModels,
  DiscoveredModels,
  DiscoveryScope,
  ModelDiscoveryConfig,
} from './gitlab-model-discovery';

// Model cache exports
export { GitLabModelCache } from './gitlab-model-cache';
export type { ModelCacheEntry } from './gitlab-model-cache';

// Model config exports
export { GitLabModelConfigRegistry, parseModelsYml } from './gitlab-model-config';
export type { ModelConfig, ModelConfigRegistryOptions } from './gitlab-model-config';

// Workflow discovery exports
export { discoverWorkflowModels } from './gitlab-workflow-discovery';
export type {
  DiscoveredWorkflowModel,
  WorkflowDiscoveryConfig,
  WorkflowDiscoveryOptions,
  WorkflowDiscoveryResult,
} from './gitlab-workflow-discovery';
