/**
 * OAuth types and constants for GitLab authentication
 * Based on gitlab-vscode-extension and gitlab-lsp patterns
 */

export interface GitLabOAuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresAt: number; // Unix timestamp in milliseconds
  instanceUrl: string;
}

export interface OpenCodeAuthOAuth {
  type: 'oauth';
  refresh: string;
  access: string;
  expires: number; // Unix timestamp in milliseconds
  /** @deprecated Use enterpriseUrl instead. Kept for backwards compatibility with older auth.json files. */
  instanceUrl?: string;
  /** Instance URL as written by opencode-gitlab-auth plugin (e.g. 'https://gitlab.com') */
  enterpriseUrl?: string;
}

export interface OpenCodeAuthApi {
  type: 'api';
  key: string;
}

export type OpenCodeAuth = OpenCodeAuthOAuth | OpenCodeAuthApi;

/**
 * Default OAuth client ID for GitLab.com
 * This is the same client ID used by opencode-gitlab-auth plugin.
 * The GITLAB_OAUTH_CLIENT_ID env var takes precedence if set.
 * Note: VS Code extension uses a different client ID ('36f2a70c...') but we use the opencode plugin's ID
 * to ensure token refresh works correctly with tokens created by the auth plugin.
 */
export const OPENCODE_GITLAB_AUTH_CLIENT_ID =
  '1d89f9fdb23ee96d4e603201f6861dab6e143c5c3c00469a018a2d94bdc03d4e';

/**
 * @deprecated Use OPENCODE_GITLAB_AUTH_CLIENT_ID instead. This is the VS Code extension's client ID
 * and will cause refresh failures if used with tokens created by opencode-gitlab-auth.
 */
export const BUNDLED_CLIENT_ID = '36f2a70cddeb5a0889d4fd8295c241b7e9848e89cf9e599d0eed2d8e5350fbf5';

/**
 * GitLab.com URL constant
 */
export const GITLAB_COM_URL = 'https://gitlab.com';

/**
 * Token expiry skew in milliseconds (5 minutes)
 * Refresh tokens this many milliseconds before they expire
 */
export const TOKEN_EXPIRY_SKEW_MS = 5 * 60 * 1000;

/**
 * OAuth scopes to request
 */
export const OAUTH_SCOPES = ['api'];
