/**
 * DWS built-in tool mapping and shared security utilities.
 *
 * Extracted into a standalone module so both production code
 * (gitlab-workflow-language-model.ts) and tests can reference the
 * same implementation — preventing drift between a test shim and
 * the real logic.
 *
 * @internal — not part of the public API surface.
 */

import * as path from 'node:path';
import * as fs from 'node:fs';
import { GitLabError } from './gitlab-error';

/**
 * Reject strings containing shell metacharacters.
 * Used as a defence-in-depth check before shellEscape.
 */
export function validateNoShellMetachars(value: string, fieldName: string): void {
  const dangerousChars = /[;&|`$()<>]/;
  if (dangerousChars.test(value)) {
    throw new GitLabError({
      message: `Invalid ${fieldName}: contains shell metacharacters. Use structured arguments instead.`,
    });
  }
}

/**
 * Wrap a value in single quotes for safe use as a single shell argument.
 * Embedded single quotes are escaped with the '\'' idiom.
 */
export function shellEscape(arg: string): string {
  return "'" + String(arg).replace(/'/g, "'\\''") + "'";
}

const ALLOWED_URL_SCHEMES = ['http:', 'https:'];

/**
 * Validate a server-supplied path argument before forwarding it to a host tool.
 *
 * Absolute paths are passed through — the host's permission-gated tool system
 * is responsible for confining them. Relative paths must stay within the
 * current working directory (no `..` escapes), and null bytes are rejected.
 */
function validateMappedPath(value: unknown, fieldName: string): string {
  const filePath = String(value ?? '');
  if (filePath.includes('\0')) {
    throw new GitLabError({ message: `${fieldName} contains null bytes` });
  }
  if (filePath && !path.isAbsolute(filePath)) {
    const resolved = path.resolve(filePath);
    const cwd = process.cwd();
    if (!resolved.startsWith(cwd + path.sep) && resolved !== cwd) {
      throw new GitLabError({
        message: `${fieldName} resolves outside the working directory: ${filePath}`,
      });
    }
  }
  return filePath;
}

/**
 * Redact credential-like patterns from error messages before they are
 * forwarded to the stream or surfaced in UI.
 *
 * Patterns covered:
 *   - Bearer / token header values
 *   - GitLab PAT / CI tokens (glpat-*, glcbt-*, etc.)
 *   - URL query parameters: private_token, access_token, token
 *   - Basic auth in URLs: http://user:PASSWORD@host
 *   - Additional GitLab token prefixes (gldt, gloas, glrt, glsoat, glffct, glsapat)
 */
export function sanitizeErrorMessage(message: string): string {
  if (!message) return '';

  return message
    .replace(/\bBearer\s+[A-Za-z0-9\-_.~+/]+=*/gi, 'Bearer [REDACTED]')
    .replace(/\bgl(?:pat|oat|cbt|dt|oas|rt|soat|ffct|sapat)-[A-Za-z0-9_-]+/g, '[REDACTED]')
    .replace(/([?&](?:private_token|access_token|token)=)[^&\s"']*/gi, '$1[REDACTED]')
    .replace(/:\/\/([^:@/\s]+):([^@/\s]+)@/g, '://$1:[REDACTED]@');
}

/**
 * Map DWS built-in tool names and arguments to the corresponding
 * consumer tool names and argument formats.
 *
 * DWS uses protobuf-style tool names (runReadFile, runShellCommand, etc.)
 * while consumers like OpenCode use different names (read, bash, write, etc.)
 *
 * IMPORTANT: The returned `args` are structured objects passed to the host's
 * `toolExecutor` callback — they are NOT executed as raw shell commands by
 * this library. The host (e.g., OpenCode) is responsible for safely executing
 * the mapped tool through its own permission-gated tool system.
 */
export function mapBuiltinTool(
  dwsToolName: string,
  data: Record<string, unknown>,
  availableTools?: Set<string>
): { toolName: string; args: Record<string, unknown> } {
  const has = (name: string) => !availableTools || availableTools.has(name);

  switch (dwsToolName) {
    case 'runReadFile':
      return {
        toolName: 'read',
        args: { filePath: validateMappedPath(data.filepath, 'filepath') },
      };
    case 'runReadFiles': {
      const paths = ((data.filepaths as string[]) ?? []).map((p) =>
        validateMappedPath(p, 'filepath')
      );
      if (paths.length <= 1) {
        return { toolName: 'read', args: { filePath: paths[0] ?? '' } };
      }
      return {
        toolName: 'read',
        args: { filePaths: paths },
      };
    }
    case 'runWriteFile': {
      const writePath = validateMappedPath(data.filepath, 'filepath');
      if (has('write')) {
        return {
          toolName: 'write',
          args: { filePath: writePath, content: data.contents },
        };
      }
      // Fallback to apply_patch using the *** Begin/End Patch format
      const filePath = String(data.filepath ?? '');
      const content = String(data.contents ?? '');
      const patchLines = [
        '*** Begin Patch',
        `*** Add File: ${filePath}`,
        ...content.split('\n').map((l) => `+${l}`),
        '*** End Patch',
      ].join('\n');
      return { toolName: 'apply_patch', args: { patchText: patchLines } };
    }
    case 'runEditFile': {
      // Proto3 omitempty: empty strings are omitted from JSON, so these fields
      // may be absent (undefined) even when the LLM provided empty strings.
      // Default to '' so the edit tool's empty-oldString=create path is used.
      const editOldString = String(data.oldString ?? data.old_string ?? '');
      const editNewString = String(data.newString ?? data.new_string ?? '');
      const editFilePath = validateMappedPath(data.filepath, 'filepath');
      if (has('edit')) {
        return {
          toolName: 'edit',
          args: {
            filePath: editFilePath,
            oldString: editOldString,
            newString: editNewString,
          },
        };
      }
      // Fallback to apply_patch using the *** Begin/End Patch format
      const editPath = String(data.filepath ?? '');
      const oldStr = editOldString;
      const newStr = editNewString;
      const oldLines = oldStr.split('\n');
      const newLines = newStr.split('\n');
      // Empty context (@@ with no text) tells the parser to search from the start
      // of the file rather than seeking to a specific anchor line first. Using
      // the first old line as context would advance lineIndex past it, causing
      // the subsequent old_lines match to fail.
      const patchContent = [
        '*** Begin Patch',
        `*** Update File: ${editPath}`,
        '@@',
        ...oldLines.map((l) => `-${l}`),
        ...newLines.map((l) => `+${l}`),
        '*** End Patch',
      ].join('\n');
      return { toolName: 'apply_patch', args: { patchText: patchContent } };
    }
    case 'runShellCommand': {
      const command = data.command as string;
      if (!command || typeof command !== 'string') {
        throw new GitLabError({
          message: 'runShellCommand: command is required and must be a string',
        });
      }
      if (command.length > 10000) {
        throw new GitLabError({
          message: 'runShellCommand: command exceeds maximum length of 10000 characters',
        });
      }
      return {
        toolName: 'bash',
        args: { command, description: 'DWS shell command' },
      };
    }
    case 'runCommand': {
      const program = data.program as string;
      if (!program || typeof program !== 'string') {
        throw new GitLabError({ message: 'runCommand: program is required and must be a string' });
      }
      validateNoShellMetachars(program, 'program');

      const flags = (data.flags as string[]) ?? [];
      const cmdArgs = (data.arguments as string[]) ?? [];

      for (const flag of flags) {
        if (typeof flag === 'string') {
          validateNoShellMetachars(flag, 'flag');
        }
      }
      for (const arg of cmdArgs) {
        if (typeof arg === 'string') {
          validateNoShellMetachars(arg, 'argument');
        }
      }

      return {
        toolName: 'bash',
        args: {
          command: [program, ...flags, ...cmdArgs].map((a) => shellEscape(String(a))).join(' '),
          description: `DWS run: ${program}`,
        },
      };
    }
    case 'runGitCommand': {
      const gitCmd = data.command as string;
      if (!gitCmd || typeof gitCmd !== 'string') {
        throw new GitLabError({
          message: 'runGitCommand: command is required and must be a string',
        });
      }
      validateNoShellMetachars(gitCmd, 'git command');

      const gitArgs = (data.arguments as string[]) ?? [];
      for (const arg of gitArgs) {
        if (typeof arg === 'string') {
          validateNoShellMetachars(arg, 'git argument');
        }
      }
      return {
        toolName: 'bash',
        args: {
          command: ['git', gitCmd, ...gitArgs].map((a) => shellEscape(String(a))).join(' '),
          description: `DWS git: ${gitCmd}`,
        },
      };
    }
    case 'listDirectory':
      return {
        toolName: 'read',
        args: { filePath: validateMappedPath(data.directory ?? '.', 'directory') },
      };
    case 'findFiles':
      return { toolName: 'glob', args: { pattern: data.name_pattern ?? data.namePattern } };
    case 'grep':
      return {
        toolName: 'grep',
        args: {
          pattern: data.pattern,
          path: data.search_directory ?? data.searchDirectory,
        },
      };
    case 'mkdir': {
      const dirPath = String(data.directory_path ?? data.directoryPath ?? '');
      if (!dirPath) {
        throw new GitLabError({ message: 'mkdir: directory_path is required' });
      }
      if (dirPath.includes('\0')) {
        throw new GitLabError({ message: 'mkdir: directory_path contains null bytes' });
      }
      return {
        toolName: 'bash',
        args: {
          command: `mkdir -p ${shellEscape(dirPath)}`,
          description: 'DWS mkdir',
        },
      };
    }
    case 'runHTTPRequest': {
      const methodRaw = String(data.method ?? 'GET').toUpperCase();
      const allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];
      if (!allowedMethods.includes(methodRaw)) {
        throw new GitLabError({ message: `runHTTPRequest: invalid HTTP method '${methodRaw}'` });
      }

      const urlPath = String(data.path ?? '');
      if (!urlPath) {
        throw new GitLabError({ message: 'runHTTPRequest: path is required' });
      }

      let parsedUrl: URL | null = null;
      try {
        parsedUrl = new URL(urlPath);
      } catch {
        parsedUrl = null;
      }
      if (parsedUrl) {
        if (!ALLOWED_URL_SCHEMES.includes(parsedUrl.protocol)) {
          throw new GitLabError({
            message: `runHTTPRequest: only http:// and https:// schemes are allowed, got '${parsedUrl.protocol}'`,
          });
        }
      } else if (!urlPath.startsWith('/')) {
        throw new GitLabError({
          message:
            'runHTTPRequest: only http:// and https:// schemes are allowed, ' +
            `got a non-URL value '${urlPath}' (curl would guess the protocol)`,
        });
      }

      const method = shellEscape(methodRaw);
      const escapedPath = shellEscape(urlPath);
      const bodyArg = data.body ? ` -d ${shellEscape(String(data.body))}` : '';
      return {
        toolName: 'bash',
        args: {
          command: `curl -s -X ${method} -- ${escapedPath}${bodyArg}`,
          description: `DWS HTTP ${methodRaw}`,
        },
      };
    }
    default:
      return { toolName: dwsToolName, args: data };
  }
}

/**
 * Resolve symlinks on the deepest existing ancestor of a path so that
 * symlink-based escapes from the working directory are detected even
 * for paths that do not exist yet.
 */
function realpathDeepestExisting(targetPath: string): string {
  let current = targetPath;
  let suffix = '';
  for (;;) {
    try {
      const real = fs.realpathSync(current);
      return suffix ? path.join(real, suffix) : real;
    } catch {
      const parent = path.dirname(current);
      if (parent === current) {
        return targetPath;
      }
      suffix = suffix ? path.join(path.basename(current), suffix) : path.basename(current);
      current = parent;
    }
  }
}

/**
 * Validate that a file path resolves to within the current working directory.
 * Prevents path traversal attacks (e.g., `../../etc/passwd`), including
 * escapes through symlinks that point outside the working directory.
 */
export function validateSafePath(filePath: string): string {
  if (!filePath) {
    throw new GitLabError({ message: 'filePath is required' });
  }
  if (filePath.includes('\0')) {
    throw new GitLabError({ message: 'filePath contains null bytes' });
  }
  const resolved = path.resolve(filePath);
  const cwd = process.cwd();
  if (!resolved.startsWith(cwd + path.sep) && resolved !== cwd) {
    throw new GitLabError({
      message: `filePath resolves outside the working directory: ${filePath}`,
    });
  }
  const realResolved = realpathDeepestExisting(resolved);
  const realCwd = realpathDeepestExisting(cwd);
  if (!realResolved.startsWith(realCwd + path.sep) && realResolved !== realCwd) {
    throw new GitLabError({
      message: `filePath resolves outside the working directory: ${filePath}`,
    });
  }
  return resolved;
}

/**
 * Direct file operation fallback for when the host doesn't have edit/write
 * tools (e.g., GPT models that use apply_patch instead).
 *
 * This performs the same string-replacement logic as the host's `edit` tool
 * but without requiring the tool to be registered. It runs synchronously
 * using Node.js fs so that DWS builtins always succeed regardless of the
 * host's tool configuration.
 *
 * All file paths are validated to be within the current working directory
 * to prevent path traversal attacks.
 *
 * Returns null if the tool is not one we can handle as a fallback.
 */
export function executeBuiltinFallback(
  toolName: string,
  argsJson: string
): {
  result: string;
  error?: string | null;
  metadata?: Record<string, unknown>;
  title?: string;
} | null {
  if (toolName !== 'edit' && toolName !== 'write') {
    return null;
  }

  let args: Record<string, unknown>;
  try {
    args = JSON.parse(argsJson);
  } catch {
    return { result: '', error: `${toolName} fallback: invalid JSON arguments` };
  }

  try {
    if (toolName === 'write') {
      const filePath = String(args.filePath ?? '');
      if (!filePath) {
        return { result: '', error: 'write fallback: filePath is required' };
      }
      const safePath = validateSafePath(filePath);
      const content = String(args.content ?? '');
      fs.writeFileSync(safePath, content, 'utf-8');
      return {
        result: 'File written successfully.',
        title: filePath,
        metadata: { output: 'File written successfully.' },
      };
    }

    const filePath = String(args.filePath ?? '');
    const oldString = String(args.oldString ?? '');
    const newString = String(args.newString ?? '');

    if (!filePath) {
      return { result: '', error: 'edit fallback: filePath is required' };
    }
    if (!oldString && !newString) {
      return { result: '', error: 'edit fallback: oldString and newString are both empty' };
    }

    const safePath = validateSafePath(filePath);

    let content: string;
    try {
      content = fs.readFileSync(safePath, 'utf-8');
    } catch {
      content = '';
    }

    if (oldString === '') {
      fs.writeFileSync(safePath, newString, 'utf-8');
      return {
        result: 'Edit applied successfully.',
        title: filePath,
        metadata: { output: 'Edit applied successfully.' },
      };
    }

    const idx = content.indexOf(oldString);
    if (idx === -1) {
      return { result: '', error: `edit fallback: could not find oldString in ${filePath}` };
    }

    const newContent =
      content.substring(0, idx) + newString + content.substring(idx + oldString.length);
    fs.writeFileSync(safePath, newContent, 'utf-8');

    return {
      result: 'Edit applied successfully.',
      title: filePath,
      metadata: { output: 'Edit applied successfully.' },
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return { result: '', error: sanitizeErrorMessage(msg) };
  }
}
