export type ModelProvider = 'anthropic' | 'openai' | 'workflow';

export type OpenAIApiType = 'chat' | 'responses';

export interface ModelMapping {
  provider: ModelProvider;
  model: string;
  /** For OpenAI models, which API to use: 'chat' for /v1/chat/completions, 'responses' for /v1/responses */
  openaiApiType?: OpenAIApiType;
}

export const MODEL_MAPPINGS: Record<string, ModelMapping> = {
  // Anthropic models
  'duo-chat-fable-5-1': { provider: 'anthropic', model: 'claude-fable-5-1' },
  'duo-chat-fable-5': { provider: 'anthropic', model: 'claude-fable-5' },
  'duo-chat-opus-5-5': { provider: 'anthropic', model: 'claude-opus-5-5' },
  'duo-chat-opus-5': { provider: 'anthropic', model: 'claude-opus-5' },
  'duo-chat-opus-4-8': { provider: 'anthropic', model: 'claude-opus-4-8' },
  'duo-chat-opus-4-7': { provider: 'anthropic', model: 'claude-opus-4-7' },
  'duo-chat-opus-4-6': { provider: 'anthropic', model: 'claude-opus-4-6' },
  'duo-chat-sonnet-5-5': { provider: 'anthropic', model: 'claude-sonnet-5-5' },
  'duo-chat-sonnet-5': { provider: 'anthropic', model: 'claude-sonnet-5' },
  'duo-chat-sonnet-4-6': { provider: 'anthropic', model: 'claude-sonnet-4-6' },
  'duo-chat-opus-4-5': { provider: 'anthropic', model: 'claude-opus-4-5-20251101' },
  'duo-chat-sonnet-4-5': { provider: 'anthropic', model: 'claude-sonnet-4-5-20250929' },
  'duo-chat-haiku-5-5': { provider: 'anthropic', model: 'claude-haiku-5-5' },
  'duo-chat-haiku-4-5': { provider: 'anthropic', model: 'claude-haiku-4-5-20251001' },

  // OpenAI models - Responses API
  // GPT-6 models reject `reasoning_effort` with function tools on Chat Completions;
  // they must use the Responses API (matches OpenAI's own routing for GPT-5.x/GPT-6).
  'duo-chat-gpt-6-astra': { provider: 'openai', model: 'gpt-6-astra', openaiApiType: 'responses' },
  'duo-chat-gpt-6-1-sol': { provider: 'openai', model: 'gpt-6.1-sol', openaiApiType: 'responses' },
  'duo-chat-gpt-6-sol': { provider: 'openai', model: 'gpt-6-sol', openaiApiType: 'responses' },
  'duo-chat-gpt-6-luna': { provider: 'openai', model: 'gpt-6-luna', openaiApiType: 'responses' },

  // OpenAI models - Chat Completions API
  'duo-chat-gpt-5-1': { provider: 'openai', model: 'gpt-5.1-2025-11-13', openaiApiType: 'chat' },
  'duo-chat-gpt-5-2': { provider: 'openai', model: 'gpt-5.2-2025-12-11', openaiApiType: 'chat' },
  'duo-chat-gpt-5-4': { provider: 'openai', model: 'gpt-5.4-2026-03-05', openaiApiType: 'chat' },
  'duo-chat-gpt-5-5': { provider: 'openai', model: 'gpt-5.5-2026-04-23', openaiApiType: 'chat' },
  'duo-chat-gpt-5-mini': {
    provider: 'openai',
    model: 'gpt-5-mini-2025-08-07',
    openaiApiType: 'chat',
  },
  'duo-chat-gpt-5-4-mini': { provider: 'openai', model: 'gpt-5.4-mini', openaiApiType: 'chat' },
  'duo-chat-gpt-5-4-nano': { provider: 'openai', model: 'gpt-5.4-nano', openaiApiType: 'chat' },

  // OpenAI models - Responses API
  // GPT-5.6 rejects `reasoning_effort` with function tools on Chat Completions;
  // it must use the Responses API (matches OpenAI's own routing for GPT-5.x).
  'duo-chat-gpt-5-6-sol': { provider: 'openai', model: 'gpt-5.6-sol', openaiApiType: 'responses' },
  'duo-chat-gpt-5-6-terra': {
    provider: 'openai',
    model: 'gpt-5.6-terra',
    openaiApiType: 'responses',
  },
  'duo-chat-gpt-5-6-luna': {
    provider: 'openai',
    model: 'gpt-5.6-luna',
    openaiApiType: 'responses',
  },

  // OpenAI models - Responses API (Codex models)
  'duo-chat-gpt-5-codex': { provider: 'openai', model: 'gpt-5-codex', openaiApiType: 'responses' },
  'duo-chat-gpt-5-2-codex': {
    provider: 'openai',
    model: 'gpt-5.2-codex',
    openaiApiType: 'responses',
  },
  'duo-chat-gpt-5-3-codex': {
    provider: 'openai',
    model: 'gpt-5.3-codex',
    openaiApiType: 'responses',
  },

  // Duo Agent Platform model (server-side agentic via DWS WebSocket).
  // This is the single user-facing model ID. The actual underlying model ref
  // is resolved dynamically at runtime via GitLabModelDiscovery.
  'duo-workflow': { provider: 'workflow', model: 'default' },

  // Internal model refs — kept for backwards compatibility and direct use.
  // Not intended as user-facing model IDs.
  'duo-workflow-default': { provider: 'workflow', model: 'default' },
  'duo-workflow-sonnet-4-5': {
    provider: 'workflow',
    model: 'claude_sonnet_4_5_20250929',
  },
  'duo-workflow-sonnet-5-5': { provider: 'workflow', model: 'claude_sonnet_5_5' },
  'duo-workflow-sonnet-5': { provider: 'workflow', model: 'claude_sonnet_5' },
  'duo-workflow-opus-5-5': { provider: 'workflow', model: 'claude_opus_5_5' },
  'duo-workflow-opus-5': { provider: 'workflow', model: 'claude_opus_5' },
  'duo-workflow-sonnet-4-6': { provider: 'workflow', model: 'claude_sonnet_4_6' },
  'duo-workflow-opus-4-5': {
    provider: 'workflow',
    model: 'claude_opus_4_5_20251101',
  },
  'duo-workflow-haiku-4-5': { provider: 'workflow', model: 'claude_haiku_4_5_20251001' },
  'duo-workflow-haiku-5-5': { provider: 'workflow', model: 'claude_haiku_5_5' },
  'duo-workflow-opus-4-6': { provider: 'workflow', model: 'claude_opus_4_6_20260205' },
  'duo-workflow-gemini-4-argon': { provider: 'workflow', model: 'gemini_4_argon_vertex' },
};

export function getModelMapping(modelId: string): ModelMapping | undefined {
  return MODEL_MAPPINGS[modelId];
}

export function getProviderForModelId(modelId: string): ModelProvider | undefined {
  return MODEL_MAPPINGS[modelId]?.provider;
}

export function getValidModelsForProvider(provider: ModelProvider): string[] {
  return Object.values(MODEL_MAPPINGS)
    .filter((m) => m.provider === provider)
    .map((m) => m.model);
}

export function getAnthropicModelForModelId(modelId: string): string | undefined {
  const mapping = MODEL_MAPPINGS[modelId];
  return mapping?.provider === 'anthropic' ? mapping.model : undefined;
}

export function getOpenAIModelForModelId(modelId: string): string | undefined {
  const mapping = MODEL_MAPPINGS[modelId];
  return mapping?.provider === 'openai' ? mapping.model : undefined;
}

export function getOpenAIApiType(modelId: string): OpenAIApiType {
  const mapping = MODEL_MAPPINGS[modelId];
  return mapping?.openaiApiType ?? 'chat';
}

export function isResponsesApiModel(modelId: string): boolean {
  return getOpenAIApiType(modelId) === 'responses';
}

export function isWorkflowModel(modelId: string): boolean {
  return MODEL_MAPPINGS[modelId]?.provider === 'workflow';
}

export function getWorkflowModelRef(modelId: string): string | undefined {
  const mapping = MODEL_MAPPINGS[modelId];
  return mapping?.provider === 'workflow' ? mapping.model : undefined;
}

export const MODEL_ID_TO_ANTHROPIC_MODEL: Record<string, string> = Object.fromEntries(
  Object.entries(MODEL_MAPPINGS)
    .filter(([, v]) => v.provider === 'anthropic')
    .map(([k, v]) => [k, v.model])
);
