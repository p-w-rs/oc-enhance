/**
 * Simple in-memory cache for GitLab project information
 * Used to avoid repeated API calls when detecting projects from git remotes
 */

export interface GitLabProject {
  id: number;
  path: string;
  pathWithNamespace: string;
  name: string;
  namespaceId?: number;
}

interface CacheEntry {
  project: GitLabProject;
  expiresAt: number;
}

/**
 * In-memory cache for GitLab project information with TTL support
 */
export class GitLabProjectCache {
  private cache = new Map<string, CacheEntry>();
  private defaultTTL: number;

  /**
   * Create a new project cache
   * @param defaultTTL - Default time-to-live in milliseconds (default: 5 minutes)
   */
  constructor(defaultTTL: number = 5 * 60 * 1000) {
    this.defaultTTL = defaultTTL;
  }

  /**
   * Get a cached project by key
   * @param key - Cache key (typically the working directory path)
   * @returns The cached project or null if not found or expired
   */
  get(key: string): GitLabProject | null {
    const entry = this.cache.get(key);
    if (!entry) {
      return null;
    }

    // Check if entry has expired
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }

    return entry.project;
  }

  /**
   * Store a project in the cache
   * @param key - Cache key (typically the working directory path)
   * @param project - The project to cache
   * @param ttl - Optional custom TTL in milliseconds
   */
  set(key: string, project: GitLabProject, ttl?: number): void {
    this.cache.set(key, {
      project,
      expiresAt: Date.now() + (ttl ?? this.defaultTTL),
    });
  }

  /**
   * Check if a key exists in the cache (and is not expired)
   * @param key - Cache key to check
   * @returns true if the key exists and is not expired
   */
  has(key: string): boolean {
    return this.get(key) !== null;
  }

  /**
   * Remove a specific entry from the cache
   * @param key - Cache key to remove
   */
  delete(key: string): void {
    this.cache.delete(key);
  }

  /**
   * Clear all entries from the cache
   */
  clear(): void {
    this.cache.clear();
  }

  /**
   * Get the number of entries in the cache (including expired ones)
   */
  get size(): number {
    return this.cache.size;
  }

  /**
   * Clean up expired entries from the cache
   * This is useful for long-running processes to prevent memory leaks
   */
  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (now > entry.expiresAt) {
        this.cache.delete(key);
      }
    }
  }
}
