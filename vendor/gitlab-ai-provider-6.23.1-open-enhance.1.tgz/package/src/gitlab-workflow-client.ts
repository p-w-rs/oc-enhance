/**
 * WebSocket client for the GitLab Duo Agent Platform (DWS).
 *
 * Handles:
 * - WebSocket connection to `wss://{instance}/api/v4/ai/duo_workflows/ws`
 * - Sending ClientEvent messages (startRequest, actionResponse, stopWorkflow)
 * - Receiving WorkflowAction messages (newCheckpoint, runMcpTool, built-in tools)
 * - Dual heartbeat: ws.ping(45s) + JSON heartbeat(60s) — matching gitlab-lsp
 * - No reconnection on drop (matches gitlab-lsp behavior)
 */

import WebSocket from 'isomorphic-ws';
import { VERSION } from './version';
import type {
  ClientEvent,
  WorkflowAction,
  StartRequest,
  ActionResponsePayload,
  WorkflowClientEvent,
  CheckpointData,
  UiChatLogEntry,
  UiChatLogToolInfo,
  NewCheckpoint,
} from './gitlab-workflow-types';
import {
  WS_KEEPALIVE_PING_INTERVAL_MS,
  WS_HEARTBEAT_INTERVAL_MS,
  WS_CLOSE_WAIT_TIMEOUT_MS,
  STOP_REASON_USER,
  CLIENT_VERSION,
} from './gitlab-workflow-types';
import { GitLabError } from './gitlab-error';

const WS_CONNECT_TIMEOUT_MS = 30_000;

export interface WorkflowWebSocketOptions {
  /** GitLab instance URL */
  instanceUrl: string;
  /** Model reference for DWS (e.g. 'anthropic/claude-sonnet-4-5-20250929' or 'default') */
  modelRef: string;
  /** Auth headers — must include Authorization */
  headers: Record<string, string>;
  /** Optional correlation ID */
  requestId?: string;
  /** Optional project context */
  projectId?: string;
  namespaceId?: string;
  rootNamespaceId?: string;
  /** AI Catalog item version ID — required for Workhorse to inject MCP tools */
  aiCatalogItemVersionId?: number;
  /** Workflow definition type (e.g. 'chat') — used by Workhorse for MCP config */
  workflowDefinition?: string;
}

type EventCallback = (event: WorkflowClientEvent) => void;

export class GitLabWorkflowClient {
  private socket: WebSocket | null = null;
  private keepaliveInterval: ReturnType<typeof setInterval> | null = null;
  private heartbeatInterval: ReturnType<typeof setInterval> | null = null;
  private eventCallback: EventCallback | null = null;
  private closed = false;
  private closedEmitted = false;
  private lastSendTime = 0;

  /**
   * Connect to the DWS WebSocket and start listening for events.
   *
   * @param options - Connection parameters
   * @param onEvent - Callback invoked for each WorkflowClientEvent
   * @returns Promise that resolves when the connection is open
   */
  connect(options: WorkflowWebSocketOptions, onEvent: EventCallback): Promise<void> {
    this.validateOptions(options);
    this.disposeSocket();
    this.eventCallback = onEvent;
    this.closed = false;
    this.closedEmitted = false;
    this.cleanedUp = false;

    return new Promise<void>((resolve, reject) => {
      const wsUrl = this.buildWebSocketUrl(options);
      const wsHeaders = this.buildWebSocketHeaders(options);

      this.socket = new WebSocket(wsUrl, { headers: wsHeaders });
      let resolved = false;

      const connectTimer = setTimeout(() => {
        if (resolved) return;
        resolved = true;
        const sock = this.socket;
        this.socket = null;
        try {
          sock?.close(1000, 'Connect timeout');
        } catch {
          // socket may already be closed
        }
        reject(
          new GitLabError({
            message: `WebSocket connect timed out after ${WS_CONNECT_TIMEOUT_MS}ms`,
          })
        );
      }, WS_CONNECT_TIMEOUT_MS);

      this.socket.onopen = () => {
        clearTimeout(connectTimer);
        if (resolved) return;
        resolved = true;
        this.startKeepalive();
        this.startHeartbeat();
        resolve();
      };

      this.socket.onmessage = (event: WebSocket.MessageEvent) => {
        try {
          const data = this.decodeMessageData(event.data);
          const action = JSON.parse(data) as WorkflowAction;

          // Basic validation of message structure
          if (!action || typeof action !== 'object') {
            throw new GitLabError({ message: 'Invalid message structure: expected object' });
          }

          this.handleAction(action);
        } catch (error) {
          this.emit({
            type: 'failed',
            error: error instanceof Error ? error : new Error(String(error)),
          });
        }
      };

      this.socket.onerror = (event: WebSocket.ErrorEvent) => {
        const error = new GitLabError({
          message: `WebSocket error: ${event.message || 'unknown'}`,
        });
        if (!resolved) {
          clearTimeout(connectTimer);
          resolved = true;
          reject(error);
        } else {
          this.emit({ type: 'failed', error });
        }
      };

      this.socket.onclose = (event: WebSocket.CloseEvent) => {
        this.cleanup();
        if (!resolved) {
          clearTimeout(connectTimer);
          resolved = true;
          reject(
            new GitLabError({
              message: `WebSocket closed before open: code=${event.code} reason=${event.reason || ''}`,
            })
          );
          return;
        }
        if (!this.closed) {
          this.emitClosed(event.code, event.reason || '');
        }
      };
    });
  }

  /**
   * Send a startRequest to begin the workflow.
   */
  sendStartRequest(request: StartRequest): void {
    this.send({ startRequest: request });
  }

  /**
   * Send an actionResponse (tool result) back to DWS.
   */
  sendActionResponse(requestID: string, response: string, error?: string | null): void {
    this.sendHeartbeatIfNeeded();
    const payload: ActionResponsePayload = {
      requestID,
      plainTextResponse: {
        response,
        error: error ?? null,
      },
    };
    this.send({ actionResponse: payload });
  }

  /**
   * Stop the workflow gracefully.
   *
   * Sends a stopWorkflow event, then closes the socket and clears all
   * timers so no heartbeats keep firing if the server never closes.
   */
  stop(): void {
    this.send({ stopWorkflow: { reason: STOP_REASON_USER } });
    this.closed = true;
    this.cleanup();
    const sock = this.socket;
    this.socket = null;
    if (sock && (sock.readyState === WebSocket.OPEN || sock.readyState === WebSocket.CONNECTING)) {
      sock.close(1000, 'Client stopping');
    }
  }

  /**
   * Close the WebSocket connection.
   */
  close(): void {
    // Set closed flag first to prevent race conditions
    if (this.closed) return;
    this.closed = true;

    this.cleanup();
    const sock = this.socket;
    this.socket = null;
    if (sock) {
      if (sock.readyState === WebSocket.OPEN || sock.readyState === WebSocket.CONNECTING) {
        sock.close(1000, 'Client closing');
      }
    }
  }

  /**
   * Close the socket and wait for the close handshake to actually land.
   *
   * `close()` returns as soon as the close frame is queued. That is too early
   * when the caller is about to reconnect to the same workflow, because
   * Workhorse releases the workflow lock only once its own stop handshake with
   * DWS completes. Awaiting `onclose` (or the timeout) keeps the reconnect from
   * racing the lock and getting rejected with close code 1013.
   *
   * Best effort: never rejects, and resolves after `timeoutMs` if the server
   * never answers.
   *
   * @param timeoutMs - Maximum time to wait for the close event
   * @default WS_CLOSE_WAIT_TIMEOUT_MS
   */
  closeAndWait(timeoutMs: number = WS_CLOSE_WAIT_TIMEOUT_MS): Promise<void> {
    const sock = this.socket;
    const pending =
      sock && (sock.readyState === WebSocket.OPEN || sock.readyState === WebSocket.CONNECTING);
    if (this.closed || !pending) {
      this.close();
      return Promise.resolve();
    }

    return new Promise<void>((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve();
      };
      const timer = setTimeout(finish, timeoutMs);
      const previous = sock.onclose;
      sock.onclose = (event: WebSocket.CloseEvent) => {
        try {
          previous?.call(sock, event);
        } finally {
          finish();
        }
      };
      this.close();
    });
  }

  /**
   * Check if the WebSocket is currently connected.
   */
  get isConnected(): boolean {
    return this.socket?.readyState === WebSocket.OPEN;
  }

  // ---------------------------------------------------------------------------
  // Private
  // ---------------------------------------------------------------------------

  private validateOptions(options: WorkflowWebSocketOptions): void {
    if (!options.instanceUrl || typeof options.instanceUrl !== 'string') {
      throw new GitLabError({ message: 'instanceUrl is required' });
    }
    const parsed = new URL(options.instanceUrl);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      throw new GitLabError({ message: `Invalid instanceUrl protocol: ${parsed.protocol}` });
    }
    if (parsed.username || parsed.password) {
      throw new GitLabError({
        message: 'instanceUrl must not contain authentication credentials (username/password)',
      });
    }
    if (!options.headers || typeof options.headers !== 'object') {
      throw new GitLabError({ message: 'headers are required' });
    }
    if (options.modelRef && typeof options.modelRef !== 'string') {
      throw new GitLabError({ message: 'modelRef must be a string' });
    }
  }

  private buildWebSocketUrl(options: WorkflowWebSocketOptions): string {
    // NO workflow_id in URL (it goes in startRequest.workflowID instead)
    const baseUrl = new URL(options.instanceUrl.replace(/\/?$/, '/'));
    const url = new URL('./api/v4/ai/duo_workflows/ws', baseUrl);
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    if (options.modelRef && options.modelRef !== 'default') {
      url.searchParams.set('user_selected_model_identifier', options.modelRef);
    }
    if (options.aiCatalogItemVersionId) {
      url.searchParams.set('ai_catalog_item_version_id', String(options.aiCatalogItemVersionId));
    }
    if (options.workflowDefinition) {
      url.searchParams.set('workflow_definition', options.workflowDefinition);
    }
    return url.toString();
  }

  private buildWebSocketHeaders(options: WorkflowWebSocketOptions): Record<string, string> {
    // Normalize incoming headers to lowercase keys to avoid duplicates
    const headers: Record<string, string> = {};
    for (const [key, value] of Object.entries(options.headers)) {
      headers[key.toLowerCase()] = value;
    }

    // Remove Content-Type — WebSocket upgrade (RFC 6455 §4.1) uses no body;
    // sending Content-Type can confuse proxies and fails some server checks.
    delete headers['content-type'];

    headers['x-gitlab-client-type'] = 'node-websocket';
    headers['x-gitlab-language-server-version'] = CLIENT_VERSION;

    // Origin header — required by gitlab-lsp, validates WebSocket security
    // The origin is derived from the validated instanceUrl (already checked in validateOptions)
    const parsedUrl = new URL(options.instanceUrl);
    const origin = parsedUrl.origin;
    headers['origin'] = origin;

    if (options.requestId) {
      headers['x-request-id'] = options.requestId;
    }
    if (options.projectId) {
      headers['x-gitlab-project-id'] = options.projectId;
    }
    if (options.namespaceId) {
      headers['x-gitlab-namespace-id'] = options.namespaceId;
    }
    if (options.rootNamespaceId) {
      headers['x-gitlab-root-namespace-id'] = options.rootNamespaceId;
    }

    // User-Agent — set only if not already provided
    if (!headers['user-agent']) {
      headers['user-agent'] = `gitlab-ai-provider/${VERSION}`;
    }

    return headers;
  }

  private handleAction(action: WorkflowAction): void {
    // Checkpoint (text/status from LLM)
    if (action.newCheckpoint) {
      const checkpoint = action.newCheckpoint;

      this.emit({ type: 'checkpoint', data: checkpoint });

      if (checkpoint.status === 'FINISHED' || checkpoint.status === 'COMPLETED') {
        this.emit({ type: 'completed' });
      } else if (checkpoint.status === 'FAILED') {
        this.emit({
          type: 'failed',
          error: new Error(checkpoint.content || 'Workflow failed'),
        });
      } else if (checkpoint.status === 'STOPPED' || checkpoint.status === 'CANCELLED') {
        this.emit({ type: 'completed' });
      } else if (checkpoint.status === 'TOOL_CALL_APPROVAL_REQUIRED') {
        this.emit({ type: 'approval-required', tools: this.extractApprovalTools(checkpoint) });
      } else if (checkpoint.status === 'PLAN_APPROVAL_REQUIRED') {
        this.emit({
          type: 'failed',
          error: new GitLabError({
            message: 'Workflow requires plan approval, which is not supported by this client',
          }),
        });
      }
      return;
    }

    // MCP tool invocation
    if (action.runMCPTool) {
      if (!action.requestID) {
        this.emit({
          type: 'failed',
          error: new GitLabError({
            message: 'Received runMCPTool action without requestID; workflow cannot continue',
          }),
        });
        return;
      }
      this.emit({
        type: 'tool-request',
        requestID: action.requestID,
        data: action.runMCPTool,
      });
      return;
    }

    // Built-in tool invocations — field names match DWS protobuf wire format
    const builtinTools: Array<[string, unknown]> = [
      ['runReadFile', action.runReadFile],
      ['runReadFiles', action.runReadFiles],
      ['runWriteFile', action.runWriteFile],
      ['runShellCommand', action.runShellCommand],
      ['runEditFile', action.runEditFile],
      ['listDirectory', action.listDirectory],
      ['findFiles', action.findFiles],
      ['grep', action.grep],
      ['mkdir', action.mkdir],
      ['runCommand', action.runCommand],
      ['runGitCommand', action.runGitCommand],
      ['runHTTPRequest', action.runHTTPRequest],
    ];

    for (const [toolName, data] of builtinTools) {
      if (data) {
        if (!action.requestID) {
          this.emit({
            type: 'failed',
            error: new GitLabError({
              message: `Received ${toolName} action without requestID; workflow cannot continue`,
            }),
          });
          return;
        }
        this.emit({
          type: 'builtin-tool-request',
          requestID: action.requestID,
          toolName,
          data: data as Record<string, unknown>,
        });
        return;
      }
    }
  }

  private extractApprovalTools(checkpoint: NewCheckpoint): Array<{ name: string; args: string }> {
    if (!checkpoint.checkpoint) return [];
    let parsed: CheckpointData;
    try {
      parsed = JSON.parse(checkpoint.checkpoint);
    } catch {
      return [];
    }
    return (parsed.channel_values?.ui_chat_log ?? [])
      .filter(
        (e): e is UiChatLogEntry & { tool_info: UiChatLogToolInfo } =>
          e.message_type === 'request' && e.tool_info !== null
      )
      .map((e) => ({ name: e.tool_info.name, args: JSON.stringify(e.tool_info.args) }));
  }

  private send(event: ClientEvent): void {
    if (this.socket?.readyState === WebSocket.OPEN) {
      const json = JSON.stringify(event);
      this.socket.send(json);
      this.lastSendTime = Date.now();
    }
  }

  private sendHeartbeatIfNeeded(): void {
    const elapsed = Date.now() - this.lastSendTime;
    if (elapsed >= WS_HEARTBEAT_INTERVAL_MS / 2) {
      this.send({ heartbeat: { timestamp: Date.now() } });
    }
  }

  private emit(event: WorkflowClientEvent): void {
    this.eventCallback?.(event);
  }

  /**
   * Emit the 'closed' event exactly once.
   */
  private emitClosed(code: number, reason: string): void {
    if (this.closedEmitted) return;
    this.closedEmitted = true;
    this.emit({ type: 'closed', code, reason });
  }

  /**
   * Decode an incoming WebSocket frame to a UTF-8 string.
   * Handles string, Buffer, ArrayBuffer and Buffer[] payloads.
   */
  private decodeMessageData(data: WebSocket.Data): string {
    if (typeof data === 'string') return data;
    if (Array.isArray(data)) {
      return Buffer.concat(data).toString('utf8');
    }
    if (data instanceof ArrayBuffer) {
      return Buffer.from(data).toString('utf8');
    }
    return Buffer.from(data as Uint8Array).toString('utf8');
  }

  /**
   * Detach and close any existing socket before creating a new one.
   * Prevents socket and interval leaks on repeated connect() calls.
   */
  private disposeSocket(): void {
    this.cleanup();
    const sock = this.socket;
    this.socket = null;
    if (sock) {
      sock.onopen = null as never;
      sock.onmessage = null as never;
      sock.onerror = null as never;
      sock.onclose = null as never;
      if (sock.readyState === WebSocket.OPEN || sock.readyState === WebSocket.CONNECTING) {
        try {
          sock.close(1000, 'Reconnecting');
        } catch {
          // socket may already be closed
        }
      }
    }
  }

  /**
   * Start ws.ping() keepalive (45s interval).
   * Keeps TCP connection alive through proxies/load balancers.
   */
  private startKeepalive(): void {
    if (this.keepaliveInterval) {
      clearInterval(this.keepaliveInterval);
    }
    this.keepaliveInterval = setInterval(() => {
      if (this.socket?.readyState === WebSocket.OPEN) {
        // ws-specific ping (not available in browser WebSocket, but
        // isomorphic-ws in Node.js delegates to the ws library)
        try {
          (this.socket as unknown as { ping: () => void }).ping();
        } catch {
          // Browser WebSocket doesn't have ping — silently skip
        }
      }
    }, WS_KEEPALIVE_PING_INTERVAL_MS);
  }

  /**
   * Start application-level heartbeat (60s interval).
   * Prevents DWS from timing out the workflow.
   */
  private startHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    this.heartbeatInterval = setInterval(() => {
      this.send({ heartbeat: { timestamp: Date.now() } });
    }, WS_HEARTBEAT_INTERVAL_MS);
  }

  private cleanedUp = false;

  /**
   * Clean up intervals. Idempotent — safe to call multiple times.
   */
  private cleanup(): void {
    if (this.cleanedUp) return;
    this.cleanedUp = true;

    if (this.keepaliveInterval) {
      clearInterval(this.keepaliveInterval);
      this.keepaliveInterval = null;
    }
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }
}
