/**
 * Token management for the GitLab Duo Agent Platform (DWS).
 *
 * Handles two API calls:
 * 1. POST /api/v4/ai/duo_workflows/direct_access  → GenerateTokenResponse (workflow token)
 * 2. POST /api/v4/ai/duo_workflows/workflows       → CreateWorkflowResponse (workflow ID)
 *
 * Tokens are cached for 25 minutes (they expire after ~30 minutes).
 * On 401, optionally triggers an API key refresh callback and retries once.
 * On 403, throws a clear error explaining GitLab Duo Enterprise requirements.
 */

import { GitLabError } from './gitlab-error';
import { sanitizeErrorMessage } from './gitlab-workflow-builtins';
import type {
  GenerateTokenResponse,
  CreateWorkflowResponse,
  GitLabWorkflowClientConfig,
} from './gitlab-workflow-types';

import {
  DEFAULT_WORKFLOW_DEFINITION,
  DEFAULT_AGENT_PRIVILEGES,
  WORKFLOW_ENVIRONMENT,
  WorkflowType,
} from './gitlab-workflow-types';

/** Cache duration: 25 minutes (tokens expire at ~30 minutes) */
const TOKEN_CACHE_DURATION_MS = 25 * 60 * 1000;

const MAX_ERROR_TEXT_LENGTH = 500;

/**
 * Truncate and redact credential-like patterns from raw error response text
 * before embedding it in error messages.
 *
 * @param text - Raw error response body
 * @returns Sanitized text, truncated to 500 characters
 */
export function sanitizeErrorText(text: string): string {
  const truncated =
    text.length > MAX_ERROR_TEXT_LENGTH ? text.slice(0, MAX_ERROR_TEXT_LENGTH) + '...' : text;
  return sanitizeErrorMessage(truncated);
}

/**
 * Shared token cache key for CHAT workflows.
 * CHAT tokens are shared across all sessions (matching gitlab-lsp behavior).
 */
const CHAT_SHARED_TOKEN_KEY = '__chat_shared__';

interface CachedToken {
  token: GenerateTokenResponse;
  expiresAt: number;
}

export class GitLabWorkflowTokenClient {
  private readonly config: GitLabWorkflowClientConfig;
  private readonly fetchFn: typeof fetch;

  /**
   * Token cache keyed by workflow definition type.
   *
   * - CHAT workflows use a shared key (CHAT_SHARED_TOKEN_KEY) so tokens
   *   are reused across ALL chat sessions (matching gitlab-lsp behavior).
   * - SOFTWARE_DEVELOPMENT workflows would use per-workflow-id keys,
   *   but since we fetch tokens before creating workflows, we key by type.
   */
  private tokenCache = new Map<string, CachedToken>();

  constructor(config: GitLabWorkflowClientConfig) {
    this.config = config;
    this.fetchFn = config.fetch ?? fetch;
  }

  /**
   * Resolve the cache key for a given workflow definition.
   * CHAT workflows share a single token per namespace; other types get per-type keys.
   */
  private getCacheKey(workflowDefinition: string, rootNamespaceId?: string): string {
    const base =
      workflowDefinition === WorkflowType.CHAT ? CHAT_SHARED_TOKEN_KEY : workflowDefinition;
    return rootNamespaceId ? `${base}:${rootNamespaceId}` : base;
  }

  /**
   * Get a DWS token, using cached value if still valid.
   *
   * Token caching strategy (matches gitlab-lsp):
   * - CHAT workflows: shared token across all sessions
   * - Other workflows: per-type token
   *
   * @param workflowDefinition - Workflow type (default: 'chat')
   * @param rootNamespaceId - Optional root namespace for scoping
   * @param forceRefresh - Bypass cache
   */
  async getToken(
    workflowDefinition: string = DEFAULT_WORKFLOW_DEFINITION,
    rootNamespaceId?: string,
    forceRefresh: boolean = false
  ): Promise<GenerateTokenResponse> {
    const now = Date.now();
    const cacheKey = this.getCacheKey(workflowDefinition, rootNamespaceId);

    const cached = this.tokenCache.get(cacheKey);
    if (!forceRefresh && cached && cached.expiresAt > now) {
      return cached.token;
    }

    if (forceRefresh) {
      this.tokenCache.delete(cacheKey);
    }

    const url = `${this.config.instanceUrl}/api/v4/ai/duo_workflows/direct_access`;

    const body: Record<string, unknown> = {
      workflow_definition: workflowDefinition,
    };
    if (rootNamespaceId) {
      body.root_namespace_id = rootNamespaceId;
    }
    if (this.config.featureFlags && Object.keys(this.config.featureFlags).length > 0) {
      body.feature_flags = this.config.featureFlags;
    }

    try {
      const response = await this.fetchFn(url, {
        method: 'POST',
        headers: {
          ...this.config.getHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorText = await response.text();
        const safeError = sanitizeErrorText(errorText);

        // 401 — try refreshing the API key once
        if (response.status === 401 && this.config.refreshApiKey && !forceRefresh) {
          try {
            await this.config.refreshApiKey();
            return await this.getToken(workflowDefinition, rootNamespaceId, true);
          } catch (retryError) {
            if (retryError instanceof GitLabError) {
              throw retryError;
            }
            throw new GitLabError({
              message: `Failed to get workflow token: ${response.status} ${response.statusText} - ${safeError}`,
              statusCode: response.status,
              responseBody: safeError,
              cause: retryError,
            });
          }
        }

        // 403 — fail fast with clear message about requirements
        if (response.status === 403) {
          throw new GitLabError({
            message:
              `GitLab Duo Agent Platform access denied. ` +
              `GitLab Duo Agent Platform requires GitLab Ultimate with Duo Enterprise add-on. ` +
              `Ensure: (1) Your instance has GitLab Ultimate, ` +
              `(2) Duo Enterprise add-on is enabled, ` +
              `(3) Your account has access to AI features.`,
            statusCode: response.status,
            responseBody: safeError,
          });
        }

        throw new GitLabError({
          message: `Failed to get workflow token: ${response.status} ${response.statusText} - ${safeError}`,
          statusCode: response.status,
          responseBody: safeError,
        });
      }

      const data = (await response.json()) as GenerateTokenResponse;

      // Cache for 25 minutes
      this.tokenCache.set(cacheKey, {
        token: data,
        expiresAt: now + TOKEN_CACHE_DURATION_MS,
      });

      return data;
    } catch (error) {
      if (error instanceof GitLabError) throw error;
      throw new GitLabError({
        message: `Failed to get workflow token: ${error}`,
        cause: error,
      });
    }
  }

  /**
   * Create a new workflow on the GitLab instance.
   *
   * @param goal - The user's message / goal for this workflow
   * @param options - Additional workflow creation options
   * @returns The created workflow's ID
   */
  async createWorkflow(
    goal: string,
    options?: {
      projectId?: string;
      namespaceId?: string;
      workflowDefinition?: string;
      agentPrivileges?: number[];
      environment?: string;
      allowAgentToRequestUser?: boolean;
      aiCatalogItemVersionId?: number;
    }
  ): Promise<string> {
    // Validate goal parameter
    if (!goal || typeof goal !== 'string') {
      throw new GitLabError({ message: 'goal is required and must be a non-empty string' });
    }
    if (goal.length > 10000) {
      throw new GitLabError({ message: 'goal exceeds maximum length of 10000 characters' });
    }

    const url = `${this.config.instanceUrl}/api/v4/ai/duo_workflows/workflows`;

    const body: Record<string, unknown> = {
      goal,
      project_id: options?.projectId,
      namespace_id: options?.namespaceId,
      workflow_definition: options?.workflowDefinition ?? DEFAULT_WORKFLOW_DEFINITION,
      agent_privileges: options?.agentPrivileges ?? DEFAULT_AGENT_PRIVILEGES,
      environment: options?.environment ?? WORKFLOW_ENVIRONMENT,
      allow_agent_to_request_user: options?.allowAgentToRequestUser ?? true,
      ...(options?.aiCatalogItemVersionId !== undefined && {
        ai_catalog_item_version_id: options.aiCatalogItemVersionId,
      }),
    };

    try {
      const response = await this.fetchFn(url, {
        method: 'POST',
        headers: {
          ...this.config.getHeaders(),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const errorText = await response.text();
        const safeError = sanitizeErrorText(errorText);
        throw new GitLabError({
          message: `Failed to create workflow: ${response.status} ${response.statusText} - ${safeError}`,
          statusCode: response.status,
          responseBody: safeError,
        });
      }

      const data = (await response.json()) as CreateWorkflowResponse;
      return data.id.toString();
    } catch (error) {
      if (error instanceof GitLabError) throw error;
      throw new GitLabError({
        message: `Failed to create workflow: ${error}`,
        cause: error,
      });
    }
  }

  /**
   * Invalidate cached tokens.
   *
   * @param workflowDefinition - If provided, only invalidate for this type.
   *                             If omitted, clears ALL cached tokens.
   */
  invalidateToken(workflowDefinition?: string, rootNamespaceId?: string): void {
    if (workflowDefinition) {
      this.tokenCache.delete(this.getCacheKey(workflowDefinition, rootNamespaceId));
    } else {
      this.tokenCache.clear();
    }
  }
}
