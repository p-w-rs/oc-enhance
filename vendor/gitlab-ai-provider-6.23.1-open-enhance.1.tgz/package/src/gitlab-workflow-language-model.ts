/**
 * LanguageModelV3 adapter for GitLab Duo Agent Platform (DWS).
 *
 * Maps DWS WebSocket events to the Vercel AI SDK streaming protocol:
 *   newCheckpoint (text)  → text-delta
 *   runMcpTool             → tool-call (emitted for UI visibility)
 *   workflow COMPLETED     → finish(stop)
 *   workflow FAILED        → error
 *
 * IMPORTANT: Tool execution architecture
 * =======================================
 * DWS drives the agentic loop server-side. When DWS requests a tool via
 * `runMcpTool`, we execute it ourselves using the AI SDK tools passed in
 * `options.tools`, send the result back to DWS via WebSocket `actionResponse`,
 * and keep streaming. The stream stays open until DWS sends COMPLETED/FAILED.
 *
 * This means the AI SDK's outer tool loop (which would call doStream() again
 * with tool results in messages) is NOT used for workflow models. The entire
 * agentic conversation happens within a single doStream() call.
 *
 * We still emit `tool-call` stream parts so the UI can show tool usage,
 * but finishReason is always 'stop' (never 'tool-calls').
 *
 * Lifecycle per doStream() call:
 *   1. Get workflow token  (POST /duo_workflows/direct_access)
 *   2. Create workflow     (POST /duo_workflows/workflows)
 *   3. Connect WebSocket   (wss://.../duo_workflows/ws)
 *   4. Send startRequest   (with goal, tools, context)
 *   5. Stream events       (checkpoint → text, tool request → execute → respond)
 *   6. Close on finish     (COMPLETED/FAILED/CANCELLED)
 *
 * SECURITY MODEL — Tool Execution
 * =================================
 * This library acts as a **bridge** between DWS (server) and the host's tool
 * system (e.g., OpenCode).  It does NOT execute host-OS commands itself except
 * for the read-only `git` calls inside `getGitInfo()` (fixed argument lists,
 * no user-controlled data, via `execFile`).
 *
 * Built-in tool mapping (`mapBuiltinTool`)
 * -----------------------------------------
 * DWS built-in tools are mapped to structured host-tool invocations that the
 * host's `toolExecutor` callback then executes through its own permission
 * system.  For tools that ultimately produce shell commands the following
 * defences are applied:
 *
 *   • `shellEscape()` — wraps every argument in single quotes and escapes
 *     embedded single quotes, preventing metacharacter injection for all
 *     argument-based tools (runCommand, runGitCommand, mkdir, runHTTPRequest).
 *
 *   • `validateNoShellMetachars()` — rejects program names and git sub-commands
 *     containing `;`, `&`, `|`, `` ` ``, `$`, `(`, `)`, `<`, `>` before they
 *     reach shellEscape, providing a defence-in-depth check.
 *
 *   • `runShellCommand` — intentionally passes the command string through
 *     **without sanitization** because it is a deliberately raw shell tool.
 *     The host's `toolExecutor` / permission system is the final gate and must
 *     decide whether to allow it.  A length cap (10 000 chars) limits DoS via
 *     oversized payloads.
 *
 *   • `runHTTPRequest` — only `http://` and `https://` URL schemes are allowed
 *     (allowlist); all others (file://, gopher://, ftp://, etc.) are rejected.
 *     A `--` separator before the URL prevents flag injection via paths like
 *     `--output /tmp/evil`.
 *
 *   • `mkdir` — rejects null bytes in the directory path.
 *
 * Error sanitization
 * -------------------
 * All error messages forwarded into the stream (tool catch blocks, failed
 * events, WebSocket close reasons) are passed through `sanitizeErrorMessage()`
 * which redacts Bearer tokens, GitLab PAT/CI tokens, and URL credential query
 * parameters before they are surfaced to callers or logged.
 *
 * Trust boundary
 * ---------------
 * DWS is treated as a **trusted server** for the purpose of tool invocation —
 * it controls which tools are called and with what arguments.  Consumers MUST
 * implement their own authorization layer in the `toolExecutor` callback
 * (e.g., user confirmation prompts, allow-lists) for any tool that can cause
 * side effects on the user's machine.
 */

import { AsyncResource } from 'node:async_hooks';
import { GitLabWorkflowClient } from './gitlab-workflow-client';
import { GitLabWorkflowTokenClient } from './gitlab-workflow-token-client';
import { GitLabProjectDetector } from './gitlab-project-detector';
import { GitLabError } from './gitlab-error';
import { getWorkflowModelRef } from './model-mappings';
import { GitLabModelDiscovery } from './gitlab-model-discovery';
import type { DiscoveryScope } from './gitlab-model-discovery';
import { GitLabModelCache } from './gitlab-model-cache';
import { GITLAB_COM_URL } from './gitlab-oauth-types';
import {
  mapBuiltinTool,
  sanitizeErrorMessage,
  executeBuiltinFallback,
} from './gitlab-workflow-builtins';

import type {
  LanguageModelV3,
  LanguageModelV3CallOptions,
  LanguageModelV3StreamPart,
  LanguageModelV3FinishReason,
  LanguageModelV3Content,
  LanguageModelV3Usage,
  LanguageModelV3Message,
  LanguageModelV3FunctionTool,
  LanguageModelV3GenerateResult,
  LanguageModelV3StreamResult,
} from '@ai-sdk/provider';

import type {
  GitLabWorkflowOptions,
  GitLabWorkflowClientConfig,
  McpToolDefinition,
  AdditionalContext,
  StartRequest,
  WorkflowClientEvent,
  CheckpointData,
  UiChatLogEntry,
  NewCheckpoint,
  ApprovalDecision,
} from './gitlab-workflow-types';

interface StreamState {
  streamClosed: boolean;
  streamedInputChars: number;
  streamedOutputChars: number;
  pendingToolCount: number;
  approvalPending: boolean;
  deferredClose: (() => void) | null;
  activeTextBlockId: string | null;
  agentMessageEmitted: Map<string, number>;
  currentAgentMessageId: string;
  activeClient: GitLabWorkflowClient | null;
  processedRequestIDs: Set<string>;
  emittedToolEntries: Set<string>;
  emittedToolKeys: Set<string>;
  sessionKey: string;
}

import {
  DEFAULT_WORKFLOW_DEFINITION,
  DEFAULT_CLIENT_CAPABILITIES,
  CLIENT_VERSION,
  WS_CLOSE_WORKFLOW_LOCKED,
  WS_WORKFLOW_LOCK_RETRY_DELAY_MS,
  WS_WORKFLOW_LOCK_MAX_RETRIES,
} from './gitlab-workflow-types';

export interface GitLabWorkflowLanguageModelConfig extends GitLabWorkflowClientConfig {
  /** Provider name (e.g., 'gitlab.workflow') */
  provider: string;
}

const GITLAB_COM_HOSTNAME = new URL(GITLAB_COM_URL).hostname;

/**
 * Whether `instanceUrl` points at GitLab.com (as opposed to a self-managed or
 * Dedicated instance). Unparseable URLs are treated as not GitLab.com.
 */
function isGitLabComInstance(instanceUrl: string): boolean {
  try {
    return new URL(instanceUrl).hostname.toLowerCase() === GITLAB_COM_HOSTNAME;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Payload size utilities
// ---------------------------------------------------------------------------

function simplifySchemaObj(schema: Record<string, unknown>): Record<string, unknown> {
  if (!schema || typeof schema !== 'object') return schema;

  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(schema)) {
    if (key === 'description' || key === 'examples' || key === 'default') {
      continue;
    }
    if (key === 'properties' && typeof value === 'object' && value !== null) {
      const props: Record<string, unknown> = {};
      for (const [propName, propValue] of Object.entries(value as Record<string, unknown>)) {
        if (typeof propValue === 'object' && propValue !== null) {
          props[propName] = simplifySchemaObj(propValue as Record<string, unknown>);
        } else {
          props[propName] = propValue;
        }
      }
      result[key] = props;
    } else if (key === 'items' && typeof value === 'object' && value !== null) {
      result[key] = simplifySchemaObj(value as Record<string, unknown>);
    } else {
      result[key] = value;
    }
  }
  return result;
}

function simplifySchema(schemaStr: string): string {
  try {
    return JSON.stringify(simplifySchemaObj(JSON.parse(schemaStr)));
  } catch {
    return schemaStr;
  }
}

function minimalSchemaObj(schema: Record<string, unknown>): Record<string, unknown> {
  if (!schema || typeof schema !== 'object') return schema;

  const result: Record<string, unknown> = { type: schema.type || 'object' };
  if (schema.required) {
    result.required = schema.required;
  }
  if (schema.properties && typeof schema.properties === 'object') {
    const props: Record<string, unknown> = {};
    for (const [propName, propValue] of Object.entries(
      schema.properties as Record<string, unknown>
    )) {
      if (typeof propValue === 'object' && propValue !== null) {
        const pv = propValue as Record<string, unknown>;
        props[propName] = { type: pv.type || 'string' };
      } else {
        props[propName] = { type: 'string' };
      }
    }
    result.properties = props;
  }
  return result;
}

function minimalSchema(schemaStr: string): string {
  try {
    return JSON.stringify(minimalSchemaObj(JSON.parse(schemaStr)));
  } catch {
    return schemaStr;
  }
}

/**
 * Callback for executing a tool requested by DWS.
 * Provided by the consumer (e.g., OpenCode) to bridge DWS tool requests
 * to the host's tool execution system.
 *
 * @param toolName - Name of the tool DWS wants to execute
 * @param args - JSON-encoded arguments
 * @returns Tool execution result as a string, or throws on error
 */
export type WorkflowToolExecutor = (
  toolName: string,
  args: string,
  requestID: string
) => Promise<{
  result: string;
  error?: string | null;
  metadata?: Record<string, unknown>;
  title?: string;
}>;

// mapBuiltinTool, sanitizeErrorMessage, shellEscape, validateNoShellMetachars
// are imported from './gitlab-workflow-builtins' (shared module).

/**
 * GitLab Duo Agent Platform Language Model.
 *
 * Implements LanguageModelV3 by bridging the DWS WebSocket protocol
 * to the Vercel AI SDK stream part format.
 */
export class GitLabWorkflowLanguageModel implements LanguageModelV3 {
  readonly specificationVersion = 'v3' as const;
  readonly modelId: string;
  readonly supportedUrls: Record<string, RegExp[]> = {};

  private readonly config: GitLabWorkflowLanguageModelConfig;
  private readonly workflowOptions: GitLabWorkflowOptions;
  private readonly tokenClient: GitLabWorkflowTokenClient;
  private readonly projectDetector: GitLabProjectDetector;
  private readonly modelDiscovery: GitLabModelDiscovery;
  private readonly modelCache: GitLabModelCache;

  // Cached detected project path
  private detectedProjectPath: string | null = null;

  // Workflow ID persisted across turns for multi-turn conversations.
  // Per-session workflow state. Keyed by opencode sessionID (x-opencode-session header).
  // Each opencode session gets its own DWS workflow, reused across turns within that session.
  // Bounded: least-recently-used sessions are evicted beyond MAX_SESSION_WORKFLOWS
  // to prevent unbounded memory growth in long-lived hosts.
  private readonly sessionWorkflows = new Map<
    string,
    {
      workflowId: string;
      workflowDefinition: string | Record<string, unknown> | null;
      agentEmitted: Map<string, number>;
      toolEntries: Set<string>;
    }
  >();

  private static readonly MAX_SESSION_WORKFLOWS = 50;

  /**
   * Store a session workflow entry, refreshing its LRU position and
   * evicting the oldest entries beyond MAX_SESSION_WORKFLOWS.
   */
  private setSessionWorkflow(
    key: string,
    value: {
      workflowId: string;
      workflowDefinition: string | Record<string, unknown> | null;
      agentEmitted: Map<string, number>;
      toolEntries: Set<string>;
    }
  ): void {
    this.sessionWorkflows.delete(key);
    this.sessionWorkflows.set(key, value);
    while (this.sessionWorkflows.size > GitLabWorkflowLanguageModel.MAX_SESSION_WORKFLOWS) {
      const oldest = this.sessionWorkflows.keys().next().value;
      if (oldest === undefined) break;
      this.sessionWorkflows.delete(oldest);
    }
  }

  // Fallback for callers that don't pass x-opencode-session (e.g. direct SDK use).
  private currentWorkflowId: string | null = null;
  private currentWorkflowDefinition: string | Record<string, unknown> | null = null;
  private persistedAgentEmitted = new Map<string, number>();

  // Track all active stream clients so stopWorkflow() can stop them all.
  private readonly activeClients = new Set<GitLabWorkflowClient>();

  // Cache resolved values to avoid redundant GraphQL calls
  private _selectedModelRef?: string;
  private _selectedModelName?: string;
  private _rootNamespaceId?: string | null;
  private _namespaceId?: string | null;
  private _discoveryPromise?: Promise<string>;

  /**
   * Get the cached selected model ref.
   */
  get selectedModelRef(): string | null {
    return this._selectedModelRef ?? null;
  }

  /**
   * Set the selected model ref (e.g., from an eager discover call).
   * This will be used by resolveModelRef() to skip the picker.
   * Also persists to the file-based workspace cache.
   */
  set selectedModelRef(ref: string | null) {
    this._selectedModelRef = ref ?? undefined;
    this._selectedModelName = undefined;
    this.modelCache.saveSelection(ref, null);
  }

  /**
   * Get the cached selected model display name.
   */
  get selectedModelName(): string | null {
    return this._selectedModelName ?? null;
  }

  /**
   * Set the selected model display name.
   * Also persists to the file-based workspace cache.
   */
  set selectedModelName(name: string | null) {
    this._selectedModelName = name ?? undefined;
    this.modelCache.saveSelection(this._selectedModelRef ?? null, name);
  }

  /**
   * Optional external tool executor. When set, this is called for tool
   * requests instead of looking up tools from `options.tools`.
   * This allows the consumer (OpenCode) to wire in its permission system.
   *
   * The executor is automatically bound to the async context at the time
   * it is set, so that AsyncLocalStorage-based contexts (like Instance)
   * remain available when the executor is invoked from WebSocket callbacks.
   */
  private _toolExecutor: WorkflowToolExecutor | null = null;

  /**
   * Optional callback invoked with intermediate token usage estimates
   * after each tool execution completes. This allows the consumer to
   * display live token counts during long-running DWS workflows, since
   * the AI SDK only surfaces usage via finish-step at stream end.
   */
  onUsageUpdate: ((usage: { inputTokens: number; outputTokens: number }) => void) | null = null;

  /**
   * Tool names pre-approved for the current session.
   * Set by the host (e.g., opencode) and merged into preapproved_tools on each StartRequest.
   * Updated when the user chooses "always" in the approval prompt.
   */
  public sessionPreapprovedTools: string[] = [];

  /**
   * The opencode session ID. Set per-stream by the host to key per-session
   * DWS workflows. Different sessions get different DWS workflows.
   */
  public sessionID: string = '';

  /**
   * Set the approval handler callback.
   * Called when DWS requires tool call approval. Host (e.g., opencode) wires this
   * to its permission system each stream call, similar to toolExecutor.
   */
  set approvalHandler(
    handler:
      | ((
          tools: Array<{ name: string; args: string }>
        ) => Promise<{ approved: boolean; message?: string }>)
      | null
  ) {
    this.workflowOptions.approvalHandler = handler ?? undefined;
  }

  get approvalHandler():
    | ((
        tools: Array<{ name: string; args: string }>
      ) => Promise<{ approved: boolean; message?: string }>)
    | null {
    return this.workflowOptions.approvalHandler ?? null;
  }

  /**
   * Optional callback invoked when multiple workflow models are available
   * and the user should pick one. Set per-stream by the host (e.g., OpenCode)
   * alongside `toolExecutor`. Takes precedence over `workflowOptions.onSelectModel`.
   */
  onSelectModel:
    | ((models: import('./gitlab-model-discovery').AiModel[]) => Promise<string | null | undefined>)
    | null = null;

  /**
   * Set the system prompt to override DWS's default.
   * Sent via `flowConfig.prompts[].prompt_template.system` at stream time.
   * Can be updated between doStream() calls (e.g., per agent/session).
   */
  set systemPrompt(prompt: string | null) {
    (this.workflowOptions as { systemPrompt?: string }).systemPrompt = prompt ?? undefined;
  }

  get systemPrompt(): string | null {
    return this.workflowOptions.systemPrompt ?? null;
  }

  get toolExecutor(): WorkflowToolExecutor | null {
    return this._toolExecutor;
  }

  set toolExecutor(executor: WorkflowToolExecutor | null) {
    if (executor) {
      try {
        this._toolExecutor = AsyncResource.bind(executor);
      } catch {
        this._toolExecutor = executor;
      }
    } else {
      this._toolExecutor = null;
    }
  }

  constructor(
    modelId: string,
    config: GitLabWorkflowLanguageModelConfig,
    workflowOptions: GitLabWorkflowOptions = {}
  ) {
    this.modelId = modelId;
    this.config = config;
    this.workflowOptions = workflowOptions;

    const workDir = workflowOptions.workingDirectory ?? process.cwd();
    this.modelCache = new GitLabModelCache(workDir, config.instanceUrl);

    const cached = this.modelCache.load();
    if (cached?.selectedModelRef) {
      this._selectedModelRef = cached.selectedModelRef;
    }
    if (cached?.selectedModelName) {
      this._selectedModelName = cached.selectedModelName;
    }

    this.tokenClient = new GitLabWorkflowTokenClient({
      instanceUrl: config.instanceUrl,
      getHeaders: config.getHeaders,
      refreshApiKey: config.refreshApiKey,
      fetch: config.fetch,
      featureFlags: config.featureFlags,
    });

    this.projectDetector = new GitLabProjectDetector({
      instanceUrl: config.instanceUrl,
      getHeaders: config.getHeaders,
      fetch: config.fetch,
    });

    this.modelDiscovery = new GitLabModelDiscovery({
      instanceUrl: config.instanceUrl,
      getHeaders: config.getHeaders,
      fetch: config.fetch,
    });
  }

  get provider(): string {
    return this.config.provider;
  }

  /**
   * Resolve the project ID (path) to use for workflow creation.
   * Priority: explicit option > auto-detected from git remote > undefined.
   */
  private async resolveProjectId(): Promise<string | undefined> {
    if (this.workflowOptions.projectId) {
      return this.workflowOptions.projectId;
    }

    if (this.detectedProjectPath) {
      return this.detectedProjectPath;
    }

    const workDir = this.workflowOptions.workingDirectory ?? process.cwd();
    const project = await this.projectDetector.detectProject(workDir);
    if (project) {
      this.detectedProjectPath = project.pathWithNamespace;
      return project.pathWithNamespace;
    }

    return undefined;
  }

  /**
   * Resolve the root namespace GID to use for model discovery.
   *
   * Priority:
   *   1. Explicit `rootNamespaceId` in workflowOptions (caller-provided GID)
   *   2. Auto-detected from git remote via project detector (namespace.id → GID)
   *   3. Cached from previous call
   */
  private async resolveRootNamespaceId(): Promise<string | null> {
    if (this.workflowOptions.rootNamespaceId) {
      return this.workflowOptions.rootNamespaceId;
    }

    // Return cached value if available
    if (this._rootNamespaceId !== undefined) {
      return this._rootNamespaceId;
    }

    const workDir = this.workflowOptions.workingDirectory ?? process.cwd();
    const project = await this.projectDetector.detectProject(workDir);
    if (project?.namespaceId) {
      const gid = `gid://gitlab/Group/${project.namespaceId}`;
      this._rootNamespaceId = gid;
      return gid;
    }

    this._rootNamespaceId = null;
    return null;
  }

  /**
   * Resolve the numeric namespace id for the DWS WebSocket.
   *
   * The `/api/v4/ai/duo_workflows/ws` endpoint needs a namespace. It reads the
   * `x-gitlab-namespace-id` header, and only accepts the **plain numeric id** —
   * a `gid://gitlab/Group/<n>` value is rejected, as is `x-gitlab-root-namespace-id`.
   * Without it the upgrade fails with
   * `403 Missing default GitLab Duo namespace user preference`.
   *
   * The header is validated, not just required: a namespace the user cannot
   * use Duo in is rejected with `403` as well. On GitLab.com users normally
   * have a default Duo namespace preference, and sending the namespace of
   * whatever repository they happen to be in (a community fork, a personal
   * project, a subgroup) could override that preference and break a
   * connection that works today. So the git-remote fallback is limited to
   * self-managed instances, where the missing preference is what refuses the
   * connection in the first place.
   *
   * Priority:
   *   1. Explicit `namespaceId` in workflowOptions (any instance)
   *   2. Auto-detected from the git remote (self-managed instances only)
   */
  private async resolveNamespaceId(): Promise<string | null> {
    if (this.workflowOptions.namespaceId) {
      return this.workflowOptions.namespaceId;
    }

    if (isGitLabComInstance(this.config.instanceUrl)) {
      return null;
    }

    if (this._namespaceId !== undefined) {
      return this._namespaceId;
    }

    // Detection failures here are swallowed so the WebSocket can still fall
    // back to the user's default Duo namespace. Note that `doStream` may
    // already have run detection for the project id / discovery scope, which
    // is not guarded; this only keeps namespace resolution itself best-effort.
    try {
      const workDir = this.workflowOptions.workingDirectory ?? process.cwd();
      const project = await this.projectDetector.detectProject(workDir);
      this._namespaceId = project?.namespaceId ? String(project.namespaceId) : null;
    } catch {
      this._namespaceId = null;
    }
    return this._namespaceId;
  }

  /**
   * Resolve the model discovery scope to use for `aiChatAvailableModels`.
   *
   * `projectId` is preferred — it works for both group- and user-namespace
   * projects — with `rootNamespaceId` attached as a fallback for GitLab
   * instances too old to support `projectId`-scoped discovery.
   */
  private async resolveDiscoveryScope(): Promise<DiscoveryScope | null> {
    const rootNamespaceId = await this.resolveRootNamespaceId();

    const workDir = this.workflowOptions.workingDirectory ?? process.cwd();
    const project = await this.projectDetector.detectProject(workDir);
    if (project?.id) {
      return {
        projectId: `gid://gitlab/Project/${project.id}`,
        ...(rootNamespaceId ? { rootNamespaceId } : {}),
      };
    }

    return rootNamespaceId ? { rootNamespaceId } : null;
  }

  /**
   * Resolve the effective DWS model ref to use for this stream.
   * Deduplicates concurrent calls via a shared promise.
   *
   * Priority for the canonical `duo-workflow` model ID:
   *   1. Admin-pinned model (from GitLabModelDiscovery) — always wins
   *   2. User selection via onSelectModel callback (if model switching enabled)
   *   3. Workspace default model
   *   4. File-cached discovery/selection — used when live discovery fails
   *   5. Hard-coded 'default' (DWS decides) — fallback when discovery fails
   *
   * For all other `duo-workflow-*` model IDs the static mapping is used as-is.
   */
  private async resolveModelRef(): Promise<string> {
    const staticRef = getWorkflowModelRef(this.modelId);

    if (this.modelId !== 'duo-workflow') {
      return staticRef ?? 'default';
    }

    if (this._selectedModelRef) {
      return this._selectedModelRef;
    }

    if (!this._discoveryPromise) {
      this._discoveryPromise = this.doResolveModelRef();
      this._discoveryPromise.finally(() => {
        this._discoveryPromise = undefined;
      });
    }
    return this._discoveryPromise;
  }

  private async doResolveModelRef(): Promise<string> {
    const scope = await this.resolveDiscoveryScope();

    if (!scope) {
      this._selectedModelRef = 'default';
      return 'default';
    }

    try {
      const discovered = await this.modelDiscovery.discover(scope);
      this.modelCache.saveDiscovery(discovered);

      if (discovered.pinnedModel) {
        this._selectedModelRef = discovered.pinnedModel.ref;
        this._selectedModelName = discovered.pinnedModel.name;
        this.modelCache.saveSelection(discovered.pinnedModel.ref, discovered.pinnedModel.name);
        return discovered.pinnedModel.ref;
      }

      const selectFn = this.onSelectModel ?? this.workflowOptions.onSelectModel;
      if (discovered.selectableModels.length > 0 && selectFn) {
        const selected = await selectFn(discovered.selectableModels);
        if (selected) {
          const match = discovered.selectableModels.find((m) => m.ref === selected);
          if (match) {
            this._selectedModelRef = match.ref;
            this._selectedModelName = match.name;
            this.modelCache.saveSelection(match.ref, match.name);
            return match.ref;
          }
        }
      }

      if (discovered.defaultModel) {
        this._selectedModelRef = discovered.defaultModel.ref;
        this._selectedModelName = discovered.defaultModel.name;
        this.modelCache.saveSelection(discovered.defaultModel.ref, discovered.defaultModel.name);
        return discovered.defaultModel.ref;
      }
    } catch {
      const cachedEntry = this.modelCache.load();
      if (cachedEntry?.selectedModelRef) {
        this._selectedModelRef = cachedEntry.selectedModelRef;
        this._selectedModelName = cachedEntry.selectedModelName ?? undefined;
        return cachedEntry.selectedModelRef;
      }
    }

    this._selectedModelRef = 'default';
    return 'default';
  }

  /**
   * Pre-fetch available models for the workspace.
   * Call this early (e.g., on IDE startup) to avoid blocking the first stream.
   * Results are persisted to the workspace model cache.
   *
   * @param scope - Project or root namespace GID to discover models for.
   *   A bare string is treated as a `rootNamespaceId` (e.g.
   *   'gid://gitlab/Group/12345') for backwards compatibility.
   * @returns Discovered models with default, selectable, and pinned models
   */
  async discoverModels(
    scope: DiscoveryScope | string
  ): Promise<import('./gitlab-model-discovery').DiscoveredModels> {
    const result = await this.modelDiscovery.discover(scope);
    this.modelCache.saveDiscovery(result);
    return result;
  }

  /**
   * Get the file-based model cache instance for this workspace.
   * Useful for consumers that need direct cache access (e.g., the discover route).
   */
  getModelCache(): GitLabModelCache {
    return this.modelCache;
  }

  /**
   * Stop the active workflow.
   */
  stopWorkflow(): void {
    for (const client of this.activeClients) {
      if (client.isConnected) {
        client.stop();
      }
    }
  }

  /**
   * Reset the workflow state, forcing a new workflow to be created on the
   * next doStream() call. Call this when starting a new conversation.
   */
  resetWorkflow(sessionKey?: string): void {
    if (sessionKey) {
      this.sessionWorkflows.delete(sessionKey);
    } else {
      this.sessionWorkflows.clear();
      this.currentWorkflowId = null;
      this.persistedAgentEmitted.clear();
    }
  }

  /**
   * Get the current workflow ID (if any).
   * Useful for consumers that need to track workflow state.
   */
  get workflowId(): string | null {
    return this.currentWorkflowId;
  }

  private createUsage(params?: {
    inputTotal?: number;
    outputTotal?: number;
  }): LanguageModelV3Usage {
    return {
      inputTokens: {
        total: params?.inputTotal,
        noCache: params?.inputTotal,
        cacheRead: undefined,
        cacheWrite: undefined,
      },
      outputTokens: {
        total: params?.outputTotal,
        text: params?.outputTotal,
        reasoning: undefined,
      },
    };
  }

  private createFinishReason(
    unified: LanguageModelV3FinishReason['unified'],
    raw?: string
  ): LanguageModelV3FinishReason {
    return { unified, raw };
  }

  // ---------------------------------------------------------------------------
  // LanguageModelV3 — doGenerate (non-streaming)
  // ---------------------------------------------------------------------------

  async doGenerate(options: LanguageModelV3CallOptions): Promise<LanguageModelV3GenerateResult> {
    // DWS is inherently streaming. Collect the full stream into a single result.
    const { stream } = await this.doStream(options);
    const reader = stream.getReader();

    const textParts: string[] = [];
    const toolCalls: LanguageModelV3Content[] = [];
    let finishReason: LanguageModelV3FinishReason = { unified: 'other', raw: undefined };
    let usage: LanguageModelV3Usage = this.createUsage();

    try {
      // eslint-disable-next-line no-constant-condition
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        switch (value.type) {
          case 'text-delta':
            textParts.push(value.delta);
            break;
          case 'tool-call':
            toolCalls.push({
              type: 'tool-call',
              toolCallId: value.toolCallId,
              toolName: value.toolName,
              input: value.input,
            });
            break;
          case 'finish':
            finishReason = value.finishReason;
            if (value.usage) {
              usage = value.usage;
            }
            break;
          case 'error':
            try {
              await reader.cancel();
            } catch {
              // best-effort cleanup of the underlying workflow
            }
            throw value.error;
        }
      }
    } finally {
      reader.releaseLock();
    }

    const content: LanguageModelV3Content[] = [];
    const fullText = textParts.join('');
    if (fullText) {
      content.push({ type: 'text', text: fullText });
    }
    content.push(...toolCalls);

    return { content, finishReason, usage, warnings: [] };
  }

  // ---------------------------------------------------------------------------
  // LanguageModelV3 — doStream (streaming)
  // ---------------------------------------------------------------------------

  async doStream(options: LanguageModelV3CallOptions): Promise<LanguageModelV3StreamResult> {
    // Extract the user's goal from the prompt
    const goal = this.extractGoalFromPrompt(options.prompt);

    // Get the model ref for WebSocket URL — resolved dynamically for 'duo-workflow'.
    const modelRef = await this.resolveModelRef();

    // Extract MCP tools from options.tools (AI SDK tools → DWS mcpTools)
    const mcpTools = this.extractMcpTools(options);

    // Merge preapproved tools — all tool names if no options provided, plus session approvals
    const preapprovedTools = [
      ...(this.workflowOptions.preapprovedTools ?? mcpTools.map((t) => t.name)),
      ...this.sessionPreapprovedTools,
    ];

    // Build additional context from conversation history.
    const additionalContext = this.buildAdditionalContext(options.prompt);

    const toolExecutor = this.toolExecutor ?? null;

    // Collect available host tool names so mapBuiltinTool can adapt
    // (e.g., use apply_patch when edit/write are not available)
    const availableToolNames = new Set<string>(options.tools?.map((t) => t.name) ?? []);

    // Per-call overrides from providerOptions — allows the host (e.g. opencode) to
    // pass per-agent settings without needing a separate LanguageModelV3 instance.
    const gitlabProviderOptions = (
      options.providerOptions as Record<string, unknown> | undefined
    )?.['gitlab'] as Record<string, unknown> | undefined;
    const callWorkflowDefinition =
      (gitlabProviderOptions?.workflowDefinition as string | undefined) ??
      this.workflowOptions.workflowDefinition;
    const callFlowConfig =
      (gitlabProviderOptions?.flowConfig as Record<string, unknown> | undefined) ?? undefined;
    const callFlowConfigSchemaVersion =
      (gitlabProviderOptions?.flowConfigSchemaVersion as string | undefined) ?? undefined;
    const callAiCatalogItemVersionId =
      (gitlabProviderOptions?.aiCatalogItemVersionId as number | undefined) ?? undefined;

    // Step 1: Warm the token cache — createWorkflow() below requires a valid
    // session, and getToken() caches the result for subsequent API calls.
    // The DWS token itself is used server-side; the WebSocket authenticates
    // via the GitLab PAT/OAuth token in headers.
    await this.tokenClient.getToken(
      callWorkflowDefinition ?? DEFAULT_WORKFLOW_DEFINITION,
      this.workflowOptions.rootNamespaceId
    );

    // Step 1b: Resolve project ID (auto-detect from git remote if needed)
    const projectId = await this.resolveProjectId();

    // Use flowConfig as the effective key when present (custom agents)
    const effectiveDefinition =
      callFlowConfig ?? callWorkflowDefinition ?? DEFAULT_WORKFLOW_DEFINITION;

    const sessionKey = this.sessionID;

    // Get or initialise per-session workflow state
    let sess = this.sessionWorkflows.get(sessionKey);
    if (sess && sess.workflowDefinition !== effectiveDefinition) {
      // Agent changed within session — start a fresh workflow
      this.sessionWorkflows.delete(sessionKey);
      sess = undefined;
    }
    // Fallback path: no sessionKey (direct SDK use) — use legacy instance fields
    const useLegacy = sessionKey === '';
    if (
      useLegacy &&
      this.currentWorkflowId &&
      this.currentWorkflowDefinition !== effectiveDefinition
    ) {
      this.currentWorkflowId = null;
      this.currentWorkflowDefinition = null;
    }

    let workflowId: string;
    if (sess) {
      workflowId = sess.workflowId;
    } else if (useLegacy && this.currentWorkflowId) {
      workflowId = this.currentWorkflowId;
    } else {
      workflowId = await this.tokenClient.createWorkflow(goal, {
        projectId,
        namespaceId: this.workflowOptions.namespaceId,
        workflowDefinition: callWorkflowDefinition,
        agentPrivileges: this.workflowOptions.agentPrivileges,
        aiCatalogItemVersionId: callAiCatalogItemVersionId,
      });
      if (useLegacy) {
        this.currentWorkflowId = workflowId;
        this.currentWorkflowDefinition = effectiveDefinition;
      } else {
        this.setSessionWorkflow(sessionKey, {
          workflowId,
          workflowDefinition: effectiveDefinition,
          agentEmitted: new Map(),
          toolEntries: new Set(),
        });
        sess = this.sessionWorkflows.get(sessionKey)!;
      }
    }

    // Step 3: Create WebSocket client
    const wsClient = new GitLabWorkflowClient();
    this.activeClients.add(wsClient);

    let textBlockCounter = 0;

    // Per-stream state — isolated so parallel streams don't corrupt each other.
    // Seed agentMessageEmitted from the persisted map so that cumulative DWS
    // chat logs don't re-emit messages already streamed in a prior turn.
    const ss: StreamState = {
      streamClosed: false,
      streamedInputChars: 0,
      streamedOutputChars: 0,
      pendingToolCount: 0,
      approvalPending: false,
      deferredClose: null,
      activeTextBlockId: null,
      agentMessageEmitted: new Map(sess?.agentEmitted ?? this.persistedAgentEmitted),
      currentAgentMessageId: '',
      activeClient: wsClient,
      processedRequestIDs: new Set(),
      emittedToolEntries: new Set(sess?.toolEntries),
      emittedToolKeys: new Set(),
      sessionKey,
    };

    for (const msg of options.prompt) {
      if (msg.role === 'system') {
        ss.streamedInputChars += msg.content.length;
      } else if (msg.role === 'user') {
        for (const part of msg.content) {
          if (part.type === 'text') {
            ss.streamedInputChars += (part as { text: string }).text.length;
          }
        }
      }
    }

    let startReq: StartRequest | undefined;

    const resolvedNamespaceId = (await this.resolveNamespaceId()) ?? undefined;

    const stream = new ReadableStream<LanguageModelV3StreamPart>({
      start: async (controller) => {
        try {
          // Connect WebSocket
          await wsClient.connect(
            {
              instanceUrl: this.config.instanceUrl,
              modelRef,
              headers: this.config.getHeaders(),
              projectId: this.workflowOptions.projectId,
              namespaceId: resolvedNamespaceId,
              rootNamespaceId: this.workflowOptions.rootNamespaceId,
              aiCatalogItemVersionId: callAiCatalogItemVersionId,
              workflowDefinition: callWorkflowDefinition ?? this.workflowOptions.workflowDefinition,
            },
            (event: WorkflowClientEvent) => {
              this.handleWorkflowEvent(
                ss,
                event,
                controller,
                wsClient,
                toolExecutor,
                () => `text-${textBlockCounter++}`,
                availableToolNames,
                startReq,
                {
                  aiCatalogItemVersionId: callAiCatalogItemVersionId,
                  workflowDefinition:
                    callWorkflowDefinition ?? this.workflowOptions.workflowDefinition,
                }
              );
            }
          );

          const workflowDef = callWorkflowDefinition ?? DEFAULT_WORKFLOW_DEFINITION;
          const capabilities =
            this.workflowOptions.clientCapabilities ?? DEFAULT_CLIENT_CAPABILITIES;
          const workflowMetadata = await this.buildWorkflowMetadata();
          const metadataStr = JSON.stringify(workflowMetadata);

          const basePayload = {
            workflowID: workflowId,
            clientVersion: CLIENT_VERSION,
            workflowDefinition: workflowDef,
            goal,
            workflowMetadata: metadataStr,
            clientCapabilities: capabilities,
            preapproved_tools: preapprovedTools,
          };
          const baseSize = JSON.stringify(basePayload).length + 100;

          const trimmed = this.trimPayload(mcpTools, additionalContext, baseSize);

          const trimmedPreapproved = preapprovedTools.filter((name) =>
            trimmed.mcpTools.some((t) => t.name === name)
          );

          startReq = {
            workflowID: workflowId,
            clientVersion: CLIENT_VERSION,
            workflowDefinition: workflowDef,
            goal,
            workflowMetadata: metadataStr,
            additional_context: trimmed.additionalContext,
            clientCapabilities: capabilities,
            mcpTools: trimmed.mcpTools,
            preapproved_tools: trimmedPreapproved,
          };

          // Per-call flowConfig overrides instance options (custom agents via providerOptions)
          const resolvedFlowConfig = callFlowConfig ?? this.workflowOptions.flowConfig;
          const resolvedFlowConfigSchemaVersion =
            callFlowConfigSchemaVersion ?? this.workflowOptions.flowConfigSchemaVersion;

          if (resolvedFlowConfig) {
            startReq.flowConfig = resolvedFlowConfig;
          }
          if (resolvedFlowConfigSchemaVersion) {
            startReq.flowConfigSchemaVersion = resolvedFlowConfigSchemaVersion;
          } else if (startReq.flowConfig) {
            startReq.flowConfigSchemaVersion = 'v1';
          }

          wsClient.sendStartRequest(startReq);

          // Emit stream-start
          controller.enqueue({
            type: 'stream-start',
            warnings: [],
          });

          // Emit response metadata
          controller.enqueue({
            type: 'response-metadata',
            id: workflowId,
            modelId: modelRef,
          });
        } catch (error) {
          if (!ss.streamClosed) {
            controller.enqueue({
              type: 'error',
              error:
                error instanceof GitLabError
                  ? error
                  : new GitLabError({
                      message: `Workflow connection failed: ${sanitizeErrorMessage(String(error))}`,
                      cause: error,
                    }),
            });
            ss.streamClosed = true;
            controller.close();
          }
        }
      },
      cancel: (_reason) => {
        if (abortListener && options.abortSignal) {
          options.abortSignal.removeEventListener('abort', abortListener);
        }
        wsClient.stop();
        wsClient.close();
        this.activeClients.delete(wsClient);
        ss.activeClient = null;
        // Only clear workflow if stream was aborted (not a normal completion).
        // Normal completion already closed the stream (ss.streamClosed=true) — keep
        // the workflow alive so the next turn in the same opencode session reuses it.
        if (!ss.streamClosed) {
          if (ss.sessionKey) {
            this.sessionWorkflows.delete(ss.sessionKey);
          } else {
            this.currentWorkflowId = null;
          }
        }
      },
    });

    let abortListener: (() => void) | null = null;
    if (options.abortSignal) {
      abortListener = () => {
        wsClient.stop();
        wsClient.close();
        this.activeClients.delete(wsClient);
        ss.activeClient = null;
        if (!ss.streamClosed) {
          ss.streamClosed = true;
          if (ss.sessionKey) {
            this.sessionWorkflows.delete(ss.sessionKey);
          } else {
            this.currentWorkflowId = null;
          }
        }
      };
      if (options.abortSignal.aborted) {
        abortListener();
      } else {
        options.abortSignal.addEventListener('abort', abortListener, { once: true });
      }
    }

    return {
      stream,
      request: {
        body: { workflowId, modelRef, goal },
      },
    };
  }

  // ---------------------------------------------------------------------------
  // Event handling
  // ---------------------------------------------------------------------------

  private handleWorkflowEvent(
    ss: StreamState,
    event: WorkflowClientEvent,
    controller: ReadableStreamDefaultController<LanguageModelV3StreamPart>,
    wsClient: GitLabWorkflowClient,
    toolExecutor: WorkflowToolExecutor | null,
    nextTextId: () => string,
    availableToolNames?: Set<string>,
    startReq?: StartRequest,
    wsExtras?: { aiCatalogItemVersionId?: number; workflowDefinition?: string }
  ): void {
    if (ss.streamClosed) {
      return;
    }

    switch (event.type) {
      case 'checkpoint': {
        this.processCheckpoint(ss, event.data, controller, nextTextId);
        break;
      }

      case 'tool-request': {
        const { requestID, data } = event;
        if (ss.processedRequestIDs.has(requestID)) break;
        ss.processedRequestIDs.add(requestID);
        ss.emittedToolKeys.add(data.name);
        let parsedArgs: string;
        try {
          JSON.parse(data.args);
          parsedArgs = data.args;
        } catch {
          parsedArgs = data.args || '{}';
        }

        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }

        controller.enqueue({
          type: 'tool-input-start',
          id: requestID,
          toolName: data.name,
          providerExecuted: true,
        });
        controller.enqueue({
          type: 'tool-input-delta',
          id: requestID,
          delta: parsedArgs,
        });
        controller.enqueue({
          type: 'tool-input-end',
          id: requestID,
        });
        controller.enqueue({
          type: 'tool-call',
          toolCallId: requestID,
          toolName: data.name,
          input: parsedArgs,
          providerExecuted: true,
        });

        this.executeToolAndRespond(
          ss,
          wsClient,
          controller,
          requestID,
          data.name,
          parsedArgs,
          toolExecutor
        ).catch(() => {});
        break;
      }

      case 'builtin-tool-request': {
        if (ss.processedRequestIDs.has(event.requestID)) break;
        ss.processedRequestIDs.add(event.requestID);
        const mapped = mapBuiltinTool(event.toolName, event.data, availableToolNames);
        ss.emittedToolKeys.add(mapped.toolName);
        const mappedArgs = JSON.stringify(mapped.args);

        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }

        controller.enqueue({
          type: 'tool-input-start',
          id: event.requestID,
          toolName: mapped.toolName,
          providerExecuted: true,
        });
        controller.enqueue({
          type: 'tool-input-delta',
          id: event.requestID,
          delta: mappedArgs,
        });
        controller.enqueue({
          type: 'tool-input-end',
          id: event.requestID,
        });
        controller.enqueue({
          type: 'tool-call',
          toolCallId: event.requestID,
          toolName: mapped.toolName,
          input: mappedArgs,
          providerExecuted: true,
        });

        this.executeToolAndRespond(
          ss,
          wsClient,
          controller,
          event.requestID,
          mapped.toolName,
          mappedArgs,
          toolExecutor
        ).catch(() => {});
        break;
      }

      case 'approval-required': {
        ss.approvalPending = true;
        this.approveAndResume(
          ss,
          event.tools,
          startReq,
          controller,
          toolExecutor,
          nextTextId,
          availableToolNames,
          wsExtras
        ).catch((_err) => {
          ss.approvalPending = false;
          if (ss.deferredClose) {
            const close = ss.deferredClose;
            ss.deferredClose = null;
            close();
          }
        });
        break;
      }

      case 'completed': {
        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }

        const doCompleteClose = () => {
          if (ss.streamClosed) return;
          // Approximate token counts (1 token ≈ 4 chars). DWS does not expose
          // actual token usage; these are estimates for AI SDK compatibility only.
          const inputTokens = Math.ceil(ss.streamedInputChars / 4);
          const outputTokens = Math.ceil(ss.streamedOutputChars / 4);
          controller.enqueue({
            type: 'finish',
            finishReason: this.createFinishReason('stop', 'completed'),
            usage: this.createUsage({ inputTotal: inputTokens, outputTotal: outputTokens }),
          });
          ss.streamClosed = true;
          controller.close();
          this.cleanupClient(ss, false); // keep workflow alive for next turn
        };

        if (ss.pendingToolCount > 0 || ss.approvalPending) {
          ss.deferredClose = doCompleteClose;
        } else {
          ss.deferredClose = null;
          doCompleteClose();
        }
        break;
      }

      case 'failed': {
        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }
        controller.enqueue({
          type: 'error',
          error: new GitLabError({
            message: `Workflow failed: ${sanitizeErrorMessage(event.error.message)}`,
            cause: event.error,
          }),
        });
        ss.streamClosed = true;
        controller.close();
        this.cleanupClient(ss, true);
        break;
      }

      case 'closed': {
        if (ss.streamClosed) {
          break;
        }
        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }

        const doClose = () => {
          if (ss.streamClosed) return;
          if (event.code !== 1000) {
            controller.enqueue({
              type: 'error',
              error: new GitLabError({
                message: `WebSocket closed unexpectedly: code=${event.code} reason=${sanitizeErrorMessage(event.reason)}`,
                statusCode: event.code,
              }),
            });
            ss.streamClosed = true;
            controller.close();
            this.cleanupClient(ss, true);
          } else {
            const inTok = Math.ceil(ss.streamedInputChars / 4);
            const outTok = Math.ceil(ss.streamedOutputChars / 4);
            controller.enqueue({
              type: 'finish',
              finishReason: this.createFinishReason('stop', 'closed'),
              usage: this.createUsage({ inputTotal: inTok, outputTotal: outTok }),
            });
            ss.streamClosed = true;
            controller.close();
            this.cleanupClient(ss, false); // keep workflow alive for next turn
          }
        };

        if (ss.pendingToolCount > 0 || ss.approvalPending) {
          ss.deferredClose = doClose;
        } else {
          ss.deferredClose = null;
          doClose();
        }
        break;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Checkpoint content extraction
  // ---------------------------------------------------------------------------

  private processCheckpoint(
    ss: StreamState,
    checkpoint: NewCheckpoint,
    controller: ReadableStreamDefaultController<LanguageModelV3StreamPart>,
    nextTextId: () => string
  ): void {
    if (!checkpoint.checkpoint) {
      if (checkpoint.content) {
        if (!ss.activeTextBlockId) {
          ss.activeTextBlockId = nextTextId();
          controller.enqueue({ type: 'text-start', id: ss.activeTextBlockId });
        }
        controller.enqueue({
          type: 'text-delta',
          id: ss.activeTextBlockId,
          delta: checkpoint.content,
        });
        ss.streamedOutputChars += checkpoint.content.length;
      }
      return;
    }

    let parsed: CheckpointData;
    try {
      parsed = JSON.parse(checkpoint.checkpoint);
    } catch (e) {
      return;
    }

    const chatLog = parsed.channel_values?.ui_chat_log;
    if (!chatLog || !Array.isArray(chatLog) || chatLog.length === 0) {
      return;
    }

    if (
      checkpoint.status !== 'RUNNING' &&
      checkpoint.status !== 'INPUT_REQUIRED' &&
      checkpoint.status !== 'FINISHED' &&
      checkpoint.status !== 'COMPLETED' &&
      checkpoint.status !== 'TOOL_CALL_APPROVAL_REQUIRED'
    ) {
      return;
    }

    for (let i = 0; i < chatLog.length; i++) {
      const entry = chatLog[i] as UiChatLogEntry;

      if (entry.message_type === 'tool' && entry.tool_info) {
        const toolId = entry.message_id || entry.correlation_id || `tool-${i}`;
        if (ss.emittedToolEntries.has(toolId)) continue;

        const name = entry.tool_info.name;
        const args = JSON.stringify(entry.tool_info.args ?? {});

        // Skip tools already handled via tool-request/builtin-tool-request.
        // Those arrive as separate WorkflowAction events with their own stream IDs,
        // then appear again in the checkpoint ui_chat_log as 'tool' entries.
        if (ss.emittedToolKeys.has(name)) {
          ss.emittedToolEntries.add(toolId);
          const sess = this.sessionWorkflows.get(ss.sessionKey);
          if (sess) sess.toolEntries.add(toolId);
          continue;
        }

        if (ss.activeTextBlockId) {
          controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
          ss.activeTextBlockId = null;
        }

        controller.enqueue({
          type: 'tool-input-start',
          id: toolId,
          toolName: name,
          providerExecuted: true,
        });
        controller.enqueue({ type: 'tool-input-delta', id: toolId, delta: args });
        controller.enqueue({ type: 'tool-input-end', id: toolId });
        controller.enqueue({
          type: 'tool-call',
          toolCallId: toolId,
          toolName: name,
          input: args,
          providerExecuted: true,
          dynamic: true,
        });

        const response = entry.tool_info.tool_response;
        const output =
          typeof response === 'string'
            ? response
            : response
              ? response.content
              : entry.content || '';

        controller.enqueue({
          type: 'tool-result',
          toolCallId: toolId,
          toolName: name,
          result: { output, title: name, metadata: {} },
          isError: false,
        });

        ss.emittedToolEntries.add(toolId);
        const sess = this.sessionWorkflows.get(ss.sessionKey);
        if (sess) sess.toolEntries.add(toolId);
        continue;
      }

      if (entry.message_type !== 'agent') continue;

      const content = entry.content || '';
      const msgId = entry.message_id || `idx-${i}`;
      const emittedLen = ss.agentMessageEmitted.get(msgId) ?? 0;

      if (content.length <= emittedLen) continue;

      const delta = content.slice(emittedLen);
      const isSameMsg = msgId === ss.currentAgentMessageId;

      if (!isSameMsg && ss.activeTextBlockId) {
        controller.enqueue({ type: 'text-end', id: ss.activeTextBlockId });
        ss.activeTextBlockId = null;
      }

      if (!ss.activeTextBlockId) {
        ss.activeTextBlockId = nextTextId();
        controller.enqueue({ type: 'text-start', id: ss.activeTextBlockId });
      }
      controller.enqueue({
        type: 'text-delta',
        id: ss.activeTextBlockId,
        delta,
      });
      ss.streamedOutputChars += delta.length;

      ss.agentMessageEmitted.set(msgId, content.length);
      const target =
        this.sessionWorkflows.get(ss.sessionKey)?.agentEmitted ?? this.persistedAgentEmitted;
      target.set(msgId, content.length);
      ss.currentAgentMessageId = msgId;
    }
  }

  private async executeToolAndRespond(
    ss: StreamState,
    wsClient: GitLabWorkflowClient,
    controller: ReadableStreamDefaultController<LanguageModelV3StreamPart>,
    requestID: string,
    toolName: string,
    argsJson: string,
    toolExecutor: WorkflowToolExecutor | null
  ): Promise<void> {
    ss.pendingToolCount++;

    const safeEnqueue = (part: LanguageModelV3StreamPart): void => {
      if (ss.streamClosed) {
        return;
      }
      try {
        controller.enqueue(part);
      } catch {
        // Stream may have been closed between the check and enqueue
      }
    };

    try {
      if (toolExecutor) {
        let result = await toolExecutor(toolName, argsJson, requestID);

        // When the host doesn't have edit/write tools (e.g., GPT models use
        // apply_patch instead), fall back to direct file operations so DWS
        // builtins (runEditFile, runWriteFile) still work.
        if (result.error && /^Unknown tool:/.test(result.error)) {
          const fallback = executeBuiltinFallback(toolName, argsJson);
          if (fallback) {
            result = fallback;
          }
        }

        wsClient.sendActionResponse(requestID, result.result, result.error);

        // Track tool call tokens (args as input, result as output)
        ss.streamedInputChars += argsJson.length;
        ss.streamedOutputChars += result.result.length;

        const toolOutput = result.result;
        // Use rich metadata/title from executor if provided (preserves diff, diagnostics, etc.)
        const toolTitle: string = result.title ?? `${toolName} result`;
        const toolMetadata: Record<string, unknown> = result.metadata ?? { output: result.result };

        if (result.error) {
          let errorText: string;
          if (typeof result.error === 'string') {
            errorText = result.error;
          } else if (result.error && typeof result.error === 'object') {
            errorText = JSON.stringify(result.error);
          } else {
            errorText = String(result.error);
          }
          // When isError=true, the AI SDK uses `result` directly as the error value
          // (not as an output object), so it must be a string to avoid "[object Object]"
          // in the error display.
          safeEnqueue({
            type: 'tool-result',
            toolCallId: requestID,
            toolName,
            result: errorText,
            isError: true,
          });
        } else {
          safeEnqueue({
            type: 'tool-result',
            toolCallId: requestID,
            toolName,
            result: {
              output: toolOutput,
              title: toolTitle,
              metadata: toolMetadata as Record<string, string>,
            },
            isError: false,
          });
        }
      } else {
        const errorMsg = `Tool executor not configured for tool: ${toolName}`;
        wsClient.sendActionResponse(requestID, '', errorMsg);

        safeEnqueue({
          type: 'tool-result',
          toolCallId: requestID,
          toolName,
          result: errorMsg,
          isError: true,
        });
      }
    } catch (error) {
      const rawMsg = error instanceof Error ? error.message : String(error);
      const errorMsg = sanitizeErrorMessage(rawMsg);
      wsClient.sendActionResponse(requestID, '', errorMsg);

      safeEnqueue({
        type: 'tool-result',
        toolCallId: requestID,
        toolName,
        result: errorMsg,
        isError: true,
      });
    } finally {
      ss.pendingToolCount--;

      if (this.onUsageUpdate) {
        try {
          this.onUsageUpdate({
            inputTokens: Math.ceil(ss.streamedInputChars / 4),
            outputTokens: Math.ceil(ss.streamedOutputChars / 4),
          });
        } catch {
          // ignore callback errors
        }
      }

      if (ss.pendingToolCount <= 0 && ss.deferredClose) {
        const close = ss.deferredClose;
        ss.deferredClose = null;
        close();
      }
    }
  }

  private cleanupClient(ss: StreamState, clearWorkflow = false): void {
    if (ss.activeClient) {
      ss.activeClient.close();
      this.activeClients.delete(ss.activeClient);
      ss.activeClient = null;
    }
    if (clearWorkflow) {
      if (ss.sessionKey) {
        this.sessionWorkflows.delete(ss.sessionKey);
      } else {
        this.currentWorkflowId = null;
        this.persistedAgentEmitted.clear();
      }
    }
  }

  private async approveAndResume(
    ss: StreamState,
    tools: Array<{ name: string; args: string }>,
    startReq: StartRequest | undefined,
    controller: ReadableStreamDefaultController<LanguageModelV3StreamPart>,
    toolExecutor: WorkflowToolExecutor | null,
    nextTextId: () => string,
    availableToolNames?: Set<string>,
    wsExtras?: { aiCatalogItemVersionId?: number; workflowDefinition?: string }
  ): Promise<void> {
    const handler = this.workflowOptions.approvalHandler;
    if (!handler || !startReq) {
      ss.approvalPending = false;
      if (ss.deferredClose) {
        const close = ss.deferredClose;
        ss.deferredClose = null;
        close();
      }
      return;
    }

    let decision: { approved: boolean; message?: string };
    try {
      decision = await handler(tools);
    } catch (err) {
      ss.approvalPending = false;
      if (!ss.streamClosed) controller.error(err);
      return;
    }

    ss.approvalPending = false;
    ss.deferredClose = null; // stale close from old WS — discard before reconnect

    const approval: ApprovalDecision = decision.approved
      ? { approval: { tool_name: tools[0]?.name, tool_args_json: tools[0]?.args } }
      : { rejection: { message: decision.message ?? 'User rejected' } };

    const newStartReq: StartRequest = {
      ...startReq,
      approval,
      preapproved_tools: decision.approved
        ? [...(startReq.preapproved_tools ?? []), ...tools.map((t) => t.name)]
        : (startReq.preapproved_tools ?? []),
    };

    // DWS closes the socket after asking for approval, so the decision has to go
    // out on a new one. Workhorse keeps the workflow lock until its stop
    // handshake finishes, so wait for the close and retry while it reports the
    // lock as still held, or the reconnect races it and is rejected with 1013.
    const reconnect = async (): Promise<void> => {
      if (ss.streamClosed) return;

      await this.closeClientAndWait(ss);

      const client = new GitLabWorkflowClient();
      this.activeClients.add(client);
      ss.activeClient = client;

      const modelRef = await this.resolveModelRef();
      // DWS closes the socket on every approval request, so this reconnect
      // needs the same namespace as the initial connect or it is refused with
      // 403 on instances that rely on the detected namespace. The result is
      // cached, so this does not run detection again.
      const namespaceId = (await this.resolveNamespaceId()) ?? undefined;
      await client.connect(
        {
          instanceUrl: this.config.instanceUrl,
          modelRef,
          headers: this.config.getHeaders(),
          projectId: this.workflowOptions.projectId,
          namespaceId,
          rootNamespaceId: this.workflowOptions.rootNamespaceId,
          aiCatalogItemVersionId: wsExtras?.aiCatalogItemVersionId,
          workflowDefinition: wsExtras?.workflowDefinition,
        },
        (event) => {
          if (event.type === 'closed' && event.code === WS_CLOSE_WORKFLOW_LOCKED) {
            void retryWhileLocked();
            return;
          }
          this.handleWorkflowEvent(
            ss,
            event,
            controller,
            client,
            toolExecutor,
            nextTextId,
            availableToolNames,
            newStartReq,
            wsExtras
          );
        }
      );
      client.sendStartRequest(newStartReq);
    };

    let lockRetries = 0;
    const retryWhileLocked = async (): Promise<void> => {
      if (ss.streamClosed) return;
      if (++lockRetries > WS_WORKFLOW_LOCK_MAX_RETRIES) {
        this.failStream(
          ss,
          controller,
          new GitLabError({
            message: 'Failed to acquire lock on workflow after reconnect retries',
            statusCode: WS_CLOSE_WORKFLOW_LOCKED,
          })
        );
        return;
      }
      await new Promise<void>((r) => setTimeout(r, WS_WORKFLOW_LOCK_RETRY_DELAY_MS * lockRetries));
      await reconnect().catch((err) => this.failStream(ss, controller, err));
    };

    await reconnect().catch((err) => this.failStream(ss, controller, err));
  }

  /**
   * Close the active client and wait for its close handshake, so a following
   * reconnect to the same workflow does not race the Workhorse lock.
   */
  private async closeClientAndWait(ss: StreamState): Promise<void> {
    const client = ss.activeClient;
    if (!client) return;
    this.activeClients.delete(client);
    ss.activeClient = null;
    await client.closeAndWait();
  }

  /**
   * Surface a terminal error on the stream and drop the workflow.
   */
  private failStream(
    ss: StreamState,
    controller: ReadableStreamDefaultController<LanguageModelV3StreamPart>,
    error: unknown
  ): void {
    this.cleanupClient(ss, true);
    if (ss.streamClosed) return;
    controller.error(error);
  }

  // ---------------------------------------------------------------------------
  // Workflow metadata
  // ---------------------------------------------------------------------------

  private async buildWorkflowMetadata(): Promise<Record<string, unknown>> {
    const metadata: Record<string, unknown> = {
      extended_logging: false,
      tool_approval_for_session_enabled: true,
    };

    try {
      const workDir = this.workflowOptions.workingDirectory ?? process.cwd();
      const gitInfo = await this.getGitInfo(workDir);
      if (gitInfo.url) metadata.git_url = gitInfo.url;
      if (gitInfo.sha) metadata.git_sha = gitInfo.sha;
      if (gitInfo.branch) metadata.git_branch = gitInfo.branch;
    } catch {
      // Git info is best-effort
    }

    return metadata;
  }

  private async getGitInfo(
    workDir: string
  ): Promise<{ url?: string; sha?: string; branch?: string }> {
    const { execFile } = await import('child_process');
    const { promisify } = await import('util');
    const execFileAsync = promisify(execFile);
    const opts = { cwd: workDir, timeout: 3000 };

    const run = async (cmd: string, args: string[]): Promise<string | undefined> => {
      try {
        const { stdout } = await execFileAsync(cmd, args, opts);
        return stdout.trim() || undefined;
      } catch {
        return undefined;
      }
    };

    const [url, sha, branch] = await Promise.all([
      run('git', ['remote', 'get-url', 'origin']),
      run('git', ['rev-parse', 'HEAD']),
      run('git', ['rev-parse', '--abbrev-ref', 'HEAD']),
    ]);

    return { url, sha, branch };
  }

  // ---------------------------------------------------------------------------
  // Prompt / tool extraction helpers
  // ---------------------------------------------------------------------------

  /**
   * Extract the user's goal (last user message) from the AI SDK prompt.
   */
  private static readonly SYSTEM_REMINDER_RE = /<system-reminder>([\s\S]*?)<\/system-reminder>/g;

  private extractGoalFromPrompt(prompt: LanguageModelV3Message[]): string {
    for (let i = prompt.length - 1; i >= 0; i--) {
      const message = prompt[i];
      if (message.role === 'user') {
        const textParts = message.content
          .filter((part) => part.type === 'text')
          .map((part) => (part as { type: 'text'; text: string }).text);
        if (textParts.length > 0) {
          const raw = textParts.join('\n');
          const cleaned = raw.replace(GitLabWorkflowLanguageModel.SYSTEM_REMINDER_RE, '').trim();
          return cleaned || raw;
        }
      }
    }
    return '';
  }

  /**
   * Convert AI SDK tools to DWS McpToolDefinition format.
   */
  private extractMcpTools(options: LanguageModelV3CallOptions): McpToolDefinition[] {
    if (this.workflowOptions.mcpTools && this.workflowOptions.mcpTools.length > 0) {
      return this.workflowOptions.mcpTools;
    }

    if (!options.tools || options.tools.length === 0) {
      return [];
    }

    return options.tools
      .filter((tool): tool is LanguageModelV3FunctionTool => tool.type === 'function')
      .map((tool) => ({
        name: tool.name,
        description: tool.description || '',
        inputSchema: JSON.stringify(tool.inputSchema || { type: 'object', properties: {} }),
      }));
  }

  // ---------------------------------------------------------------------------
  // Payload size management
  // ---------------------------------------------------------------------------

  private static readonly MAX_START_REQUEST_BYTES = 4 * 1024 * 1024;

  /**
   * Trim mcpTools and additionalContext to fit within the DWS 4MB gRPC
   * message size limit (`MAX_MESSAGE_SIZE` in duo_workflow_service/server.py).
   *
   * DWS has no per-field limits on tool descriptions, schemas, or context items.
   * The only hard constraint is the total serialized message size.
   *
   * Strategy (progressive, only if over budget):
   * 1. Send everything as-is
   * 2. Simplify tool input schemas (strip descriptions from properties)
   * 3. Strip schemas to minimal form (type + property names only)
   * 4. Drop tools from the end until it fits
   */
  private trimPayload(
    mcpTools: McpToolDefinition[],
    additionalContext: AdditionalContext[],
    basePayloadSize: number
  ): { mcpTools: McpToolDefinition[]; additionalContext: AdditionalContext[] } {
    const budget = GitLabWorkflowLanguageModel.MAX_START_REQUEST_BYTES - basePayloadSize;
    const contextJson = JSON.stringify(additionalContext);

    const toolsJson = JSON.stringify(mcpTools);
    const totalSize = toolsJson.length + contextJson.length;

    if (totalSize <= budget) {
      return { mcpTools, additionalContext };
    }

    const simplifiedTools = mcpTools.map((tool) => ({
      name: tool.name,
      description: tool.description,
      inputSchema: simplifySchema(tool.inputSchema),
    }));

    const simpSize = JSON.stringify(simplifiedTools).length + contextJson.length;
    if (simpSize <= budget) {
      return { mcpTools: simplifiedTools, additionalContext };
    }

    const minTools = simplifiedTools.map((tool) => ({
      name: tool.name,
      description: tool.description,
      inputSchema: minimalSchema(tool.inputSchema),
    }));

    const minSize = JSON.stringify(minTools).length + contextJson.length;
    if (minSize <= budget) {
      return { mcpTools: minTools, additionalContext };
    }

    const keptTools = [...minTools];
    while (keptTools.length > 0) {
      const currentSize = JSON.stringify(keptTools).length + contextJson.length;
      if (currentSize <= budget) break;
      keptTools.pop();
    }

    return { mcpTools: keptTools, additionalContext };
  }

  private buildAdditionalContext(prompt: LanguageModelV3Message[]): AdditionalContext[] {
    const context: AdditionalContext[] = [];

    if (this.workflowOptions.additionalContext) {
      context.push(...this.workflowOptions.additionalContext);
    }

    for (const message of prompt) {
      if (message.role === 'system') {
        context.push({
          category: 'system_prompt',
          content: message.content,
          metadata: JSON.stringify({ role: 'system' }),
        });
      } else if (message.role === 'assistant') {
        const textContent = message.content
          .filter((part) => part.type === 'text')
          .map((part) => (part as { type: 'text'; text: string }).text)
          .join('\n');
        if (textContent) {
          context.push({
            category: 'conversation',
            content: textContent,
            metadata: JSON.stringify({ role: 'assistant' }),
          });
        }
      } else if (message.role === 'user') {
        for (const part of message.content) {
          if (part.type === 'text') {
            const text = (part as { type: 'text'; text: string }).text;
            const matches = text.matchAll(GitLabWorkflowLanguageModel.SYSTEM_REMINDER_RE);
            for (const match of matches) {
              const inner = match[1].trim();
              if (inner) {
                context.push({
                  category: 'agent_context',
                  content: inner,
                  metadata: JSON.stringify({ source: 'system-reminder' }),
                });
              }
            }
          }
        }
      }
    }

    return context;
  }
}
