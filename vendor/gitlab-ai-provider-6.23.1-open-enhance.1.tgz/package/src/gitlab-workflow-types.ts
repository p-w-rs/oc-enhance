/**
 * Types for the GitLab Duo Agent Platform (DWS) protocol.
 *
 * DWS uses a WebSocket-based bidirectional protocol where:
 * - Client sends `ClientEvent` messages (startRequest, actionResponse, stopWorkflow, heartbeat)
 * - Server sends `WorkflowAction` messages (newCheckpoint, runMcpTool, built-in tools)
 *
 * Message format is JSON-serialized protobuf with camelCase field names.
 */

// ---------------------------------------------------------------------------
// Token / workflow creation responses
// ---------------------------------------------------------------------------

export interface GenerateTokenResponse {
  gitlab_rails: {
    base_url: string;
    token: string;
    token_expires_at: string;
  };
  duo_workflow_service: {
    base_url: string;
    token: string;
    secure: boolean;
    token_expires_at: number;
    headers: Record<string, string>;
  };
  duo_workflow_executor: {
    executor_binary_url: string;
    version: string;
  };
}

export interface CreateWorkflowResponse {
  id: string;
}

// ---------------------------------------------------------------------------
// MCP tool definitions (sent in startRequest)
// ---------------------------------------------------------------------------

export interface McpToolDefinition {
  name: string;
  description: string;
  inputSchema: string;
}

// ---------------------------------------------------------------------------
// Client → Server messages (ClientEvent)
// ---------------------------------------------------------------------------

export interface AdditionalContext {
  category: string;
  id?: string;
  content?: string;
  metadata?: string;
}

export interface StartRequest {
  workflowID: string;
  clientVersion: string;
  workflowDefinition: string;
  goal: string;
  workflowMetadata?: string;
  additional_context?: AdditionalContext[];
  clientCapabilities?: string[];
  mcpTools?: McpToolDefinition[];
  preapproved_tools?: string[];
  flowConfig?: unknown;
  flowConfigSchemaVersion?: string;
  approval?: ApprovalDecision;
}

export interface ApprovalDecision {
  approval?: {
    remember_approval?: boolean;
    tool_name?: string;
    tool_args_json?: string;
  };
  rejection?: {
    message?: string;
  };
}

export interface ActionResponsePayload {
  requestID: string;
  plainTextResponse: {
    response: string;
    error: string | null;
  };
}

export interface StopWorkflow {
  reason: string;
}

export interface Heartbeat {
  timestamp: number;
}

/**
 * Client → Server event union.
 * Exactly one of the fields should be set per message.
 */
export type ClientEvent =
  | { startRequest: StartRequest }
  | { actionResponse: ActionResponsePayload }
  | { stopWorkflow: StopWorkflow }
  | { heartbeat: Heartbeat };

// ---------------------------------------------------------------------------
// Server → Client messages (WorkflowAction)
// ---------------------------------------------------------------------------

export type WorkflowStatus =
  | 'CREATED'
  | 'RUNNING'
  | 'FINISHED'
  | 'COMPLETED'
  | 'FAILED'
  | 'STOPPED'
  | 'CANCELLED'
  | 'PAUSED'
  | 'INPUT_REQUIRED'
  | 'PLAN_APPROVAL_REQUIRED'
  | 'TOOL_CALL_APPROVAL_REQUIRED'
  | 'UNKNOWN';

export interface NewCheckpoint {
  status: WorkflowStatus;
  goal?: string;
  /** Raw checkpoint JSON string from DWS (contains channel_values.ui_chat_log) */
  checkpoint?: string;
  /** Legacy content field (may be empty — text is in checkpoint.ui_chat_log) */
  content?: string;
}

// ---------------------------------------------------------------------------
// Checkpoint parsing types (based on gitlab-lsp ui_chat_log.ts)
// ---------------------------------------------------------------------------

export interface UiChatLogEntry {
  message_type: 'user' | 'agent' | 'tool' | 'request';
  message_sub_type: string | null;
  content: string;
  message_id?: string;
  timestamp: string;
  status: string | null;
  correlation_id: string | null;
  tool_info: UiChatLogToolInfo | null;
  additional_context: unknown;
}

export interface UiChatLogToolInfo {
  name: string;
  args: Record<string, unknown>;
  tool_response?: UiChatLogToolResponse | string;
}

export interface UiChatLogToolResponse {
  content: string;
  type: string;
  name: string;
  id: string | null;
  tool_call_id: string;
  status: string;
}

export interface CheckpointData {
  channel_values: {
    ui_chat_log?: UiChatLogEntry[];
    plan?: { steps: unknown[] };
    status?: string;
    [key: string]: unknown;
  };
}

export interface RunMcpTool {
  name: string;
  args: string;
}

export interface ReadFileAction {
  filepath: string;
}

export interface ReadFilesAction {
  filepaths: string[];
}

export interface WriteFileAction {
  filepath: string;
  contents: string;
}

export interface ShellCommandAction {
  command: string;
}

export interface EditFileAction {
  filepath: string;
  oldString: string;
  newString: string;
}

export interface ListDirectoryAction {
  directory: string;
}

export interface FindFilesAction {
  name_pattern: string;
}

export interface GrepAction {
  pattern: string;
  search_directory?: string;
  case_insensitive?: boolean;
}

export interface MkdirAction {
  directory_path: string;
}

export interface RunCommandAction {
  program: string;
  flags?: string[];
  arguments?: string[];
}

export interface RunGitCommandAction {
  command: string;
  arguments?: string[];
  repository_url?: string;
}

export interface GitLabApiRequestAction {
  method: string;
  path: string;
  body?: string;
}

/**
 * Server → Client action union.
 * Field names match the DWS protobuf camelCase wire format exactly.
 * Each message has an optional `requestID` (required for tool invocations
 * that need an `actionResponse` back).
 */
export interface WorkflowAction {
  requestID?: string;

  newCheckpoint?: NewCheckpoint;

  runMCPTool?: RunMcpTool;

  runReadFile?: ReadFileAction;
  runReadFiles?: ReadFilesAction;
  runWriteFile?: WriteFileAction;
  runShellCommand?: ShellCommandAction;
  runEditFile?: EditFileAction;
  listDirectory?: ListDirectoryAction;
  findFiles?: FindFilesAction;
  grep?: GrepAction;
  mkdir?: MkdirAction;
  runCommand?: RunCommandAction;
  runGitCommand?: RunGitCommandAction;
  runHTTPRequest?: GitLabApiRequestAction;
}

// ---------------------------------------------------------------------------
// Provider options
// ---------------------------------------------------------------------------

/**
 * Options for creating a workflow chat model via `provider.workflowChat()`.
 */
export interface GitLabWorkflowOptions {
  /**
   * Workflow definition type.
   * @default 'chat'
   */
  workflowDefinition?: string;

  /**
   * Root namespace ID for the GitLab group/project.
   * Used for token scoping and model discovery.
   */
  rootNamespaceId?: string;

  /**
   * GitLab project ID (numeric or path).
   * Sent as `x-gitlab-project-id` header on WebSocket.
   */
  projectId?: string;

  /**
   * GitLab namespace ID, as a **plain numeric id** (e.g. `'12'`, not
   * `'gid://gitlab/Group/12'`).
   * Sent as `x-gitlab-namespace-id` header on WebSocket and used for workflow
   * creation. When unset, the WebSocket on self-managed instances falls back to
   * the namespace of the project detected from the git remote; GitLab.com
   * relies on the user's default Duo namespace preference.
   */
  namespaceId?: string;

  /**
   * MCP tool definitions to expose to the workflow.
   * These are sent in `startRequest.mcpTools`.
   */
  mcpTools?: McpToolDefinition[];

  /**
   * Client capabilities to advertise.
   * @default ['shell_command']
   */
  clientCapabilities?: string[];

  /**
   * Tool names that are pre-approved for execution without user confirmation.
   * Sent in `startRequest.preapproved_tools`.
   */
  preapprovedTools?: string[];

  /**
   * Additional context items to send with the first request.
   * Used for conversation history continuity.
   */
  additionalContext?: AdditionalContext[];

  /**
   * Feature flags to pass to the GitLab API.
   */
  featureFlags?: Record<string, boolean>;

  /**
   * Working directory for auto-detecting GitLab project from git remote.
   * Used to resolve `projectId` when not explicitly set.
   * Defaults to `process.cwd()`.
   */
  workingDirectory?: string;

  /**
   * System prompt to override DWS's default system prompt.
   * Sent via `flowConfig.prompts[].prompt_template.system`.
   *
   * When set and `flowConfig` is not explicitly provided, the SDK
   * auto-generates the appropriate `flowConfig` and sets
   * `flowConfigSchemaVersion` to `'v1'`.
   *
   * Explicit `flowConfig` takes precedence if both are provided.
   */
  systemPrompt?: string;

  /**
   * Flow configuration (parsed YAML object) to send to DWS.
   * Controls agent behavior, intermediate text generation, etc.
   * Sent as `startRequest.flowConfig`.
   * Takes precedence over `systemPrompt` if both are provided.
   */
  flowConfig?: unknown;

  /**
   * Schema version for the flow configuration.
   * Sent as `startRequest.flowConfigSchemaVersion`.
   */
  flowConfigSchemaVersion?: string;

  /**
   * Callback invoked when multiple workflow models are available for the
   * workspace and model switching is enabled by the instance admin.
   *
   * The provider calls this before starting the workflow so the host can
   * present a model picker to the user. Return the `ref` of the chosen
   * model, or `null`/`undefined` to fall back to the workspace default.
   *
   * If the returned ref is not in the list of selectable models it is
   * ignored and the workspace default is used instead.
   *
   * Not called when the admin has pinned a model — in that case the
   * pinned model is always used regardless of user preference.
   *
   * @param models - List of models the user can select from
   * @returns The selected model ref, or null/undefined for default
   */
  onSelectModel?: (
    models: import('./gitlab-model-discovery').AiModel[]
  ) => Promise<string | null | undefined>;

  /**
   * Agent privileges to request when creating the workflow.
   * Defaults to DEFAULT_AGENT_PRIVILEGES (all privileges).
   * Pass a subset to restrict which tools DWS pre-approves server-side,
   * causing TOOL_CALL_APPROVAL_REQUIRED for excluded privileges.
   */
  agentPrivileges?: number[];

  /**
   * Called when DWS requires approval for a tool call.
   * Return `{ approved: true }` to proceed or `{ approved: false, message? }` to reject.
   * If not set, the stream ends silently when approval is required (backward compat).
   */
  approvalHandler?: (
    tools: Array<{ name: string; args: string }>
  ) => Promise<{ approved: boolean; message?: string }>;
}

// ---------------------------------------------------------------------------
// WebSocket client configuration
// ---------------------------------------------------------------------------

export interface GitLabWorkflowClientConfig {
  /** GitLab instance URL (e.g., 'https://gitlab.com') */
  instanceUrl: string;

  /** Function to get current auth headers */
  getHeaders: () => Record<string, string>;

  /**
   * Optional callback to refresh the API key when a 401 error occurs.
   */
  refreshApiKey?: () => Promise<void>;

  /** Custom fetch implementation */
  fetch?: typeof fetch;

  /** Feature flags for the token request */
  featureFlags?: Record<string, boolean>;

  /**
   * AI Gateway URL.
   * Can also be set via GITLAB_AI_GATEWAY_URL environment variable.
   * @default 'https://cloud.gitlab.com'
   */
  aiGatewayUrl?: string;
}

// ---------------------------------------------------------------------------
// WebSocket event types (emitted by GitLabWorkflowClient)
// ---------------------------------------------------------------------------

export type WorkflowClientEvent =
  | { type: 'checkpoint'; data: NewCheckpoint }
  | { type: 'tool-request'; requestID: string; data: RunMcpTool }
  | {
      type: 'builtin-tool-request';
      requestID: string;
      toolName: string;
      data: Record<string, unknown>;
    }
  | { type: 'approval-required'; tools: Array<{ name: string; args: string }> }
  | { type: 'completed' }
  | { type: 'failed'; error: Error }
  | { type: 'closed'; code: number; reason: string };

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/**
 * Workflow type enum — matches gitlab-lsp WorkflowType.
 *
 * - CHAT: Shared token across sessions, tokens NOT revoked on completion
 * - SOFTWARE_DEVELOPMENT: Per-workflow token, tokens revoked on completion
 */
export enum WorkflowType {
  CHAT = 'chat',
  SOFTWARE_DEVELOPMENT = 'software_development',
}

/** WebSocket ping interval (TCP keepalive) — 45s matching gitlab-lsp */
export const WS_KEEPALIVE_PING_INTERVAL_MS = 45_000;

/** Application heartbeat interval — 60s matching gitlab-lsp */
export const WS_HEARTBEAT_INTERVAL_MS = 60_000;

/**
 * WebSocket close code Workhorse sends when another session still holds the
 * exclusive lock on the workflow ("Failed to acquire lock on workflow").
 */
export const WS_CLOSE_WORKFLOW_LOCKED = 1013;

/**
 * How long to wait for the previous socket's close handshake before
 * reconnecting to the same workflow. Workhorse frees the lock only after that
 * handshake, so reconnecting immediately races it.
 */
export const WS_CLOSE_WAIT_TIMEOUT_MS = 3_000;

/** Delay before retrying a reconnect that Workhorse rejected with 1013. */
export const WS_WORKFLOW_LOCK_RETRY_DELAY_MS = 1_500;

/** How many times to retry a reconnect rejected with 1013. */
export const WS_WORKFLOW_LOCK_MAX_RETRIES = 8;

/** Default workflow definition — uses CHAT for agentic chat (matches gitlab-lsp) */
export const DEFAULT_WORKFLOW_DEFINITION = WorkflowType.CHAT;

/** Default client capabilities */
export const DEFAULT_CLIENT_CAPABILITIES = ['shell_command'];

/** Client version sent in startRequest */
export const CLIENT_VERSION = '8.51.0';

/** Stop reason for user-initiated stop */
export const STOP_REASON_USER = 'USER_ACTION_TRIGGERED_STOP';

/**
 * Agent privileges for workflow creation.
 * Matches gitlab-lsp AGENT_PRIVILEGES enum.
 */
export const AGENT_PRIVILEGES = {
  READ_WRITE_FILES: 1,
  READ_ONLY_GITLAB: 2,
  READ_WRITE_GITLAB: 3,
  RUN_COMMANDS: 4,
  USE_GIT: 5,
  RUN_MCP_TOOLS: 6,
} as const;

/** Default agent privileges — matches gitlab-lsp defaults */
export const DEFAULT_AGENT_PRIVILEGES = [
  AGENT_PRIVILEGES.READ_WRITE_FILES,
  AGENT_PRIVILEGES.READ_ONLY_GITLAB,
  AGENT_PRIVILEGES.READ_WRITE_GITLAB,
  AGENT_PRIVILEGES.RUN_COMMANDS,
  AGENT_PRIVILEGES.RUN_MCP_TOOLS,
  AGENT_PRIVILEGES.USE_GIT,
];

/** Workflow execution environment */
export const WORKFLOW_ENVIRONMENT = 'ide' as const;
