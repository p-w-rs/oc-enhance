import { GitLabAnthropicLanguageModel } from './gitlab-anthropic-language-model';
import type { GitLabThinkingConfig } from './gitlab-anthropic-language-model';
import { GitLabOpenAILanguageModel } from './gitlab-openai-language-model';
import { GitLabWorkflowLanguageModel } from './gitlab-workflow-language-model';
import { GitLabError } from './gitlab-error';
import type { LanguageModelV3 } from '@ai-sdk/provider';
import { GitLabOAuthManager } from './gitlab-oauth-manager';
import type { OpenCodeAuth } from './gitlab-oauth-types';
import { GITLAB_COM_URL } from './gitlab-oauth-types';
import { getModelMapping, getValidModelsForProvider, isWorkflowModel } from './model-mappings';
import type { GitLabWorkflowOptions } from './gitlab-workflow-types';
import { VERSION } from './version';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

export interface GitLabProvider {
  (modelId: string): LanguageModelV3;
  readonly specificationVersion: 'v3';
  languageModel(modelId: string): LanguageModelV3;
  chat(modelId: string): LanguageModelV3;
  /**
   * Create an agentic chat model with tool calling support
   *
   * @param modelId - GitLab model identifier. Some IDs automatically map to specific Anthropic models.
   * @param options - Configuration options for the agentic model
   * @returns A language model with native tool calling support via Anthropic
   *
   * @example
   * // Automatic model mapping
   * const model = gitlab.agenticChat('duo-chat-opus-4-5');
   * // Uses claude-opus-4-5-20251101
   *
   * @example
   * // Explicit model override
   * const model = gitlab.agenticChat('duo-chat', {
   *   anthropicModel: 'claude-sonnet-4-5-20250929'
   * });
   */
  agenticChat(modelId: string, options?: GitLabAgenticOptions): GitLabAnthropicLanguageModel;
  /**
   * Create a workflow chat model using GitLab Duo Agent Platform.
   *
   * Workflow models use a server-side agentic loop where GitLab's DWS drives
   * the LLM, requests tool executions from the client via WebSocket, and
   * streams text/status back.
   *
   * Requires GitLab Ultimate with Duo Enterprise add-on.
   *
   * @param modelId - Workflow model identifier (e.g., 'duo-workflow-sonnet-4-6')
   * @param options - Workflow-specific configuration
   * @returns A language model backed by the DWS WebSocket protocol
   *
   * @example
   * const model = gitlab.workflowChat('duo-workflow-sonnet-4-6', {
   *   mcpTools: [...],
   *   preapprovedTools: ['read_file', 'write_file'],
   * });
   */
  workflowChat(modelId: string, options?: GitLabWorkflowOptions): GitLabWorkflowLanguageModel;
  embeddingModel(modelId: string): never;
  imageModel(modelId: string): never;
}

export interface GitLabAgenticOptions {
  /**
   * Override the provider-specific model (optional).
   * Must be a valid model for the detected provider.
   *
   * For Anthropic models:
   * - 'claude-opus-4-6'
   * - 'claude-sonnet-4-6'
   * - 'claude-opus-4-5-20251101'
   * - 'claude-sonnet-4-5-20250929'
   * - 'claude-haiku-4-5-20251001'
   *
   * For OpenAI models:
   * - 'gpt-5.1-2025-11-13'
   * - 'gpt-5-mini-2025-08-07'
   * - 'gpt-5-codex'
   * - 'gpt-5.2-codex'
   *
   * @example
   * // Override with explicit model
   * const model = gitlab.agenticChat('duo-chat-opus-4-5', {
   *   providerModel: 'claude-sonnet-4-5-20250929'
   * });
   */
  providerModel?: string;

  /**
   * Maximum tokens to generate
   * @default 8192
   */
  maxTokens?: number;

  /**
   * Default reasoning effort for OpenAI models.
   * Can be overridden per call through `providerOptions.gitlab.reasoningEffort`.
   */
  reasoningEffort?: 'none' | 'minimal' | 'low' | 'medium' | 'high' | 'xhigh' | 'max';

  /**
   * Default extended thinking configuration for Anthropic Messages API models.
   * Can be overridden per call through `providerOptions.gitlab.thinking`.
   */
  thinking?: GitLabThinkingConfig;

  /**
   * Feature flags to pass to the GitLab API
   */
  featureFlags?: Record<string, boolean>;

  /**
   * Custom headers for AI Gateway requests (per-model override).
   * These headers are sent to the Anthropic/OpenAI proxy endpoints.
   * Merged with provider-level aiGatewayHeaders (model-level takes precedence).
   */
  aiGatewayHeaders?: Record<string, string>;
}

export interface GitLabProviderSettings {
  /**
   * GitLab instance URL (e.g., 'https://gitlab.com')
   * Can also be set via GITLAB_INSTANCE_URL environment variable.
   * @default 'https://gitlab.com'
   */
  instanceUrl?: string;

  /**
   * API token (Personal Access Token or OAuth access token)
   * Can also be set via GITLAB_TOKEN environment variable
   */
  apiKey?: string;

  /**
   * OAuth refresh token (optional, for OAuth flow)
   */
  refreshToken?: string;

  /**
   * OAuth client ID (required for OAuth flow)
   */
  clientId?: string;

  /**
   * OAuth redirect URI (required for OAuth flow)
   */
  redirectUri?: string;

  /**
   * Custom headers to include in requests
   */
  headers?: Record<string, string>;

  /**
   * Custom fetch implementation
   */
  fetch?: typeof fetch;

  /**
   * Default workflow options for `duo-workflow-*` models.
   *
   * Hosts that construct models through the plain `provider(modelId)` /
   * `languageModel(modelId)` entry points — OpenCode does — cannot pass
   * `GitLabWorkflowOptions`, so without this there is no way to supply a
   * namespace from configuration. The Duo Agent Platform needs one: both
   * `POST /api/v4/ai/duo_workflows/workflows` and the DWS WebSocket reject the
   * request otherwise, unless the user has a default Duo namespace preference.
   */
  workflowOptions?: GitLabWorkflowOptions;

  /**
   * Provider name override
   */
  name?: string;

  /**
   * Default feature flags to pass to the GitLab API for all agentic chat models
   */
  featureFlags?: Record<string, boolean>;

  /**
   * AI Gateway URL for the Anthropic proxy.
   * Can also be set via GITLAB_AI_GATEWAY_URL environment variable.
   * @default 'https://cloud.gitlab.com'
   */
  aiGatewayUrl?: string;

  /**
   * Private POSIX directory for shared direct-access tokens; empty string disables caching.
   * Falls back to GITLAB_DIRECT_ACCESS_CACHE_DIR when omitted.
   * @default undefined
   */
  directAccessCacheDir?: string;

  /**
   * Custom headers to include in AI Gateway requests (Anthropic/OpenAI proxy).
   * These headers are merged with the default headers from direct_access response.
   * Default User-Agent: gitlab-ai-provider/{version}
   */
  aiGatewayHeaders?: Record<string, string>;
}

/**
 * Get OpenCode auth file path
 * Uses XDG Base Directory specification
 */
function getOpenCodeAuthPath(): string {
  const homeDir = os.homedir();

  // Check XDG_DATA_HOME first (Linux/Mac standard)
  const xdgDataHome = process.env.XDG_DATA_HOME;
  if (xdgDataHome) {
    return path.join(xdgDataHome, 'opencode', 'auth.json');
  }

  // Fallback to ~/.local/share/opencode/auth.json (XDG default)
  if (process.platform !== 'win32') {
    return path.join(homeDir, '.local', 'share', 'opencode', 'auth.json');
  }

  // Windows fallback
  return path.join(homeDir, '.opencode', 'auth.json');
}

/**
 * Load OpenCode auth.json file
 */
async function loadOpenCodeAuth(instanceUrl: string): Promise<OpenCodeAuth | undefined> {
  try {
    const authPath = getOpenCodeAuthPath();

    if (!fs.existsSync(authPath)) {
      return undefined;
    }

    const authData = JSON.parse(fs.readFileSync(authPath, 'utf-8'));
    const normalizedUrl = instanceUrl.replace(/\/$/, '');

    // Priority 1: Check 'gitlab' key (used by opencode-gitlab-auth plugin)
    const gitlabAuth = authData.gitlab;
    if (gitlabAuth?.type === 'oauth') {
      // Verify it matches the requested instance URL (normalize trailing slashes on both sides).
      // The auth plugin does not always write enterpriseUrl; when it is missing/null we treat the
      // entry as belonging to the default gitlab.com instance so OAuth tokens are not silently dropped.
      const normalizedEnterpriseUrl =
        typeof gitlabAuth.enterpriseUrl === 'string'
          ? gitlabAuth.enterpriseUrl.replace(/\/$/, '')
          : undefined;
      const matchesInstance =
        normalizedEnterpriseUrl === normalizedUrl ||
        (normalizedEnterpriseUrl === undefined && normalizedUrl === GITLAB_COM_URL);
      if (matchesInstance) {
        return gitlabAuth as OpenCodeAuth;
      }
    } else if (gitlabAuth?.type === 'api' && typeof gitlabAuth.key === 'string') {
      // Personal access token stored under the 'gitlab' key by the auth plugin.
      return gitlabAuth as OpenCodeAuth;
    }

    // Priority 2: Try to find auth for this instance by URL
    // Check both with and without trailing slash
    const auth = authData[normalizedUrl] || authData[`${normalizedUrl}/`];

    return auth as OpenCodeAuth | undefined;
  } catch {
    return undefined;
  }
}

/**
 * Module-global dedup for OAuth token refresh, keyed by instance URL.
 *
 * GitLab refresh tokens are single-use. opencode creates a separate provider
 * per model and several agents can request a token concurrently; without
 * cross-caller dedup, each would read the same stored refresh token and race to
 * exchange it, so only the first succeeds and the rest fail with 401
 * ("Forbidden by auth provider"). Keying on instance URL (rather than the
 * refresh token) collapses all concurrent refreshes for an instance into one,
 * regardless of which token each caller happened to read first.
 */
const inFlightOAuthRefreshes = new Map<string, Promise<string>>();

/**
 * Refresh an OAuth token and persist the rotated tokens to auth.json,
 * deduplicating concurrent refreshes for the same instance.
 */
async function refreshOAuthToken(
  auth: { refresh: string },
  instanceUrl: string,
  clientId?: string
): Promise<string> {
  const existing = inFlightOAuthRefreshes.get(instanceUrl);
  if (existing) {
    return existing;
  }

  const refreshPromise = (async () => {
    const oauthManager = new GitLabOAuthManager();
    const refreshed = await oauthManager.exchangeRefreshToken({
      instanceUrl,
      refreshToken: auth.refresh,
      clientId,
    });

    // Update stored token under 'gitlab' key (same format as opencode-gitlab-auth plugin)
    const authPath = getOpenCodeAuthPath();
    const authData = JSON.parse(fs.readFileSync(authPath, 'utf-8'));

    authData.gitlab = {
      type: 'oauth',
      refresh: refreshed.refreshToken,
      access: refreshed.accessToken,
      expires: refreshed.expiresAt,
      enterpriseUrl: instanceUrl, // Use enterpriseUrl to match auth plugin format
    };

    fs.writeFileSync(authPath, JSON.stringify(authData, null, 2), { mode: 0o600 });

    return refreshed.accessToken;
  })();

  inFlightOAuthRefreshes.set(instanceUrl, refreshPromise);

  try {
    return await refreshPromise;
  } finally {
    inFlightOAuthRefreshes.delete(instanceUrl);
  }
}

/**
 * Load GitLab API key with OAuth support
 * Priority: explicit apiKey > OAuth token > env var
 */
async function loadApiKey(
  options: {
    apiKey?: string;
    environmentVariableName: string;
    description: string;
  },
  instanceUrl: string,
  clientId?: string
): Promise<string> {
  // Priority 1: Explicit apiKey
  if (options.apiKey) {
    return options.apiKey;
  }

  // Priority 2: Auth from OpenCode auth.json
  const auth = await loadOpenCodeAuth(instanceUrl);
  if (auth?.type === 'api') {
    return auth.key;
  }
  if (auth?.type === 'oauth') {
    const oauthManager = new GitLabOAuthManager();

    // Check if token needs refresh
    if (oauthManager.needsRefresh(auth.expires)) {
      try {
        return await refreshOAuthToken(auth, instanceUrl, clientId);
      } catch (error) {
        // If refresh fails, fall through to env var but remember the error
        const refreshErrorMsg = error instanceof Error ? error.message : String(error);
        // Silently handle refresh failure — avoid stdout output that interferes with TUI

        // Priority 3: Environment variable (fallback when refresh fails)
        const envApiKey = process.env[options.environmentVariableName];
        if (envApiKey) {
          return envApiKey;
        }

        // No env var fallback — throw with the refresh failure context
        throw new GitLabError({
          message:
            `OAuth token refresh failed and no fallback ${options.environmentVariableName} environment variable is set. ` +
            `Refresh error: ${refreshErrorMsg}. ` +
            `Re-authenticate with 'opencode auth login gitlab' or set ${options.environmentVariableName}.`,
        });
      }
    } else {
      return auth.access;
    }
  }

  // Priority 3: Environment variable
  const apiKey = process.env[options.environmentVariableName];

  if (!apiKey) {
    throw new GitLabError({
      message: `${options.description} API key is missing. Pass it as the 'apiKey' parameter, set the ${options.environmentVariableName} environment variable, or authenticate with 'opencode auth login gitlab'.`,
    });
  }

  return apiKey;
}

function withUserAgentSuffix(
  headers: Record<string, string>,
  suffix: string
): Record<string, string> {
  const userAgent = headers['User-Agent'];
  return {
    ...headers,
    'User-Agent': userAgent ? `${userAgent} ${suffix}` : suffix,
  };
}

/**
 * Merge provider-level workflow defaults with per-call workflow options.
 *
 * Per-call values win, but keys explicitly set to `undefined` are ignored so a
 * host that forwards optional fields as-is (OpenCode passes
 * `workflowDefinition: undefined`) does not erase the configured default.
 * `featureFlags` are merged rather than replaced.
 *
 * @param defaults - Provider-level `workflowOptions` from settings
 * @param overrides - Per-call options passed to `workflowChat()`
 * @returns The effective options, or `undefined` when neither is set
 */
function mergeWorkflowOptions(
  defaults: GitLabWorkflowOptions | undefined,
  overrides: GitLabWorkflowOptions | undefined
): GitLabWorkflowOptions | undefined {
  if (!defaults && !overrides) return undefined;

  const definedOverrides = Object.fromEntries(
    Object.entries(overrides ?? {}).filter(([, value]) => value !== undefined)
  ) as GitLabWorkflowOptions;

  const merged: GitLabWorkflowOptions = { ...defaults, ...definedOverrides };

  if (defaults?.featureFlags || overrides?.featureFlags) {
    merged.featureFlags = { ...defaults?.featureFlags, ...overrides?.featureFlags };
  }

  return merged;
}

export function createGitLab(options: GitLabProviderSettings = {}): GitLabProvider {
  const instanceUrl =
    options.instanceUrl ?? process.env['GITLAB_INSTANCE_URL'] ?? 'https://gitlab.com';
  const providerName = options.name ?? 'gitlab';

  // Cache for the API key - loaded lazily on first use
  let cachedApiKey: string | undefined;
  let apiKeyPromise: Promise<string> | undefined;
  let refreshPromise: Promise<void> | undefined;

  const getApiKey = async (): Promise<string> => {
    if (cachedApiKey) {
      return cachedApiKey;
    }

    if (apiKeyPromise) {
      return apiKeyPromise;
    }

    apiKeyPromise = loadApiKey(
      {
        apiKey: options.apiKey,
        environmentVariableName: 'GITLAB_TOKEN',
        description: 'GitLab',
      },
      instanceUrl,
      options.clientId
    );

    try {
      cachedApiKey = await apiKeyPromise;
      return cachedApiKey;
    } finally {
      apiKeyPromise = undefined;
    }
  };

  /**
   * Refresh the API key by clearing the cache and re-fetching from auth provider.
   * This is called when a 401 error occurs to trigger OAuth token refresh.
   */
  const refreshApiKey = async (): Promise<void> => {
    if (refreshPromise) {
      return refreshPromise;
    }

    refreshPromise = (async () => {
      // Clear the cached API key to force a refresh
      cachedApiKey = undefined;
      apiKeyPromise = undefined;

      // Re-fetch the API key, but don't pass the stale options.apiKey
      // This forces loadApiKey to read from auth.json and potentially refresh the OAuth token
      cachedApiKey = await loadApiKey(
        {
          apiKey: undefined, // Bypass stale options.apiKey to force auth.json read
          environmentVariableName: 'GITLAB_TOKEN',
          description: 'GitLab',
        },
        instanceUrl,
        options.clientId
      );
    })();

    try {
      return await refreshPromise;
    } finally {
      refreshPromise = undefined;
    }
  };

  const getHeaders = () => {
    // For synchronous access, we need to have the key already loaded
    // or fall back to env var/explicit key
    const apiKey = cachedApiKey || options.apiKey || process.env['GITLAB_TOKEN'] || '';

    if (!apiKey) {
      throw new GitLabError({
        message:
          "GitLab API key is missing. Pass it as the 'apiKey' parameter, set the GITLAB_TOKEN environment variable, or authenticate with 'opencode auth login gitlab'.",
      });
    }

    return withUserAgentSuffix(
      {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        ...options.headers,
      },
      `ai-sdk-gitlab/${VERSION}`
    );
  };

  // Ensure the API key is loaded before synchronous getHeaders() is used.
  // getHeaders is synchronous but the key loads asynchronously; awaiting this
  // avoids a cold-start race where the first request throws "API key is missing"
  // or sends an empty Authorization header. Swallows errors so getHeaders can
  // surface a clear message (or env/explicit-key fallbacks still apply).
  const ensureApiKey = async (): Promise<void> => {
    try {
      await getApiKey();
    } catch {
      // Ignore — getHeaders falls back to options.apiKey / GITLAB_TOKEN or throws.
    }
  };

  // Pre-load the API key asynchronously
  getApiKey().catch(() => {
    // Silently fail - will be caught when getHeaders is called
  });

  const createAgenticChatModel = (modelId: string, agenticOptions?: GitLabAgenticOptions) => {
    const mapping = getModelMapping(modelId);

    if (!mapping) {
      throw new GitLabError({
        message: `Unknown model ID: ${modelId}. Model must be registered in MODEL_MAPPINGS.`,
      });
    }

    if (agenticOptions?.providerModel) {
      const validModels = getValidModelsForProvider(mapping.provider);
      if (!validModels.includes(agenticOptions.providerModel)) {
        throw new GitLabError({
          message: `Invalid providerModel '${agenticOptions.providerModel}' for provider '${mapping.provider}'. Valid models: ${validModels.join(', ')}`,
        });
      }
    }

    const featureFlags = {
      DuoAgentPlatformNext: true as const,
      ...options.featureFlags,
      ...agenticOptions?.featureFlags,
    };

    const defaultAiGatewayHeaders = {
      'User-Agent': `gitlab-ai-provider/${VERSION}`,
    };

    const aiGatewayHeaders = {
      ...defaultAiGatewayHeaders,
      ...options.aiGatewayHeaders,
      ...agenticOptions?.aiGatewayHeaders,
    };

    const baseConfig = {
      provider: `${providerName}.agentic`,
      instanceUrl,
      getHeaders,
      ensureApiKey,
      refreshApiKey,
      fetch: options.fetch,
      maxTokens: agenticOptions?.maxTokens,
      featureFlags,
      aiGatewayUrl: options.aiGatewayUrl,
      directAccessCacheDir: options.directAccessCacheDir,
      aiGatewayHeaders,
    };

    if (mapping.provider === 'openai') {
      return new GitLabOpenAILanguageModel(modelId, {
        ...baseConfig,
        openaiModel: agenticOptions?.providerModel ?? mapping.model,
        reasoningEffort: agenticOptions?.reasoningEffort,
      });
    }

    return new GitLabAnthropicLanguageModel(modelId, {
      ...baseConfig,
      anthropicModel: agenticOptions?.providerModel ?? mapping.model,
      thinking: agenticOptions?.thinking,
    });
  };

  const createWorkflowChatModel = (
    modelId: string,
    workflowOptions?: GitLabWorkflowOptions
  ): GitLabWorkflowLanguageModel => {
    const effectiveWorkflowOptions = mergeWorkflowOptions(options.workflowOptions, workflowOptions);

    const mapping = getModelMapping(modelId);

    if (!mapping || mapping.provider !== 'workflow') {
      throw new GitLabError({
        message: `Unknown workflow model ID: ${modelId}. Use 'duo-workflow' or a 'duo-workflow-*' model ID.`,
      });
    }

    return new GitLabWorkflowLanguageModel(
      modelId,
      {
        provider: `${providerName}.workflow`,
        instanceUrl,
        getHeaders,
        refreshApiKey,
        fetch: options.fetch,
        featureFlags: {
          ...options.featureFlags,
          ...effectiveWorkflowOptions?.featureFlags,
        },
        aiGatewayUrl: options.aiGatewayUrl,
      },
      effectiveWorkflowOptions
    );
  };

  // Default model factory - uses Anthropic backend for tool support
  const createDefaultModel = (modelId: string): LanguageModelV3 => {
    // Route workflow models to the workflow backend
    if (isWorkflowModel(modelId)) {
      return createWorkflowChatModel(modelId);
    }
    // Use Anthropic-based model by default for all models to get tool support
    return createAgenticChatModel(modelId);
  };

  const provider = Object.assign((modelId: string) => createDefaultModel(modelId), {
    specificationVersion: 'v3' as const,
    languageModel: createDefaultModel,
    chat: createDefaultModel,
    agenticChat: createAgenticChatModel,
    workflowChat: createWorkflowChatModel,
  }) as GitLabProvider;

  // Unsupported model types
  provider.embeddingModel = (modelId: string) => {
    throw new GitLabError({
      message: `GitLab provider does not support text embedding models. Model ID: ${modelId}`,
    });
  };

  provider.imageModel = (modelId: string) => {
    throw new GitLabError({
      message: `GitLab provider does not support image models. Model ID: ${modelId}`,
    });
  };

  return provider;
}

/**
 * Default GitLab Duo provider instance
 *
 * @example
 * ```typescript
 * import { gitlab } from '@ai-sdk/gitlab';
 *
 * const model = gitlab('duo-chat');
 * ```
 */
export const gitlab = createGitLab();
