# Rebuild recipe

All working files stay under `.local/audit-investigation/provider-migration/`. Pixi is the separately installed tool; npm/Node/TypeScript/tsup come from its locked environment or the local npm lock. Builds do not execute package install hooks. No provider credentials or live provider requests are required.

From the Open Enhance project root:

```sh
pixi run --locked node .local/audit-investigation/provider-migration/rebuild.mjs
pixi run --locked node .local/audit-investigation/provider-migration/check-contract-types.mjs
pixi run --locked node .local/audit-investigation/provider-migration/run-isolated.mjs
```

`rebuild.mjs` verifies the retained upstream tarball against registry SHA-512, recovers only allowlisted embedded source files, applies `source.patch`, restores the retained npm build lock, runs `npm ci --ignore-scripts`, typechecks and regenerates all outputs. It intentionally replaces only generated/recovered candidate files within this directory. `fetch-public.mjs` can redownload the pinned public artifact and LICENSE/configuration at its published gitHead if the retained inputs need refreshing. Never use it to silently change the upstream version of an existing candidate.

Build tools are pinned: TypeScript 5.9.3, tsup 9.0.0, AI SDK provider 3.0.8/provider-utils 4.0.65 and exact type package versions in package.json; all transitive resolutions and integrity hashes are retained in BUILD-LOCK.json. Build-time tsup 9 requires a recent Node; the project's locked Node 26 is the validated environment. SOURCE.patch is the source/configuration diff against the recovered public release. PROVENANCE.json records the original artifact/source inputs. npm's publication process ignores package-lock.json, so BUILD-LOCK.json is included separately for reproducibility. To rebuild directly from an extracted candidate tarball (which already includes migrated sources), restore BUILD-LOCK.json as package-lock.json using Pixi's Node, then run `pixi run --locked npm --prefix <extracted-package> ci --ignore-scripts --cache <isolated-cache>`, followed by `pixi run --locked npm --prefix <extracted-package> run typecheck` and `pixi run --locked npm --prefix <extracted-package> run build`. Keep extracted files and cache under the configured local data directory.

The project-local `artifacts/` directory contains the candidate npm tarball and its hash manifest; those files were never uploaded. Installing a fork into a different consumer must rerun full audit, negative type contracts and installed SDK/plugin/permission acceptance. Override file paths are consumer-specific and must not be published as references to a private local directory.
