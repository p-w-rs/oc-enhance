# Unpublished Open Enhance compatibility rebuild

This is `gitlab-ai-provider@6.23.1-open-enhance.1`, a local source rebuild of the public npm release `6.23.1`, not an upstream GitLab release. It is marked private and was not published.

## Provenance and license

The 24 TypeScript source files were recovered from the verified published `dist/index.js.map`; the original npm integrity, SHA-256, pinned upstream git commit, map digest and individual source digests are recorded in `PROVENANCE.json`. Paths were allowlisted before recovery. The upstream LICENSE was fetched from that exact public git commit and is included verbatim; no copyright notice was invented. README and changelog are upstream's original files and describe upstream, not this fork.

## Source migration

- Pin runtime Zod to `4.6.7`, not its legacy `/v3` entrypoint.
- Use explicit string key/value schemas in both direct-access header records.
- Enable `strictNullChecks` when checking sources and emitting declarations, so required OAuth/direct-access fields remain required in the public contract.
- Correct the existing nullable workflow root-namespace cache annotation; runtime behavior is unchanged.
- Serialize OpenAI Responses assistant text history using the SDK-supported input-message string form. The prior asserted output-resource shape omitted mandatory resource `id` and `status`. Text and role are unchanged, but the wire representation intentionally changes from an `output_text` array to a string. No inference/network behavior was exercised against a real provider.
- Regenerate CJS, ESM, both declaration entrypoints and both source maps using pinned TypeScript/tsup. No generated declaration text was edited.

## Compatibility and non-goals

All 45 runtime export names and value categories are preserved. Public model mappings and configuration constants are unchanged. Only `VERSION`/version-derived metadata identify the rebuild. The original build's required schema fields appeared optional in TypeScript because null checks were off; the new required fields match actual runtime validation. Invalid callers that depended on those incorrectly optional fields will now receive type errors.

Valid/invalid direct-access and OAuth HTTP payloads, error status handling, retry, in-memory/shared cache behavior, ESM/CJS loading, SDK-consumed provider/model factory shapes and offline no-project discovery are tested with synthetic injected fetches. Negative type contracts cover scalar responses, omitted required fields and non-string header/refresh values under full strict declaration checking. Oversized constrained array/map/set checks verify that patched Zod rejects before generating per-element issues.

Remaining inherited limitations: empty direct-access tokens are accepted by the nonpersistent schema but rejected by persistent caching; generic `duo-chat` is not a registered model ID in this upstream release. These baseline behaviors were not changed. Invalid-payload error formatting may differ under Zod 4. No guarantee is made for arbitrary custom Zod introspection or exact serialized error strings.

This is a measured local candidate, not a claim of full upstream provider conformance. Live GitLab/OAuth endpoints, WebSocket workflow sessions, Anthropic/OpenAI generation/streaming, alternate platforms, and minimum Node 18 support were not tested. Target acceptance is macOS Apple Silicon with the project's locked Node 26/OpenCode 2.2.6. Do not replace or modify a native OpenCode binary using this artifact. A root npm override affects only the project-resolved dependency tree, not dependency code embedded in that binary.

## Maintenance contract

Retain source, source patch, upstream integrity, build lock, test contracts and rebuild recipe together. Track upstream provider releases/security updates. Replace this fork with an upstream Zod-4-compatible release after rerunning runtime/type/installed-SDK tests; do not keep an unmaintained forever override. Any future fork change requires a new prerelease version and new artifact digest. Keep the full npm audit visible; production-only zero is not evidence of full-tree zero.
