import { defineConfig } from 'tsup';

export default defineConfig({
  entry: ['src/index.ts'],
  format: ['cjs', 'esm'],
  dts: true,
  sourcemap: true,
  clean: true,
  splitting: false,
  external: ['@ai-sdk/provider', '@ai-sdk/provider-utils'],
  define: {
    // semantic-release sets RELEASE_VERSION while preparing a release, before package.json is
    // bumped, so the published build reports the version it is released as.
    __PACKAGE_VERSION__: JSON.stringify(
      process.env.RELEASE_VERSION ||
        (await import('./package.json', { with: { type: 'json' } })).default.version
    ),
  },
});
