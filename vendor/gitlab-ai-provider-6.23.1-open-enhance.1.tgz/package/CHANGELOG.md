# Changelog

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## <small>6.23.1 (2026-10-25)</small>

- Merge branch 'fix/dws-ws-namespace-fallback' into 'main' ([a6bc3ac](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a6bc3ac))
- fix(dap): make Duo Agent Platform usable on self-managed instances ([647e929](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/647e929))

## 6.23.0 (2026-10-22)

- Merge branch 'feat/shared-direct-access-cache' into 'main' ([5f13534](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5f13534))
- feat(auth): add opt-in shared direct-access token cache ([1ddcf08](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/1ddcf08))

## 6.22.0 (2026-10-19)

- Merge branch 'ghavenga-skipcache-provider-option' into 'main' ([3d92427](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/3d92427))
- feat(anthropic): add skipCache provider option for one-shot runs ([2a1c1b1](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/2a1c1b1))

## 6.21.0 (2026-10-14)

- Merge branch 'feat/add-gemini-4-argon' into 'main' ([6a1b5e4](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6a1b5e4))
- feat(models): add Gemini 4 Argon workflow model mapping ([f21daf5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/f21daf5))

## <small>6.20.1 (2026-10-08)</small>

- Merge branch 'fix/anthropic-refusal-finish-reason' into 'main' ([4b126ee](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/4b126ee)), closes [#12](https://gitlab.com/vglafirov/gitlab-ai-provider/issues/12)
- fix(anthropic): map refusal stop reason to content-filter ([5997701](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5997701))

## 6.20.0 (2026-10-07)

- Merge branch 'feat/add-claude-haiku-5-5' into 'main' ([c8bc1ac](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/c8bc1ac))
- Merge branch 'mk/test-workflow-claude-5-mappings' into 'main' ([5421149](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5421149))
- feat(models): add Claude Haiku 5.5 model mapping ([6197e25](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6197e25))
- feat(models): add duo-workflow-haiku-5-5 mapping ([7f7dddc](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7f7dddc))
- test(models): assert Claude 5 workflow model refs ([89b7425](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/89b7425))

## <small>6.19.1 (2026-10-05)</small>

- Merge branch 'fix/openai-responses-tool-strict-default' into 'main' ([a104e7d](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a104e7d))
- fix(openai): default Responses tool strictness to [secure] ([8fd5dfb](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/8fd5dfb))

## 6.19.0 (2026-10-05)

- Merge branch 'mk/add-gpt-6-1-sol-and-sonnet-5-5' into 'main' ([abdfbcf](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/abdfbcf))
- feat(models): add Claude Sonnet 5.5 model mappings ([0f796db](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/0f796db))
- feat(models): add GPT-6.1 Sol model mappings ([7f40685](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7f40685))

## 6.18.0 (2026-09-23)

- Merge branch 'feature-add-gpt-6-sol-luna' into 'main' ([1f36939](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/1f36939))
- feat(models): add GPT-6 Sol and GPT-6 Luna model mappings ([90d53aa](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/90d53aa))

## <small>6.17.1 (2026-09-23)</small>

- Merge branch 'fix/release-version-injection' into 'main' ([236d448](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/236d448))
- fix(release): build with the release version and drop the tarball from the package ([33e9405](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/33e9405))

## 6.17.0 (2026-09-23)

- Merge branch 'feat/discovery-cache-key' into 'main' ([e407898](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e407898))
- feat(discovery): scope workflow discovery cache by optional cacheKey ([e9aac8c](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e9aac8c))

## 6.16.0 (2026-09-22)

- Merge branch 'feature-add-opus-5-5' into 'main' ([c1a5f12](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/c1a5f12))
- feat(models): add Claude Opus 5.5 model mappings ([6b6efe4](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6b6efe4))

## <small>6.15.1 (2026-09-09)</small>

- Merge branch 'fix/agent-platform-model-discovery' into 'main' ([98c1fa7](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/98c1fa7))
- fix(discovery): scope Agent Platform model discovery by project and correct stale workflow refs ([9dd9681](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9dd9681))

## 6.15.0 (2026-09-07)

- Merge branch 'feature-add-gpt-6-astra' into 'main' ([19d1e4f](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/19d1e4f))
- feat(models): add GPT-6 Astra model mappings ([a636486](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a636486))

## 6.14.0 (2026-09-04)

- Merge branch 'reasoning-controls' into 'main' ([7e13eb7](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7e13eb7))
- feat(agentic): add configurable reasoning controls ([afb4850](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/afb4850))

## 6.13.0 (2026-09-02)

- Merge branch 'feature-add-fable-5-1' into 'main' ([4c4196b](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/4c4196b))
- feat(models): add Claude Fable 5.1 model mapping ([e31c530](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e31c530))

## <small>6.12.2 (2026-08-24)</small>

- Merge branch 'fix/workflow-lock-reconnect-race' into 'main' ([51a9277](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/51a9277))
- fix(workflow): wait out the workflow lock before reconnecting after approval ([35ca694](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/35ca694))

## <small>6.12.1 (2026-07-29)</small>

- Merge branch 'ghavenga-cache-breakpoint-placement' into 'main' ([e8d0fe5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e8d0fe5))
- perf(anthropic): place cache breakpoints on final two messages ([5f2e13e](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5f2e13e))

## 6.12.0 (2026-07-27)

- Merge branch 'feature-add-opus-5' into 'main' ([9a5f447](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9a5f447))
- feat(models): add Claude Opus 5 model mappings ([50638a0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/50638a0))

## <small>6.11.1 (2026-07-13)</small>

- Merge branch 'docs-readme-model-table-sync' into 'main' ([790c050](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/790c050))
- Merge branch 'fix-gpt-5-6-responses-api' into 'main' ([7868119](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7868119))
- fix(models): route GPT-5.6 models through the Responses API ([eadbbe0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/eadbbe0))
- docs(readme): sync Available Model Mappings table with model-mappings.ts ([e16a28c](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e16a28c))

## 6.11.0 (2026-07-13)

- Merge branch 'feature-add-gpt-5-6' into 'main' ([283993c](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/283993c))
- feat(models): add GPT-5.6 model mappings (Sol, Terra, Luna) ([2248cd0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/2248cd0))

## <small>6.10.1 (2026-07-01)</small>

- Merge branch 'docs-add-gitlab-model-mr-pr-steps' into 'main' ([b22c0bd](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/b22c0bd))
- docs(skill): add MR, models.dev PR, and opencode bump steps ([3b4f366](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/3b4f366))

## 6.10.0 (2026-07-01)

- Merge branch 'feature-add-claude-sonnet-5' into 'main' ([5294b5e](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5294b5e))
- feat(models): add Claude Sonnet 5 model mappings ([85976b4](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/85976b4))
- chore(skill): add add-gitlab-model skill to automate model onboarding ([6bbfc4d](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6bbfc4d))

## <small>6.9.3 (2026-06-11)</small>

- Merge branch 'fix/concurrent-auth-token-race' into 'main' ([7306083](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7306083))
- fix(auth): prevent concurrent auth failures from token races ([49ed5c7](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/49ed5c7))

## <small>6.9.2 (2026-06-10)</small>

- Merge branch 'fix/auth-json-api-token-handling' into 'main' ([19a6e58](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/19a6e58))
- fix(auth): use PAT and enterpriseUrl-less OAuth tokens from auth.json ([6feeb58](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6feeb58))

## <small>6.9.1 (2026-06-10)</small>

- Merge branch 'fix-security-review-hardening' into 'main' ([81e627b](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/81e627b))
- fix: harden security, auth reliability, and stream lifecycle across provider ([ba754bf](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/ba754bf))

## 6.9.0 (2026-06-10)

- feat: add Claude Fable 5 model mapping ([0677b06](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/0677b06))

## 6.8.0 (2026-05-28)

- Merge branch 'feat/add-opus-4-8-model-mapping' into 'main' ([3ba92de](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/3ba92de))
- feat: add Claude Opus 4.8 model mapping ([be321b3](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/be321b3))

## <small>6.7.1 (2026-05-26)</small>

- Merge branch 'fix/anthropic-cache-token-counting' into 'main' ([298e2d0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/298e2d0))
- build: regenerate dist for anthropic cache token fix ([627d6f7](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/627d6f7))
- test(anthropic): add streaming test for cache token handling ([6033350](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6033350))
- fix(anthropic): include cache tokens in input token total ([699af0a](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/699af0a))

## 6.7.0 (2026-05-18)

- Merge branch 'feat/add-gpt-5-5-model-mapping' into 'main' ([10e84d1](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/10e84d1))
- feat: add GPT-5.5 model mapping ([eb9b32d](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/eb9b32d))

## 6.6.0 (2026-04-17)

- Merge branch 'feat/anthropic-prompt-caching' into 'main' ([d2125eb](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/d2125eb)), closes [#6](https://gitlab.com/vglafirov/gitlab-ai-provider/issues/6)
- feat(anthropic): enable prompt caching via cache_control on system prompt ([376556f](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/376556f))

## 6.5.0 (2026-04-17)

- Merge branch 'add-opus-4-7-model-mapping' into 'main' ([f95e21a](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/f95e21a))
- feat: add Claude Opus 4.7 model mapping ([dbb697f](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/dbb697f))

## <small>6.4.2 (2026-04-09)</small>

- fix: prevent auto-generated flowConfig from breaking DWS flow resolution ([e653dfc](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e653dfc))

## <small>6.4.1 (2026-04-06)</small>

- fix(workflow): surface server-side MCP tool calls as structured AI SDK events ([fcae357](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/fcae357))

## 6.4.0 (2026-04-02)

- chore: regenerate dist ([c6833c4](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/c6833c4))
- feat: pass ai_catalog_item_version_id to WebSocket for MCP tool injection ([19cd4e5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/19cd4e5))

## 6.3.0 (2026-03-31)

- fix(model): clear deferredClose before reconnect to prevent stream dying after batch approval ([017f8fe](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/017f8fe))
- fix(tests): use class mock for GitLabWorkflowTokenClient to support new in all environments ([e3f0e24](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/e3f0e24))
- chore: rebuild dist ([71bdc51](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/71bdc51))
- feat(model): per-session DWS workflow lifecycle and tool call approval ([aa7a09a](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/aa7a09a))

## <small>6.2.1 (2026-03-31)</small>

- fix(model): pre-approve all batch tools on approval reconnect to prevent re-triggering ([d7f80e2](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/d7f80e2))

## 6.2.0 (2026-03-30)

- feat: support aiCatalogItemVersionId in createWorkflow for custom agent session linking ([861c98d](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/861c98d))
- feat: support per-call flowConfig and flowConfigSchemaVersion overrides for custom agents ([9ba0308](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9ba0308))
- feat: support per-call workflowDefinition override via providerOptions.gitlab ([7f8ced2](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7f8ced2))
- chore: remove debug logging from doStream ([46a5278](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/46a5278))
- chore: remove debug logging from doStream ([7a2594f](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7a2594f))
- fix: reset workflow when workflowDefinition changes between agents ([30e95f8](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/30e95f8))
- fix: use callWorkflowDefinition in startRequest, not instance workflowOptions ([23f14ef](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/23f14ef))

## <small>6.1.1 (2026-03-29)</small>

- fix: update dist ([9f4b816](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9f4b816))

## 6.1.0 (2026-03-29)

- fix(approval): defer stream close while approval is pending and send rejection to DWS ([9344828](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9344828))
- feat(client): emit approval-required event for TOOL_CALL_APPROVAL_REQUIRED checkpoints ([500eff1](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/500eff1))
- feat(model): add approveAndResume, sessionPreapprovedTools, processedRequestIDs dedup ([f543831](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/f543831))
- feat(model): add public approvalHandler getter/setter for external wiring ([ee075b9](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/ee075b9))
- feat(options): add agentPrivileges to GitLabWorkflowOptions for testing approval flow ([475f2c7](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/475f2c7))
- feat(types): add ApprovalDecision, approval on StartRequest, approval-required event ([9a4ccf4](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9a4ccf4))
- chore: rebuild dist with approval integration changes ([d66deb9](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/d66deb9))
- chore: rebuild dist with approval integration changes ([daacc33](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/daacc33))

## 6.0.0 (2026-03-26)

- feat!: migrate to AI SDK v6 (LanguageModelV3) ([21c1165](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/21c1165))
- Merge branch 'ai-sdk-v6' into 'main' ([a527717](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a527717)), closes [#3](https://gitlab.com/vglafirov/gitlab-ai-provider/issues/3)
- chore: add .worktrees to .gitignore ([a7df2fb](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a7df2fb))

### BREAKING CHANGE

- This release migrates the provider to AI SDK v6 which
  requires @ai-sdk/provider-utils v4+ and uses the LanguageModelV3 interface.
  Consumers must upgrade to AI SDK v6 compatible tooling.

* Migrate models and provider to LanguageModelV3 for AI SDK v6
* Add AI SDK v6 support with updated streaming and tool-call handling
* Fix streaming tool-call handling and normalize v3 tool-result output
* Fix per-tool strict mode in OpenAI responses
* Fix unknown finish reason mapping for v6 compatibility
* Fix cache and add v3 contract tests
* Rebuild dist

## <small>5.3.3 (2026-03-25)</small>

- Merge branch 'vg/tools-fix' into 'main' ([d33e8c0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/d33e8c0))
- fix: fixed tools approval flow ([9597307](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/9597307))

## <small>5.3.2 (2026-03-24)</small>

- Merge branch 'fix/system-prompt-workflow-flowconfig' into 'main' ([ffe99d6](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/ffe99d6))
- fix: route system prompt via flowConfig and strip plan mode from DWS goal ([b71dc85](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/b71dc85))

## <small>5.3.1 (2026-03-23)</small>

- fix: rebuild dist files to include GPT-5.4 model mappings ([4bfe220](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/4bfe220))

## 5.3.0 (2026-03-23)

- Merge branch 'feat/gpt-5-4-models' into 'main' ([79a5090](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/79a5090))
- feat: add GPT-5.4, GPT-5.4 Mini, and GPT-5.4 Nano proxy model support ([7908719](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7908719))

## <small>5.2.2 (2026-03-20)</small>

- fix: save GraphQL defaultModel as selectedModelRef on first discovery ([5181f71](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/5181f71))

## <small>5.2.1 (2026-03-20)</small>

- fix: cache workflow model discovery to file and resolve model name on selection ([8ba7056](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/8ba7056))

## 5.2.0 (2026-03-18)

- fix: update dists ([57692b5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/57692b5))
- feat: add discoverWorkflowModels() for high-level workflow model discovery ([b61ed5a](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/b61ed5a))

## <small>5.1.2 (2026-03-17)</small>

- fix: regenerate dists ([091d3ae](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/091d3ae))

## <small>5.1.1 (2026-03-17)</small>

- Merge branch 'fix/builtin-fallback-security' into 'main' ([1026029](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/1026029))
- Merge branch 'vg/tools_fixes' into 'main' ([477d971](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/477d971))
- fix: add path validation and JSON error handling to executeBuiltinFallback ([a9ace75](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a9ace75))
- fix: fixed tools calling for workflow models ([d52ec56](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/d52ec56))

## 5.1.0 (2026-03-17)

- Merge branch 'fix/model-config-inparams-cache-ttl' into 'main' ([a9fdfa0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a9fdfa0))
- feat(model-config): add GitLabModelConfigRegistry with correct YAML parsing and cache TTL ([6ec09ad](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6ec09ad))

## 5.0.0 (2026-03-02)

- feat: move package to gitlab-ai-provider under vglafirov namespace ([3b5060f](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/3b5060f))

### BREAKING CHANGE

- package name changed from @gitlab/gitlab-ai-provider to gitlab-ai-provider

## 4.1.0 (2026-03-01)

- Merge branch 'duo-edit-20260227-221915' into 'main' ([654643a](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/654643a))
- feat(models): add GPT-5.3 Codex model support ([b34ebd6](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b34ebd6))

## 4.0.0 (2026-02-27)

- feat!: add Duo Workflow Service integration via WebSocket ([b293f73](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b293f73))
- feat!: bump major version ([196b058](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/196b058))
- feat!: trigger major release ([2cb0f9c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/2cb0f9c))
- Merge branch 'feat/duo-workflow-integration' into 'main' ([bfface1](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/bfface1))

### BREAKING CHANGE

- detectProject() now throws GitLabError instead of returning null on API failures. loadOpenCodeAuth() throws on malformed auth.json instead of returning undefined. Callers that relied on silent failure must add error handling.

## 4.0.0 (2026-02-27)

### ✨ Features

- **feat: add Duo Workflow Service integration via WebSocket** ([!9](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/-/merge_requests/9))
  - Add `workflowChat()` factory method for server-side agentic workflows
  - Implement WebSocket client for bidirectional DWS communication
  - Add dynamic model discovery via GraphQL (`aiChatAvailableModels`)
  - Support MCP tool integration and built-in tool mapping
  - Add file-based model cache with workspace/instance scoping
  - Implement per-stream state isolation for concurrent requests
  - Add dual heartbeat (WebSocket ping + JSON heartbeat)
  - Support `GITLAB_INSTANCE_URL` environment variable
  - Pass `aiGatewayUrl` through to workflow config

### 🔧 New Modules

- `gitlab-workflow-client.ts` - WebSocket client for DWS communication
- `gitlab-workflow-language-model.ts` - LanguageModelV2 adapter for DWS
- `gitlab-workflow-token-client.ts` - Token exchange and workflow creation
- `gitlab-model-discovery.ts` - Runtime model discovery via GraphQL
- `gitlab-model-cache.ts` - File-based cache for model discovery and selection
- `gitlab-workflow-builtins.ts` - Built-in tool mapping and security utilities
- `gitlab-workflow-types.ts` - Comprehensive DWS protocol type definitions

### 🧪 Test Coverage

- Added 89 new tests (300 total)
- `gitlab-model-discovery.test.ts` - 21 tests
- `gitlab-workflow-client.test.ts` - 33 tests
- `gitlab-workflow-language-model.test.ts` - 20 tests
- `gitlab-workflow-token-client.test.ts` - 25 tests
- `gitlab-provider.test.ts` - 15 new tests for workflow routing

### 🔒 Security

- Shell metacharacter validation before escaping
- URL scheme validation (http/https only)
- Credential redaction in error messages
- Command length limits
- Defense-in-depth approach for all tool executions

### 📝 Documentation

- Updated README with Duo Workflow Service documentation
- Added workflow model mappings and usage examples
- Documented model selection priority and caching behavior
- Added architecture documentation for new components

### ⚠️ BREAKING CHANGES

- Added `workflowChat()` method to `GitLabProvider` interface
- `GITLAB_INSTANCE_URL` environment variable now supported (precedence: explicit > env > default)

## 3.6.0 (2026-02-18)

- Merge branch 'feat/add-sonnet-4-6' into 'main' ([68d9e4f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/68d9e4f))
- feat: add Claude Sonnet 4.6 model mapping ([c4fd7b1](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c4fd7b1))

## <small>3.5.1 (2026-02-16)</small>

- Merge branch 'vg/token-refresh' into 'main' ([38295cf](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/38295cf))
- fix: resolve mid-session OAuth token refresh failures ([b495153](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b495153))

## 3.5.0 (2026-02-06)

- Merge branch 'feat/add-opus-4-6' into 'main' ([b776bd7](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b776bd7))
- feat(models): add Claude Opus 4.6 model support ([e221e45](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e221e45))

## <small>3.4.1 (2026-02-06)</small>

- Merge branch 'vg/token_refresh_fix' into 'main' ([8c1f2c4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/8c1f2c4))
- fix: detect context overflow errors before token refresh ([ce272cd](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/ce272cd))

## 3.4.0 (2026-02-02)

- Merge branch 'feat/ai-gateway-headers' into 'main' ([f2d4c79](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/f2d4c79))
- feat: add custom AI Gateway headers support ([2ef662d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/2ef662d))
- chore: added models testing script ([85dd9ba](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/85dd9ba))
- chore: bump version to 3.3.1 to fix package-lock.json sync ([6e6e9e2](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/6e6e9e2))

## 3.3.0 (2026-01-23)

- feat: add GPT-5.2 model support (duo-chat-gpt-5-2) ([fba8c4c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/fba8c4c))

## 3.2.0 (2026-01-22)

- feat: add OpenAI models support with Responses API ([c715505](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c715505))

## <small>3.1.3 (2026-01-21)</small>

- Merge branch 'fix/streaming-tool-call-handling' into 'main' ([22279b1](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/22279b1))
- fix: refactor streaming to handle tool calls properly ([88fb513](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/88fb513))

## <small>3.1.2 (2026-01-18)</small>

- fix: removed API tools and added new env variable ([a64ef6d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a64ef6d))

## <small>3.1.1 (2026-01-14)</small>

- fix: use models mapping for Anthropic ([7b876ec](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/7b876ec))

## 3.1.0 (2026-01-13)

- feat: improve npm metadata for better discoverability ([fc3795c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/fc3795c))

## <small>3.0.9 (2026-01-07)</small>

- docs: removed unused documentation ([a5f3bdd](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a5f3bdd))

## <small>3.0.8 (2025-12-19)</small>

- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([0c24b31](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/0c24b31))
- fix: specified CODEOWNERS ([0e92bbd](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/0e92bbd))

## <small>3.0.7 (2025-12-19)</small>

- fix: convert relative links to absolute GitLab URLs in README ([accde31](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/accde31))

## <small>3.0.6 (2025-12-19)</small>

- fix: use NPM_ID_TOKEN with correct audience for OIDC ([03fb549](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/03fb549))

## <small>3.0.5 (2025-12-19)</small>

- fix: use NPM_TOKEN for authentication (OIDC not supported for GitLab) ([4d595cf](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/4d595cf))

## <small>3.0.4 (2025-12-19)</small>

- refactor: use artifacts for version propagation ([03d4935](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/03d4935))
- fix: use OIDC for npmjs.org and sync version ([e5ff429](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e5ff429))

## <small>3.0.3 (2025-12-19)</small>

- fix: update package-lock.json with MIT license ([d724d20](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/d724d20))
- fix: use NPM_TOKEN for npmjs.org authentication ([e96d9de](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e96d9de))

## <small>3.0.2 (2025-12-19)</small>

- fix: correct license to MIT in package.json ([6df4154](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/6df4154))

## <small>3.0.1 (2025-12-19)</small>

- fix: use SIGSTORE_ID_TOKEN for npm provenance ([e5c8c7f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e5c8c7f))

## 3.0.0 (2025-12-19)

- feat: automate publishing workflow ([f8c384d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/f8c384d))

### BREAKING CHANGE

- Publishing now happens automatically on every main branch commit

## 2.0.0 (2025-12-18)

- fix: bump the version ([02df4b2](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/02df4b2))
- fix: remove GitLab registry config and add test dependencies ([81cc14e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/81cc14e))
- feat: configure publishing to npmjs.org with OIDC ([bb62d90](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/bb62d90))

### BREAKING CHANGE

- Package now only published to npmjs.org as @gitlab/gitlab-ai-provider

## <small>1.0.5 (2025-12-18)</small>

- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([f93aa47](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/f93aa47))
- fix: publish to both registries ([1ef9dd2](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1ef9dd2))

## <small>1.0.4 (2025-12-18)</small>

- fix: fix .npmrc ([fc55fa0](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/fc55fa0))
- fix: moved to @gitlab scope ([1213f5d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1213f5d))
- fix: npmjs fix ([461e87c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/461e87c))
- fix: publish to @gitlab ([c55252c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c55252c))
- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([30d1307](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/30d1307))

## <small>1.0.3 (2025-12-18)</small>

- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([aa5ed2a](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/aa5ed2a))
- fix: added .chat() alias ([e8d8ab8](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e8d8ab8))

## <small>1.0.2 (2025-12-18)</small>

- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([327e561](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/327e561))
- fix: fixed publishing ([1f65b41](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1f65b41))

## <small>1.0.1 (2025-12-18)</small>

- fix: added MIT LICENSE ([4484571](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/4484571))
- fix: contributing documentation ([7f90de8](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/7f90de8))
- Merge branch 'main' of gitlab.com:gitlab-org/editor-extensions/gitlab-ai-provider ([854ece3](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/854ece3))

## 1.0.0 (2025-12-18)

- fix: add missing peer marker for vite in package-lock.json ([03f0091](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/03f0091))
- fix: add text-start and text-end events for V2 stream format ([a4fec61](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a4fec61))
- fix: added npmrc ([75725d5](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/75725d5))
- fix: buffer and reorder chunks by numeric chunkId sequence number ([83e0593](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/83e0593))
- fix: create release ([8f38ca1](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/8f38ca1))
- fix: disable body-max-line-length rule for semantic-release compatibility ([300b6cf](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/300b6cf))
- fix: handle out-of-order chunks with cumulative content ([3fe12e8](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/3fe12e8))
- fix: load auth token ([b2f3b5b](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b2f3b5b))
- fix: package-lock ([e478397](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e478397))
- fix: resolve ESLint errors in CI pipeline ([12d391e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/12d391e))
- fix: simplify streaming - cumulative content with length-based delta extraction ([34b9b9a](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/34b9b9a))
- fix: simplify streaming - remove buffering, handle both cumulative and incremental content ([722d1fc](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/722d1fc))
- fix: skip final cumulative message and treat chunks as incremental ([b078ef4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b078ef4))
- fix: sync package-lock and fix formatting ([1583fb1](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1583fb1))
- fix: Token refresh on 401 ([2a7bfec](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/2a7bfec))
- fix: update specificationVersion to v2 for AI SDK 5 compatibility ([ddc75cd](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/ddc75cd))
- fix: updated package-lock ([25332df](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/25332df))
- fix: use AI SDK V2 stream format with delta field ([e8eb3b4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e8eb3b4))
- fix: use Bearer token authentication for GitLab API project detection ([c32b926](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c32b926))
- chore: update CI to node 25.2.1 and regenerate package-lock ([04889be](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/04889be))
- chore: update CI to use node 22.14.0 LTS ([1ce4a4e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1ce4a4e))
- chore(deps): Updated README.md ([47cb8ed](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/47cb8ed))
- chore(release): 0.0.3 [skip ci] ([d1ba2ed](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/d1ba2ed))
- chore(release): 0.0.4 [skip ci] ([6459942](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/6459942))
- chore(release): 1.0.0 [skip ci] ([80b423d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/80b423d))
- chore(release): 1.0.1 [skip ci] ([a77ce6b](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a77ce6b))
- chore(release): 1.0.2 [skip ci] ([c683fc7](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c683fc7))
- chore(release): 1.1.0 [skip ci] ([46542c4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/46542c4))
- chore(release): 1.2.0 [skip ci] ([bd79e4e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/bd79e4e))
- chore(release): 1.2.1 [skip ci] ([d05d7f8](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/d05d7f8))
- chore(release): 1.2.2 [skip ci] ([2c2a160](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/2c2a160))
- feat: Added package build for npmjs ([d32e97e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/d32e97e))
- feat: added package-lock.json ([7b320b5](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/7b320b5))
- feat: remove agentic workflow model and fix lint warnings ([843c422](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/843c422))
- feat: Renamed package to @gitlab-org/gitlab-ai-provider ([6d41fc0](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/6d41fc0))
- feat: rolled back npm namespace ([a10987b](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a10987b))
- feat: Updated npm repo namespace ([b74de74](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b74de74))
- feat(workflow): Added Gitlab Duo Workflow functionality ([624900f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/624900f))
- Add comprehensive logging to debug empty workflow sessions ([9c1cd6d](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/9c1cd6d))
- Add error handling for missing project context in agentic workflow ([1595caf](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1595caf))
- Add feature flags support for agentic chat models ([792581c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/792581c))
- Add prepare script to auto-build on install ([013a033](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/013a033))
- Add WebSocket headers logging for debugging ([bbb4c16](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/bbb4c16))
- Add workflow status polling to debug why workflow doesn't start ([520afa6](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/520afa6))
- Add X-Gitlab-Workflow-Id header to WebSocket connection ([2fd3097](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/2fd3097))
- Added Gitlab OAuth support ([59c095c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/59c095c))
- added gitlab project detector ([127687c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/127687c))
- agentic workflow ([6263c61](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/6263c61))
- Configure package for remote git installation ([80740a5](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/80740a5))
- feat!: rename model classes to reflect agentic capabilities ([05e6b35](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/05e6b35))
- Fix streaming to use AI SDK V1 format with textDelta field ([17c059f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/17c059f))
- Fix workflow creation payload to match GitLab API expectations ([5c2cd52](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/5c2cd52))
- Fix workflow initialization by sending initial message via REST API instead of WebSocket ([c8fc84f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c8fc84f))
- Fixing chunk ordering ([962ea8c](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/962ea8c))
- Include built dist folder for npm install ([b31d7dd](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b31d7dd))
- Initial commit ([3f23827](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/3f23827))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider ([1f0c73f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/1f0c73f))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider ([0f915c9](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/0f915c9))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider ([376e770](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/376e770))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider ([801bfcc](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/801bfcc))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider ([18324c3](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/18324c3))
- Merge branch 'main' of gitlab.com:vglafirov/gitlab-ai-provider into main ([e7a003f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e7a003f))
- Merge branch 'vg/duo-workflow' into 'main' ([b15c322](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/b15c322))
- Merge branch 'vg/models_selection' into 'main' ([f5d2ab7](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/f5d2ab7))
- Remove unnecessary sendEvent call - workflow starts automatically with goal ([3cea85b](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/3cea85b))
- Remove workflow status update - workflow starts automatically ([f6bd7d4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/f6bd7d4))
- removed API based agentic model ([d6a1037](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/d6a1037))
- removed legacy chat model ([0f1e795](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/0f1e795))
- Renamed GITLAB_API_TOKEN to GITLAB_TOKEN ([4bdcfbb](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/4bdcfbb))
- Send initial MESSAGE event to start workflow execution ([9b8df12](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/9b8df12))
- Set workflow status to RUNNING before sending initial message ([e826e55](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/e826e55))
- Updated README.md ([752871e](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/752871e))
- Use Agentic proxy ([a9a9827](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/a9a9827))
- Use OpenCode standard log directory for workflow debug logs ([28d1cc2](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/28d1cc2))
- Write debug logs to file instead of console ([093ad08](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/093ad08))
- ci: add GitLab CI/CD pipeline with semantic release automation ([53283e6](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/53283e6))
- ci: Updated publish namespace ([29864d7](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/29864d7))
- docs: add AGENTS.md with build, test, and code style guidelines ([31f9554](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/31f9554))
- docs: Updated README.md ([047b6e5](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/047b6e5))
- Fix: Add project_id and namespace_id as WebSocket headers ([5c2d142](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/5c2d142))
- Fix: Send initial user message to workflow after WebSocket connection ([12f4cfc](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/12f4cfc))
- Fix: Use project PATH for project_id, not numeric ID ([5709dd4](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/5709dd4))
- Fix: Use SOFTWARE_DEVELOPMENT workflow type instead of AGENTIC_CHAT ([c347013](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/c347013))
- Fix: Use status_event instead of status in workflow update API ([946333f](https://gitlab.com/gitlab-org/editor-extensions/gitlab-ai-provider/commit/946333f))

### BREAKING CHANGE

- Renamed GitLabAnthropicLanguageModel to
  GitLabAgenticLanguageModel and GitLabLSPAgenticLanguageModel to
  GitLabAgenticWorkflowLanguageModel. Updated all related types,
  configs, and provider methods:

* GitLabAnthropicOptions -> GitLabAgenticOptions
* GitLabLSPAgenticOptions -> GitLabAgenticWorkflowOptions
* provider.anthropicChat() -> provider.agenticChat()
* provider.lspAgenticChat() -> provider.agenticWorkflow()
* Provider names: .anthropic -> .agentic
* Provider names: .lsp-agentic -> .agentic-workflow

This change better reflects the agentic nature of these models
and provides clearer naming for workflow-based interactions.

## [1.2.2](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.2.1...v1.2.2) (2025-12-07)

### 🐛 Bug Fixes

- load auth token ([b2f3b5b](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/b2f3b5b01abfdfa36c12b4c045029a2b8186b886))

## [1.2.1](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.2.0...v1.2.1) (2025-12-07)

### 🐛 Bug Fixes

- Token refresh on 401 ([2a7bfec](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/2a7bfecbb1d32463150b2e5f67e6deae8a9b6641))

## [1.2.0](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.1.0...v1.2.0) (2025-12-06)

### ✨ Features

- rolled back npm namespace ([a10987b](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/a10987bb17ba02fcbdac60e918424f1852f61589))

## [1.1.0](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.0.2...v1.1.0) (2025-12-06)

### ✨ Features

- added package-lock.json ([7b320b5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/7b320b58c771eb4615ab7d0b28a612065ec01bbb))
- Renamed package to @gitlab-org/gitlab-ai-provider ([6d41fc0](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/6d41fc08ab2b3a3603a9f095df097e0e0c260898))
- Updated npm repo namespace ([b74de74](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/b74de74100e854cef35e98a7f6334fd59179aeeb))

## [1.0.2](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.0.1...v1.0.2) (2025-12-04)

### 📚 Documentation

- Updated README.md ([047b6e5](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/047b6e55ba0c7faaa9a149b06d92392c808d080d))

## [1.0.1](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v1.0.0...v1.0.1) (2025-12-04)

### 🐛 Bug Fixes

- use Bearer token authentication for GitLab API project detection ([c32b926](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/c32b9266f2c01d714bd54762c00676994ad74810))

## [1.0.0](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v0.0.4...v1.0.0) (2025-12-04)

### ⚠ BREAKING CHANGES

- Renamed GitLabAnthropicLanguageModel to
  GitLabAgenticLanguageModel and GitLabLSPAgenticLanguageModel to
  GitLabAgenticWorkflowLanguageModel. Updated all related types,
  configs, and provider methods:

* GitLabAnthropicOptions -> GitLabAgenticOptions
* GitLabLSPAgenticOptions -> GitLabAgenticWorkflowOptions
* provider.anthropicChat() -> provider.agenticChat()
* provider.lspAgenticChat() -> provider.agenticWorkflow()
* Provider names: .anthropic -> .agentic
* Provider names: .lsp-agentic -> .agentic-workflow

This change better reflects the agentic nature of these models
and provides clearer naming for workflow-based interactions.

### ✨ Features

- rename model classes to reflect agentic capabilities ([05e6b35](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/05e6b35269433df85ab1d4138cf7fbca61dd95d3))

## [0.0.4](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v0.0.3...v0.0.4) (2025-12-03)

### 📚 Documentation

- add AGENTS.md with build, test, and code style guidelines ([31f9554](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/31f95547cb8a12295b86c2926b11f7885a8aa959))

## [0.0.3](https://gitlab.com/vglafirov/gitlab-ai-provider/compare/v0.0.2...v0.0.3) (2025-12-03)

### 🐛 Bug Fixes

- disable body-max-line-length rule for semantic-release compatibility ([300b6cf](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/300b6cfea4f8f71dcbabc5cad7b7d30c53c4348f))
- resolve ESLint errors in CI pipeline ([12d391e](https://gitlab.com/vglafirov/gitlab-ai-provider/commit/12d391eda8405a8abd85cc33118ea259c171493c))

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Initial implementation of GitLab Duo provider
- GraphQL API client for GitLab Duo Chat
- ActionCable WebSocket streaming support
- Personal Access Token authentication
- Support for GitLab.com and self-hosted instances
- Context-aware chat with file support
- Multi-turn conversations with thread support
- Comprehensive error handling with GitLabError class
- TypeScript type definitions
- Documentation and examples

### Features

- ✅ Streaming chat responses
- ✅ GraphQL API integration
- ✅ PAT authentication
- ✅ Self-hosted GitLab support
- ✅ Context-aware assistance

### Known Limitations

- Token counting uses estimation
- Limited tool/function calling support
- No embedding support
- No image generation support

## [0.0.1] - 2025-01-XX

Initial release (in development)
